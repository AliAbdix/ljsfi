<?php
  function get_cluster_info($cs, $bdii="exp-bdii.cern.ch") {
    $ds=ldap_connect($bdii,2170);
    $r=ldap_bind($ds);
    // Get the subcluster name
    $filter='(&(objectclass=GlueCluster)(GlueForeignKey=GlueCEUniqueID='.$cs.'))';
    $items=array('GlueClusterUniqueID');
    $sr=ldap_search($ds, "o=grid", $filter, $items);
    $info = ldap_get_entries($ds, $sr);
    $scname = $info[0]["glueclusteruniqueid"][0];
    // Geth the subcluster info
    $filter='(&(objectclass=GlueSubCluster)(GlueSubClusterUniqueID=' . $scname . '))';
    $items=array('GlueHostOperatingSystemName','GlueHostOperatingSystemRelease','GlueHostOperatingSystemVersion');
    $sr=ldap_search($ds, "o=grid", $filter, $items);
    $info = ldap_get_entries($ds, $sr);
    for ($i=0; $i<$info["count"]; $i++) {
      $osname = $info[$i]["gluehostoperatingsystemname"][0];
      $osrel  = $info[$i]["gluehostoperatingsystemrelease"][0];
      $osver  = $info[$i]["gluehostoperatingsystemversion"][0];
      list($scuid, $cuid, $mdsvoname, $other) = split(",", $info[$i]["dn"], 4);
      list($key, $sitename) = split("=", $mdsvoname);
    }
    ldap_close($ds);
    $res = array($sitename,$osname,$osrel,$osver);
    return $res;
  }
?>
