<HTML>
<HEAD>

<?php
  require("guid.php");
  require("config.php");
  require("db.php");
?>

<TITLE>Request An Install for the <?php echo $LJSFi_VO; ?> software</TITLE>
</HEAD>

<link rel="STYLESHEET" type="text/css" href="../ai.css">
<link rel="shortcut icon" href="../img/favicon.ico">

<BODY>

<P>

<?php
  function insert_data() {
    // Current date/time
    $date = date("Y-m-d H:i:s");

    // Site info
    $sitename = $_POST["sitename"];
    $osname   = $_POST["osname"];
    $osver    = $_POST["osver"];
    $osrel    = $_POST["osrel"];
    $cs       = $_POST["cs"];
    $cename   = $_POST["cename"];

    // Process the site
    $res = db_query("SELECT ref FROM site WHERE cs='" . $cs . "'");
    $row = mysql_fetch_row($res);
    if (!$row) {
      $siteqry  = "INSERT INTO site SET";
      $siteqry .= "  cs='"        . $cs       . "'";
      $siteqry .= ", cename='"    . $cename   . "'";
      $siteqry .= ", name='"      . $sitename . "'";
      $siteqry .= ", osname='"    . $osname   . "'";
      $siteqry .= ", osversion='" . $osver    . "'";
      $siteqry .= ", osrelease='" . $osrel    . "'";
      $res = db_query($siteqry);
      $res = db_query("SELECT ref FROM site WHERE cs='" . $cs . "'");
      $row = mysql_fetch_row($res);
    }
    $siteref = $row[0];

    // Process the user
    $res = db_query("SELECT ref FROM user WHERE name='" . $_POST["user"] . "'");
    $row = mysql_fetch_row($res);
    if (!$row) {
      $res = db_query("INSERT INTO user SET name='" . $_POST["user"] . "', dn='" . getenv("SSL_CLIENT_S_DN") . "', email='" . $_POST["email"] . "'");
      $res = db_query("SELECT ref FROM user WHERE name='" . $_POST["user"] . "'");
      $row = mysql_fetch_row($res);
    }
    $userref = $row[0];

    // Process the release
    if ($_POST["rel"] == "other") {
      $relname = $_POST["relnew"];
    } else {
      $relname = $_POST["rel"];
    }
    $res = db_query("SELECT ref FROM release_stat WHERE name='" . $relname . "' AND sitefk=" . $siteref);
    $row = mysql_fetch_row($res);
    if (!$row) {
      $res = db_query("INSERT INTO release_stat SET name='" . $relname . "', sitefk=" . $siteref . ", userfk=" . $userref . ", status='pending', date='" . $date . "'");
      $res = db_query("SELECT ref FROM release_stat WHERE name='" . $relname . "' AND sitefk=" . $siteref);
      $row = mysql_fetch_row($res);
    }
    $relref = $row[0];

    // Process the bdii
    $res = db_query("SELECT ref FROM bdii WHERE hostname='" . $_POST["bdii"] . "'");
    $row = mysql_fetch_row($res);
    $bdiiref = $row[0];

    // Process the type
    $res = db_query("SELECT ref FROM request_type WHERE description='" . $_POST["reqtype"] . "'");
    $row = mysql_fetch_row($res);
    $typeref = $row[0];

    // Transaction ID
    $guid = guid();

    // Insert the data
    $query =  "INSERT INTO request SET id='" . $guid . "', bdiifk=" . $bdiiref;
    $query = $query . ", sitefk=" . $siteref . ", relfk=" . $relref;
    $query = $query . ", typefk=" . $typeref . ", userfk=" . $userref;
    $query = $query . ", statusfk=1, request_date='" . $date . "'";
    $query = $query . ", user_comments='" . ereg_replace("'","\'", $_POST["comments"]) . "'";
    $res   = db_query($query);

    return $guid;
  }
?>


<?php
  echo ("Request submitted. You'll be contacted back in case of problems.");
  $_POST["validated"] = "no";
  $guid = insert_data();
  echo ("<H2><FONT COLOR=red>Your request ID is: " . $guid);
  echo ("<BR>You may check the status of your request by following ");
  echo ("<A HREF='req.php?id=" . $guid . "'>this link</A>.</FONT></H2>");
  $_SERVER['FULL_URL'] = 'http';
  if($_SERVER['HTTPS']=='on') {
    $_SERVER['FULL_URL'] .=  's';
  }
  $_SERVER['FULL_URL'] .=  '://';
  $ip = gethostbyname($_SERVER['HTTP_HOST']);
  $hn = gethostbyaddr($ip);
  if($_SERVER['SERVER_PORT']!='80' && $_SERVER['SERVER_PORT']!='443') {
    $_SERVER['FULL_URL'] .=  $hn.':'.$_SERVER['SERVER_PORT'].$_SERVER['DOCUMENT_ROOT'];
  } else {
    $_SERVER['FULL_URL'] .=  $hn.$_SERVER['SCRIPT_NAME'];
  }
  $link=dirname($_SERVER['FULL_URL']) . "/req.php?id=" . $guid;
?>
<P>
<A HREF="mailto:Alessandro.DeSalvo@roma1.infn.it">For comments or informations please drop me a mail (Alessandro.DeSalvo@roma1.infn.it)</A>
</BODY>
</HTML>
