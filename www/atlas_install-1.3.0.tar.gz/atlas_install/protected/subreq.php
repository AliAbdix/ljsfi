<?php
  require("guid.php");
  require("config.php");
  require("db.php");
  function send_mail($link,$guid) {
    global $LJSFi_VO,$LJSFi_email;
    $infoqry = "SELECT rt.description, rl.name, s.cename, s.name, r.admin_comments"
             . "  FROM request_type rt, request r, release_stat rl, site s"
             . " WHERE r.relfk=rl.ref"
             . "   AND r.sitefk=s.ref"
             . "   AND r.typefk=rt.ref"
             . "   AND r.id='".$guid."'";
    $result = db_query($infoqry);
    $info=mysql_fetch_row($result);
    if (!isset($info[3])) { $info[3]=""; }
    $emailqry = "SELECT u.email FROM subscription s, user u"
              . " WHERE s.userfk=u.ref"
              . "   AND (s.sitename='".$info[3]."' OR s.sitename='*')"
              . "   AND u.email IS NOT NULL";
    $result = db_query($emailqry);
    $to = "";
    while ($email = mysql_fetch_array($result)) {
      if ($to != "") {
        $to .= ','.$email[0];
      } else {
        $to  = $email[0];
      }
    }

    $from_header = "From: nobody <".$LJSFi_email.">";
    $contents = "Dear ".$LJSFi_VO." software manager,\n";
    $contents = $contents . "a request for task type ".$info[0]." has been submitted by\n";
    $contents = $contents . $_POST["user"] . " <" . $_POST["email"] . ">\n";
    $contents = $contents . "on " . date("l, F dS Y, H:m:s") . "\n";
    $contents = $contents . "The request concerns the release '". $_POST["rel"] . "'";
    if ($_POST["rel"] == 'other') $contents = $contents . " (" . $_POST["relnew"] . ").";
    $contents = $contents . "\n";
    $contents = $contents . "on the CE " . $_POST["cename"] . ", indentified by\n";
    $contents = $contents . $_POST["cs"] . "\n";
    $contents = $contents . "Additional comments are reported below:\n------------\n" . $_POST["comments"] . "\n------------\n";
    $contents = $contents . "Additional info is available from the URL below:\n\n" . $link;
    $contents = $contents . "\n\nPlease process this request as soon as possible.\nBest regards.";
    $subject  = "Installation request for release " . $_POST["rel"] . " at " . $_POST["cename"];
 
    if($contents != "") {
      mail($to, $subject, $contents, $from_header);
      header("Location: $HTTP_REFERER");
    } else {
      print("Error, no mail submitted!");
    }
  }

  function check_pin() {
    $pinval=0;
    if (isset($_POST["cename"]) && isset($_POST["rel"])) {
      $qry = "SELECT release_stat.pin "
              ."FROM release_stat, site "
             ."WHERE release_stat.sitefk = site.ref "
               ."AND site.cename = '".$_POST["cename"]."' "
               ."AND release_stat.name='".$_POST["rel"]."'"
               ."AND release_stat.status<>'removed'";
      $res = db_query($qry);
      $row = mysql_fetch_row($res);
      if ($row) $pinval = $row[0];
    }
    return $pinval;
  }

  function check_requirements() {
    // Process the requirements
    $requirementsok = 1;   // By default the requirements are satisfied
    if (!isset($_POST["nodeps"]) && isset($_POST["rel"])) {
      $qry = "SELECT rd.requires FROM release_data rd WHERE rd.name='".$_POST["rel"]."' LIMIT 1";
      $res = db_query($qry);
      while ($row = mysql_fetch_array($res)) {
        if (isset($row[0]) && $row[0] != "") {
          $requires = $row[0];
          $requirementsok = 0;
          if (isset($_POST["sitename"]) && $_POST["sitename"] != "") {
            $qryreq = "SELECT release_stat.status FROM release_stat, site"
                    . " WHERE release_stat.name = '".$requires."'"
                    .   " AND release_stat.sitefk = site.ref"
                    .   " AND site.name = '".$_POST["sitename"]."'";
            $resreq = db_query($qryreq);
            while ($row = mysql_fetch_array($resreq)) {
              if (isset($row[0]) && strtolower($row[0]) == "installed") $requirementsok = 1;
            }
          }
        }
      }
    }
    return $requirementsok;
  }

  function check_required() {
    // Process the requirements
    $requiredby = "";   // By default the release is not required by anybody
    if (isset($_POST["rel"])) {
      $qry = "SELECT rd.name FROM release_data rd WHERE rd.requires='".$_POST["rel"]."'";
      $res = db_query($qry);
      while ($row = mysql_fetch_array($res)) {
        if (isset($row[0]) && $row[0] != "") {
          $relnum = $row[0];
          if (isset($_POST["sitename"]) && $_POST["sitename"] != "") {
            $qryreq = "SELECT release_stat.status FROM release_stat, site"
                    . " WHERE release_stat.name = '".$relnum."'"
                    .   " AND release_stat.sitefk = site.ref"
                    .   " AND (site.name = '".$_POST["sitename"]."'";
            if (isset($_POST["cs"]) && $_POST["cs"] != "") {
              $qryreq .= " OR site.cs = '".$_POST["cs"]."'";
            }
            $qryreq .= ")";
            $resreq = db_query($qryreq);
            $isfound = 0;
            while ($row = mysql_fetch_array($resreq)) {
              if (isset($row[0]) && strtolower($row[0]) != "removed" && strtolower($row[0]) != "aborted") $isfound=1;
            }
            if ($isfound == 1) {
              if ($requiredby != "") $requiredby .= ", ";
              $requiredby .= $relnum;
            }
          } else {
            if ($requiredby != "") $requiredby .= ", ";
            $requiredby .= $relnum;
          }
        }
      }
    }
    return $requiredby;
  }

  function insert_data() {
    // Current date/time
    $date = date("Y-m-d H:i:s");

    // Site info
    if (isset($_POST["sitename"])) $sitename = $_POST["sitename"];
    if (isset($_POST["osname"]))   $osname   = $_POST["osname"];
    if (isset($_POST["osver"]))    $osver    = $_POST["osver"];
    if (isset($_POST["osrel"]))    $osrel    = $_POST["osrel"];
    if (isset($_POST["cs"]))       $cs       = $_POST["cs"];
    if (isset($_POST["cename"]))   $cename   = $_POST["cename"];
    if (isset($_POST["arch"]))     $arch     = $_POST["arch"];

    if (isset($cs)) {
      // Process the site
      $res = db_query("SELECT ref, cs, cename, name, osname, osversion, osrelease, arch, swarea FROM site WHERE cs='" . $cs . "'");
      $row = mysql_fetch_row($res);
      if (!$row) {
        $siteqry  = "INSERT INTO site SET";
        $siteqry .= "  cs='"        . $cs       . "'";
        $siteqry .= ", cename='"    . $cename   . "'";
        $siteqry .= ", name='"      . $sitename . "'";
        $siteqry .= ", osname='"    . $osname   . "'";
        $siteqry .= ", osversion='" . $osver    . "'";
        $siteqry .= ", osrelease='" . $osrel    . "'";
        if (isset($arch) && $arch != "" && $arch != "-") $siteqry .= ", arch='".$arch."'";
        $res = db_query($siteqry);
        $res = db_query("SELECT ref, cs, cename, name, osname, osversion, osrelease, arch, swarea FROM site WHERE cs='" . $cs . "'");
        $row = mysql_fetch_row($res);
      } else {
        // Update the site info, if needed
        $upd_array = array();
        if (isset($cename) && $cename != "" && $cename != "-" && $row[2] != $cename) array_push($upd_array, "cename='".$cename."'");
        if (isset($name)   && $name   != "" && $name   != "-" && $row[3] != $name)   array_push($upd_array, "name='".$name."'");
        if (isset($osname) && $osname != "" && $osname != "-" && $row[4] != $osname) array_push($upd_array, "osname='".$osname."'");
        if (isset($osver)  && $osver  != "" && $osver  != "-" && $row[5] != $osver)  array_push($upd_array, "osversion='".$osver."'");
        if (isset($osrel)  && $osrel  != "" && $osrel  != "-" && $row[6] != $osrel)  array_push($upd_array, "osrelease='".$osrel."'");
        if (isset($arch)   && $arch   != "" && $arch   != "-" && $row[7] != $arch)   array_push($upd_array, "arch='".$arch."'");
        if ($upd_array) {
          $upd_query = "UPDATE site SET ".join(",",$upd_array)." WHERE ref=".$row[0];
          $res = db_query($upd_query);
        }
      }
      $siteref = $row[0];
      $swarea  = $row[8];
  
      // Process the user
      $res = db_query("SELECT ref FROM user WHERE name='" . $_POST["user"] . "'");
      $row = mysql_fetch_row($res);
      if (!$row) {
        $res = db_query("INSERT INTO user SET name='" . $_POST["user"] . "', dn='" . getenv("SSL_CLIENT_S_DN") . "', email='" . $_POST["email"] . "'");
        $res = db_query("SELECT ref FROM user WHERE name='" . $_POST["user"] . "'");
        $row = mysql_fetch_row($res);
      }
      $userref = $row[0];
  
      // Process the release data
      $query = "SELECT sw_physicalpath, sw_versionarea FROM release_data WHERE name='".$_POST["rel"]."'";
      $res = db_query($query);
      $row = mysql_fetch_row($res);
      if ($row) {
          $physpath = $row[0];
          $versarea = $row[1];
      } else {
          $physpath = "none";
          $versarea = "none";
      }

      // Process the release
      if ($_POST["rel"] == "other") {
        $relname = $_POST["relnew"];
      } else {
        $relname = $_POST["rel"];
      }
      $res = db_query("SELECT ref FROM release_stat WHERE name='" . $relname . "' AND sitefk=" . $siteref);
      $row = mysql_fetch_row($res);
      if (!$row) {
        $res = db_query("INSERT INTO release_stat SET name='" . $relname . "', sitefk=" . $siteref . ", userfk=" . $userref . ", status='pending', date='" . $date . "'");
        $res = db_query("SELECT ref FROM release_stat WHERE name='" . $relname . "' AND sitefk=" . $siteref);
        $row = mysql_fetch_row($res);
      }
      $relref = $row[0];
  
      // Process the bdii
      $res = db_query("SELECT ref FROM bdii WHERE hostname='" . $_POST["bdii"] . "'");
      $row = mysql_fetch_row($res);
      $bdiiref = $row[0];

      // Process the type
      $res = db_query("SELECT ref FROM request_type WHERE description='" . $_POST["reqtype"] . "'");
      $row = mysql_fetch_row($res);
      $typeref = $row[0];

      // Transaction ID
      $guid = guid();

      // Process the status
      if (isset($_POST["autoinstall"]) && $_POST["autoinstall"] == "yes") {
          $statusfk = 7;  // autorun
      } else {
          $statusfk = 1;  // not assigned
      }
      if (isset($_POST["status"]) && $_POST["status"] != "") {
          $res = db_query("SELECT ref FROM request_status WHERE description='" . $_POST["status"] . "'");
          $row = mysql_fetch_row($res);
          if ($row) {
              $statusfk = $row[0];
          }
      }

      if (!isset($_POST['multi']) ||
         (isset($_POST['multi']) && $_POST['multi']=='n')) {
          // Check for duplicate requests on the same CE
          $query = "SELECT id, request_date FROM request WHERE sitefk=" . $siteref;
          $query = $query . " AND typefk=" . $typeref;
          $query = $query . " AND relfk=" . $relref;
          $query = $query . " AND statusfk NOT IN (4,10)";
          $resdp = db_query($query);
          $row   = mysql_fetch_row($resdp);
          if (!$row and isset($swarea) and $swarea != "") {
              // Check for concurrent requests on the same exp soft area
              $query = "SELECT id, request_date"
                      . " FROM request, release_stat, release_data, site"
                     . " WHERE release_stat.ref = request.relfk"
                       . " AND site.ref = release_stat.sitefk"
                       . " AND swarea='" . $swarea . "'"
                       . " AND release_stat.name = release_data.name"
                       . " AND sw_physicalpath='" . $physpath . "'"
                       . " AND sw_versionarea='" . $versarea . "'"
                       . " AND request.statusfk NOT IN (3,4,5,6,10)";
              $rescr = db_query($query);
              $row   = mysql_fetch_row($rescr);
          }
      } else {
          unset($row);
      }

      if (!$row) {
          // Insert the data
          $query =  "INSERT INTO request SET id='" . $guid . "', bdiifk=" . $bdiiref;
          $query = $query . ", sitefk=" . $siteref . ", relfk=" . $relref;
          $query = $query . ", typefk=" . $typeref . ", userfk=" . $userref;
          $query = $query . ", statusfk=" . $statusfk . ", request_date='" . $date . "'";
          $query = $query . ", user_comments='" . ereg_replace("'","\'", $_POST["comments"]) . "'";
          $res   = db_query($query);
      } else {
          $guid  = "-" . $row[0]; 
      }
    } else {
      // No cs specified, error
      $guid  = "-"; 
    }
    return $guid;
  }
  if (!isset($_POST['quiet'])) {
?>
<HTML>
<HEAD>
<TITLE>Request An Install for the <?php echo $LJSFi_VO; ?> software</TITLE>
</HEAD>
<link rel="STYLESHEET" type="text/css" href="../ai.css">
<link rel="shortcut icon" href="../img/favicon.ico">
<BODY>
<P>
<?php
  }
  $_POST["validated"] = "no";
  $pin = check_pin();
  $requirementsok = check_requirements();
  $reqby          = check_required();
  if ($requirementsok == 1) {
    #if ($reqby == "" || ($reqby != "" && $_POST['reqtype'] != 'removal' && $_POST['reqtype'] != 'cleanup')) {
    if ($reqby == "" || ($reqby != "" && $_POST['reqtype'] != 'removal')) {
      if ($pin == 0 || ($pin != 0 && $_POST['reqtype'] != 'removal' && $_POST['reqtype'] != 'cleanup')) {
        $guid = insert_data();
        if ($guid == "-") {
          if (!isset($_POST['quiet'])) echo ("<H2><FONT COLOR=red>Wrong parameters</FONT></H2>");
        } elseif ($guid{0} == "-") {
          $guidlen = strlen($guid);
          $guid    = substr($guid,1,$guidlen-1);
          if (!isset($_POST['quiet'])) {
            echo ("<H2><FONT COLOR=red>A concurrent request on the same area is active, ");
            echo ("please retry later.");
            echo ("<BR>Please follow ");
            echo ("<A HREF='req.php?id=" . $guid . "'>this link</A> ");
            echo ("for further info or to restart the tasks.</FONT></H2>");
          }
        } else {
          if (!isset($_POST['quiet'])) {
            echo ("Request submitted. You'll be contacted back in case of problems.");
            echo ("<H2><FONT COLOR=red>Your request ID is: " . $guid);
            echo ("<BR>You may check the status of your request by following ");
            echo ("<A HREF='req.php?id=" . $guid . "'>this link</A>.</FONT></H2>");
          } else {
            if (!isset($_POST['noout'])) {
              echo "INSTALL SERVER> request id ".$guid." submitted\n";
            } else {
              echo $guid;
            }
          }
          $_SERVER['FULL_URL'] = 'http';
          if($_SERVER['HTTPS']=='on') {
            $_SERVER['FULL_URL'] .=  's';
          }
          $_SERVER['FULL_URL'] .=  '://';
          $ip = gethostbyname($_SERVER['HTTP_HOST']);
          $hn = gethostbyaddr($ip);
          if($_SERVER['SERVER_PORT']!='80' && $_SERVER['SERVER_PORT']!='443') {
            $_SERVER['FULL_URL'] .=  $hn.':'.$_SERVER['SERVER_PORT'].$_SERVER['DOCUMENT_ROOT'];
          } else {
            $_SERVER['FULL_URL'] .=  $hn.$_SERVER['SCRIPT_NAME'];
          }
          $link=dirname($_SERVER['FULL_URL']) . "/req.php?id=" . $guid;
          send_mail($link,$guid);
        }
      } else {
        if (!isset($_POST['quiet'])) echo ("You cannot remove a pinned release.");
      }
    } else {
      if (!isset($_POST['quiet'])) echo ("This release is required by ".$reqby.". Please remove the dependencies first.");
    }
  } else {
    if (!isset($_POST['quiet'])) echo ("The selected software requires a release which is not installed in the site.");
  }
  if (!isset($_POST['quiet'])) {
?>
<P>
<A HREF="mailto:Alessandro.DeSalvo@roma1.infn.it">For comments or informations please drop me a mail (Alessandro.DeSalvo@roma1.infn.it)</A>
</BODY>
</HTML>
<?php } ?>
