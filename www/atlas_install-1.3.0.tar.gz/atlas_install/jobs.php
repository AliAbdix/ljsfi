<HTML>
<HEAD>

<?php
  require ("db.php");
  require ("config.php");
?>

<TITLE><?php echo $LJSFi_VO; ?> Installation DB viewer - Job View</TITLE>

<link rel="STYLESHEET" type="text/css" href="ai.css">
<link rel="shortcut icon" href="img/favicon.ico">

</HEAD>
<BODY>
<script type="text/javascript" src="js/wz_tooltip.js"></script>
<P>
<?php if (isset($_GET['showinfo'])) { ?>
<TABLE border="2" frame="hsides" rules="groups"
          summary="<?php echo $LJSFi_VO; ?> software deployment status.">
<COLGROUP align="left">
<THEAD valign="top">
<TR>
<TH>Job info
<?php } else { ?>
<TABLE border="2" frame="hsides" rules="groups"
          summary="<?php echo $LJSFi_VO; ?> software deployment status.">
<CAPTION><EM><FONT SIZE=+2><?php echo $LJSFi_VO; ?> software deployment job list</FONT></EM></CAPTION>
<COLGROUP align="left">
<COLGROUP align="left">
<COLGROUP align="left">
<COLGROUP align="center">
<COLGROUP align="left">
<COLGROUP align="left">
<COLGROUP align="left">
<COLGROUP align="left">
<THEAD valign="top">
<TR>
<TH>Job type
<TH>Release
<TH>Destination
<TH>Job<BR>status
<TH>Validation<BR>status
<TH>Submission<BR>time
<TH>Retrieval<BR>time
<TH>Comments
<TH>User
<?php } ?>
<TBODY>

<?php
  $COLORS = array (1 => '#DDDDDD'
                 , 2 => '#00FF00'
                 , 3 => '#FF0000'
                 , 4 => '#FF00FF'
                  );
  $query  = ("SELECT jdl.type,release_stat.name,site.cs,job.status
                    ,validation.description
                    ,job.submission_time,job.retrieval_time
                    ,job.comments,user.name,job.validationfk
                    ,job.name,site.arch,job.id,job.reach_time
                    ,job.exit_code,job.status_reason
                    ,job.info
                    ,job.ref
                    ,user.dn
                    ,job.jdlfk
                    ,(SELECT dn FROM user WHERE ref=job.adminfk)
              FROM job,site,user,validation,jdl,release_stat
              WHERE     job.sitefk=site.ref AND job.userfk=user.ref
                    AND job.validationfk=validation.ref
                    AND job.jdlfk=jdl.ref AND jdl.relfk=release_stat.ref");
  if (isset($_GET['ce'])) $query = ($query . " AND cename='" . $_GET['ce'] . "'");
  if (isset($_GET['relfk'])) $query = ($query . " AND jdl.relfk='" . $_GET['relfk'] . "'");
  if (isset($_GET['status'])) $query = ($query . " AND validation.description='" . $_GET['status'] . "'");
  if (isset($_GET['user'])) $query = ($query . " AND user.name like '%" . $_GET['user'] . "%'");
  if (isset($_GET['id'])) $query = ($query . " AND job.ref=" . $_GET['id']);
  $query = ($query . " ORDER BY job.submission_time DESC, job.name");
  if (isset($_GET['show'])) echo $query;
  $result = db_query($query);
  if (!$result) {
    echo ("<P>ERROR: " . mysql_error() . "</P>");
    exit();
  } else {
    while ( $row = mysql_fetch_array($result) ) {
      echo ("<TR>");
      if (isset($_GET['showinfo'])) {
        $jobinfo = $row[16];
        $sslusername = getenv("SSL_CLIENT_S_DN_CN");
        $ssluserdetails = getenv("SSL_CLIENT_S_DN");
        if (isset($sslusername) && isset($ssluserdetails) && $ssluserdetails != "") {
          $query = "SELECT priv_view FROM user WHERE name='" . $sslusername . "' AND dn='" . $ssluserdetails . "'";
          $uresult = db_query($query);
          $urow = mysql_fetch_row($uresult);
          if ($urow) $priv_view=$urow[0];
        } else {
          echo ("<FONT SIZE=+1 COLOR='red'><B>");
          echo ("No valid credential found. Please use https and a valid certificate\n");
          echo ("</B></FONT>");
        }
        if (isset($priv_view)) {
          if ($priv_view == 1) {
            // Show the job info
            $data = nl2br(htmlentities($jobinfo));
            echo ("<TD bgcolor='#D3D3D3'><BR>\n");
            if ($data != '') {
              echo $data;
            } else {
              echo 'No info for this job';
            }
          } else {
            echo ("<FONT SIZE=+1 COLOR='red'><B>");
            echo ("You don't have permissions to view the job info.<BR>\n");
            echo ("Please check your registration and ask for the view privilege <A HREF='protected/user.php'>here</A>\n");
            echo ("</B></FONT>");
          }
        } elseif (isset($ssluserdetails) && $ssluserdetails != "") {
          echo ("Unknown user. Please register <A HREF='user.php'>here</A>\n");
        }
        echo ("<BR></TD>\n");
      } else {
        for ($i=0; $i<9; $i++) {
          echo ("<TD nowrap bgcolor=" . $COLORS[$row[9]] . ">");
          if ($i==0) { echo (" <A href='protected/jdl.php?id=".$row[19]."'>"); }
          if ($i==1) { echo (" <A href='protected/rel.php?name=".$row[1]."'>"); }
          if ($i==3) { echo (" <A href='protected/log.php?id=".$row[17]."'>"); }
          echo ($row[$i]);
          if ($i==0 || $i==1 || $i==3) echo ("</A>");
          if ($i==3) {
            echo ("&nbsp;<A href='jobs.php?id=".$row[17]."&showinfo' onmouseover=\"Tip('");
            echo ("JOB NAME:      " . $row[10] . "<BR>");
            echo ("JOB ARCH:      " . $row[11] . "<BR>");
            echo ("JOB ID:        " . $row[12] . "<BR>");
            echo ("REACH TIME:    " . $row[13] . "<BR>");
            echo ("EXIT CODE:     " . $row[14] . "<BR>");
            echo ("STATUS REASON: " . $row[15] . "<BR>");
            echo ("SUBMITTER DN:  " . $row[18] . "<BR>");
            if (isset($row[20])) $reqdn = $row[20]; else $reqdn = $row[18];
            echo ("REQUESTER DN:  " . $reqdn);
            echo ("', TITLE, 'Job Info', SHADOW, true, STICKY, 1, CLOSEBTN, true)\" onmouseout=\"UnTip()\">");
            echo ("<img src='img/info_sign_new.gif' width=15></A>");
          }
        }
      }
      echo ("</TR><TBODY>");
    }
  }
?>
</TABLE>
<?php
  echo( date("l, F dS Y, H:m:s") );
?>
<P>
<A HREF="mailto:Alessandro.DeSalvo@roma1.infn.it">For comments or informations please drop me a mail (Alessandro.DeSalvo@roma1.infn.it)</A>
</BODY>
</HTML>
