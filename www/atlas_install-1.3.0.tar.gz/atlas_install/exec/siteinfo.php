<?php
  require("db.php");

  function get_site_info() {
    $query = "SELECT cename, name, cs, swarea, fstype, mountpoint, capacity, available, quota FROM site ";
    $query_fields = array();
    array_push($query_fields, "cename='".$_POST["cename"]."'");
    if (isset($_POST["sitename"]) && $_POST["sitename"] != "") array_push($query_fields, "name='".$_POST["sitename"]."'");
    if (isset($_POST["cs"]) && $_POST["cs"] != "") array_push($query_fields, "cs='".$_POST["cs"]."'");
    if (isset($_POST["swarea"]) && $_POST["swarea"] != "") array_push($query_fields, "swarea='".$_POST["swarea"]."'");
    if (isset($_POST["fstype"]) && $_POST["fstype"] != "") array_push($query_fields, "fstype='".$_POST["fstype"]."'");
    if (isset($_POST["mountpoint"]) && $_POST["mountpoint"] != "") array_push($query_fields, "mountpoint='".$_POST["mountpoint"]."'");
    if (isset($_POST["capacity"]) && $_POST["capacity"] != "") array_push($query_fields, "capacity=".$_POST["capacity"]);
    if (isset($_POST["available"]) && $_POST["available"] != "") array_push($query_fields, "available=".$_POST["available"]);
    if (isset($_POST["quota"]) && $_POST["quota"] != "") array_push($query_fields, "quota=".$_POST["quota"]);
    $query .= "WHERE ".join(" AND ",$query_fields)." LIMIT 1";
    $res   = db_query($query);
    if ($res) {
      $row = mysql_fetch_row($res);
      print join(',', $row)."\n";
    } else {
      echo ("INSTALL SERVER> Cannot update site info for CE ".$_POST['cename'].".\n");
    }
    return 0;
  }

  if (isset($_POST["cename"]) && $_POST["cename"] != "") get_site_info();
?>
