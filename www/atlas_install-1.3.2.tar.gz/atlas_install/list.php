<HTML>
<HEAD>
<?php
  require ("db.php");
  require ("config.php");
?>
<TITLE><?php echo $LJSFi_VO; ?> Installation DB viewer</TITLE>
</HEAD>

<link rel="STYLESHEET" type="text/css" href="ai.css">
<link rel="shortcut icon" href="img/favicon.ico">

<script type="text/javascript">
function openpop(url) {
    newWin = window.open(url,'Details','scrollbars=no,resizable=yes, width=300, height=300,status=no,location=no,toolbar=no');
}
function closeWin() {
    self.close();
}
function showHideElement(cb,id) {
    var elm = document.getElementById(id);
    elm.style.display = cb.checked? "inline":"none";
}

function enableDisableField(form,id) {
  var elm = document.getElementById(id);
  if (elm.disabled) elm.disabled=false; else elm.disabled=true;
}

var btnWhichButton;

function checkform(form) {
  var retval=true;
  if (btnWhichButton.value == 'delete') {
    answ = confirm('Do you really want to delete the selected records?');
    if (!answ) {
      retval=false
    }
  }
  return retval;
}

</script>

<BODY>

<script src="js/sorttable.js"></script>
<script type="text/javascript" src="js/selectall.js"></script>
<script type="text/javascript" src="js/wz_tooltip.js"></script>

<P>
<?php

  function printLJSFtags ($tags)
  {
    foreach ($_REQUEST as $key => $value) {
      if (in_array($key, $tags) && $key != "skip" and $value != "") {
        if (is_array($value)) {
          foreach ($value as $val) echo '<input type="hidden" name="'.$key.'[]" value="'.$val.'">';
        } else {
          echo '<input type="hidden" name="'.$key.'" value="'.$value.'">';
        }
        echo "\n";
      }
    }
  }

  $sslusername = getenv("SSL_CLIENT_S_DN_CN");
  $ssluserdetails = getenv("SSL_CLIENT_S_DN");
  if (!isset($ssluserdetails) || $ssluserdetails == "") $ssluserdetails = "guest";
  $result = db_query("SELECT user.ref, role.description, role.ref FROM user,role WHERE name='" . $sslusername . "' AND dn='" . $ssluserdetails . "' AND user.rolefk=role.ref");
  $row = mysql_fetch_row($result);
  if (!$row) {
    $role="";
  } else {
    $adminfk=$row[0];
    $role=$row[1];
    $roleid=$row[2];
  }

  $LJSFtags = array( "rel", "user", "sitename", "arch", "cename", "status", "orderby", "orderdir");
  $lists    = array();
  $queries  = array(
                    "SELECT DISTINCT(name) FROM release_stat WHERE name <> 'all' ORDER BY name"
                   ,"SELECT DISTINCT(name) FROM site ORDER BY name"
                   ,"SELECT DISTINCT(arch) FROM site ORDER BY arch"
                   ,"SELECT DISTINCT(cename) FROM site ORDER BY cename"
                   ,"SELECT DISTINCT(status) FROM release_stat ORDER BY status"
                   ,""
                   ,""
                   ,"SELECT DISTINCT(LEFT(name, LOCATE('@',name)-1)) AS username FROM user ORDER BY username"
                   );
  foreach ($queries as $query) {
    $list = array();
    if ($query != "") {
      $result = mysql_query($query);
      if (!$result) {
        db_err(mysql_error());
      } else {
        while ($row = mysql_fetch_array($result)) {
          array_push($list, $row[0]);
        }
      }
    }
    array_push($lists, $list);
  }


?>

<TABLE id='frame_tbl' border="1" rules="groups" width="100%" summary="Mail subscriptions">
<COLGROUP width="800"></COLGROUP>
<TR><TD width="100%" height="30" background="img/bar.gif" class="captionimg">
<CENTER><?php echo $LJSFi_VO; ?> software deployment status</CENTER>
</TD></TR>
<TR><TD height="30">&nbsp;</TD></TR>

<TR><TD><CENTER>


<TABLE border="2" frame="hsides" rules="groups"
          summary="<?php echo $LJSFi_VO; ?> software deployment status.">
<?php if (isset($roleid) && $roleid > 1) echo '<COLGROUP align="center">'; ?>
<COLGROUP align="center">
<COLGROUP align="center">
<COLGROUP align="left">
<COLGROUP align="center">
<COLGROUP align="left">
<COLGROUP align="left">
<COLGROUP align="left">
<COLGROUP align="left">
<?php
  require("combo.php");
  $COLUMNS = array (
                    'Release<BR>number' => array('release_stat.name','rel')
                   ,'Site name<BR>'     => array('site.name','sitename')
                   ,'Release arch<BR>'  => array('site.arch','arch')
                   ,'Site CE<BR>'       => array('site.cename','cename')
                   ,'Status<BR>'        => array('release_stat.status','status')
                   ,'Comments<BR>'      => array('release_stat.comments','comments')
                   ,'Date<BR>'          => array('release_stat.date','date')
                   ,'Installer<BR>'     => array('user.name','user')
                   );
  $indx = 0;
  echo ('<form method="get" action="">');
  if (isset($roleid) && $roleid > 1) echo '<TH>Sel';
  echo ('<TH>Num');
  foreach($COLUMNS as $text=>$data) {
    $keyword = $data[0];
    $optname = $data[1];
    echo ('<TH>');
    if (count($lists[$indx]) > 0) {
      echo '<select name="',$optname,'" size="1">';
      combo_box ($lists[$indx]);
      echo '</select><br/>';
      echo '<input type="submit" value="Filter">';
      echo '<br/>';
    }
    $indx++;
    echo ("<A HREF='list.php?");
    $first = 0;
    foreach($_GET as $key=>$value) {
      if ($key != "orderby" && $key != "orderdir" && $value != "") {
        if ($first == 1) echo ("&");
        echo ($key . "=" . $value);
        $first = 1;
      }
    }
    if ($first == 1) echo ("&");
    echo ("orderby=" . $keyword);
    if ($_GET['orderdir'] == 'asc') {
      echo ("&orderdir=desc'>" . $text . "</A><BR><img width=30 src='img/b_up.png'>\n");
    } else {
      echo ("&orderdir=asc'>" . $text . "</A><BR><img width=30 src='img/b_down.png'>\n");
    }
  }
  echo '</form>';
?>
<TBODY>
<?php
  if (isset($roleid) && $roleid > 1) {
    echo ('<TR><TD colspan="10">');
    echo ('<FORM method="post" name="ljsfadmin" action="list.php" onsubmit="return checkform(this);">');
    echo ("\n");
    printLJSFtags($LJSFtags);
    echo '<table id="toolbar_tbl" border="0" bgcolor="#acacff" width="100%" cellpadding="1" rules="groups">';
    echo '<COLGROUP width="80"></COLGROUP>';
    echo '<COLGROUP width="80"></COLGROUP>';
    echo '<COLGROUP width="80"></COLGROUP>';
    echo '<COLGROUP width="80"></COLGROUP>';
    echo '<COLGROUP width="80"></COLGROUP>';
    echo '<COLGROUP width="80"></COLGROUP>';
    echo '<tr><td align="center">';
    echo ('<input type="image" src="img/delete_icon_small.gif" name="submit" value="delete" alt="Delete" onclick="btnWhichButton=this">');
    echo '</td><td align="center">';
    echo ('<input type="image" src="img/installed_icon.gif" name="submit" value="setinstalled" alt="SetInstalled" onclick="btnWhichButton=this">');
    echo '</td><td align="center">';
    echo ('<input type="image" src="img/failed_icon.gif" name="submit" value="setfailed" alt="SetFailed" onclick="btnWhichButton=this">');
    echo '</td><td align="center" valign="center">';
    echo ('<input type="image" src="img/erased_icon.gif" name="submit" value="setremoved" alt="SetRemoved" onclick="btnWhichButton=this">');
    echo '</td><td align="center" valign="center">';
    echo ('<input type="image" src="img/aborted_icon.gif" name="submit" value="setaborted" alt="SetAborted" onclick="btnWhichButton=this">');
    echo '</td><td align="center" valign="bottom">';
    echo '<input type="checkbox" name="ljsfadmin_sa" value="all" onclick="SetAllCheckBoxes(\'ljsfadmin\', \'relsel[]\', \'ljsfadmin_sa\');">';
    echo '</td><td>';
    echo '</td></tr>';
    echo '<tr><td align="center">';
    echo 'Delete';
    echo '</td><td align="center">';
    echo 'Set Installed';
    echo '</td><td align="center">';
    echo 'Set Failed';
    echo '</td><td align="center">';
    echo 'Set Removed';
    echo '</td><td align="center">';
    echo 'Set Aborted';
    echo '</td><td align="center">';
    echo 'Select all';
    echo '</td><td>';
    echo '</td></tr>';
    echo '</table>';
    echo '</TD></TR>';
  }
?>
<?php
  $COLORS = array ('installed' => '#00FF00'
                 , 'failed' => '#FF0000'
                 , 'aborted' => '#00AAFF'
                 , 'removed' => '#7F7F7F'
                 , 'other' => '#DDDDDD'
                  );

  // Perform the admin actions
  if (isset($roleid) && isset($_REQUEST['relsel']) && $roleid > 1) {
    require("protected/config.php");
    $query_action = array();
    if ($_REQUEST["submit"] == "delete") {
      $jdl_list = array();
      $job_list = array();
      $log_list = array();
      $req_list = array();
      $query_prep_action = "SELECT ref FROM jdl WHERE relfk IN (".join(',',$_REQUEST['relsel']).")";
      $result = mysql_query($query_prep_action);
      if (!$result) {
        echo ("<P>ERROR: Cannot get the jdl list. " . mysql_error() . "</P>");
        exit();
      } else {
        while ($row = mysql_fetch_array($result)) array_push($jdl_list,$row[0]);
      }
      if ($jdl_list) array_push($query_action, "DELETE FROM jdl WHERE ref IN (".join(',',$jdl_list).")");
      if ($jdl_list) {
        $query_prep_action = "SELECT ref, logfile FROM job WHERE jdlfk IN (".join(',',$jdl_list).")";
        $result = mysql_query($query_prep_action);
        if (!$result) {
          echo ("<P>ERROR: Cannot get the job list. " . mysql_error() . "</P>");
          exit();
        } else {
          while ($row = mysql_fetch_array($result)) {
            array_push($job_list,$row[0]);
            if (isset($row[1])) array_push($log_list,$upload_path.$row[1]);
          }
        }
      }
      if ($job_list) array_push($query_action, "DELETE FROM job WHERE ref IN (".join(',',$job_list).")");
      $query_prep_action = "SELECT id FROM request WHERE relfk IN (".join(',',$_REQUEST['relsel']).")";
      $result = mysql_query($query_prep_action);
      if (!$result) {
        echo ("<P>ERROR: Cannot get the request list. " . mysql_error() . "</P>");
        exit();
      } else {
        while ($row = mysql_fetch_array($result)) array_push($req_list,"'".$row[0]."'");
      }
      if ($req_list) array_push($query_action, "DELETE FROM request WHERE id IN (".join(',',$req_list).")");
      array_push($query_action, "DELETE FROM release_stat WHERE ref IN (".join(',',$_REQUEST['relsel']).")");
    } elseif ($_REQUEST["submit"] == "setinstalled") {
      foreach ($_REQUEST['relsel'] as $indx => $selection) {
        if (isset($_REQUEST['comments'][$indx]) && $_REQUEST['comments'][$indx] != "")
          $comments = "'".$_REQUEST['comments'][$indx]."'"; else $comments="NULL";
        array_push($query_action, "UPDATE release_stat SET status='installed', comments=".$comments." WHERE ref = ".$selection);
      }
    } elseif ($_REQUEST["submit"] == "setfailed") {
      foreach ($_REQUEST['relsel'] as $indx => $selection) {
        if (isset($_REQUEST['comments'][$indx]) && $_REQUEST['comments'][$indx] != "")
          $comments = "'".$_REQUEST['comments'][$indx]."'"; else $comments="NULL";
        array_push($query_action, "UPDATE release_stat SET status='failed', comments=".$comments." WHERE ref = ".$selection);
      }
    } elseif ($_REQUEST["submit"] == "setremoved") {
      foreach ($_REQUEST['relsel'] as $indx => $selection) {
        if (isset($_REQUEST['comments'][$indx]) && $_REQUEST['comments'][$indx] != "")
          $comments = "'".$_REQUEST['comments'][$indx]."'"; else $comments="NULL";
        array_push($query_action, "UPDATE release_stat SET status='removed', comments=".$comments." WHERE ref = ".$selection);
      }
    } elseif ($_REQUEST["submit"] == "setaborted") {
      foreach ($_REQUEST['relsel'] as $indx => $selection) {
        if (isset($_REQUEST['comments'][$indx]) && $_REQUEST['comments'][$indx] != "")
          $comments = "'".$_REQUEST['comments'][$indx]."'"; else $comments="NULL";
        array_push($query_action, "UPDATE release_stat SET status='aborted', comments=".$comments." WHERE ref = ".$selection);
      }
    }
  }
  if ($query_action) {
    foreach ($query_action as $query) {
      //echo $query."<br>";
      $result = mysql_query($query);
      if (!$result) {
        echo ("<P>ERROR: " . mysql_error() . "</P>");
        exit();
      }
    }
  }
  if ($log_list) {
    foreach ($log_list as $logfile) {
      //echo "Removing ".$logfile."<br>";
      unlink($logfile);
    }
  }

  // Show the results
  $query  = ("SELECT release_stat.name,site.name,release_arch.description,site.cename
                    ,release_stat.status,release_stat.comments,release_stat.date,user.name
                    ,user.email,release_stat.ref
                    ,site.osname,site.osrelease,site.cs
              FROM release_stat,release_data,release_arch,site,user
              WHERE release_stat.sitefk=site.ref AND release_stat.name=release_data.name
                    AND release_data.archfk=release_arch.ref AND release_stat.userfk=user.ref
                    AND release_stat.name != 'ALL'");
  if (isset($_REQUEST['rel']) && $_REQUEST['rel'] != '')
    $query=($query . " AND release_stat.name='" . $_REQUEST['rel'] . "'");
  if (isset($_REQUEST['user']) && $_REQUEST['user'] != '')
    $query=($query . " AND user.name like '%" . $_REQUEST['user'] . "%'");
  if (isset($_REQUEST['sitename']) && $_REQUEST['sitename'] != '')
    $query=($query . " AND site.name like '%" . $_REQUEST['sitename'] . "%'");
  if (isset($_REQUEST['arch']) && $_REQUEST['arch'] != '')
    $query=($query . " AND site.arch like '%" . $_REQUEST['arch'] . "%'");
  if (isset($_REQUEST['cename']) && $_REQUEST['cename'] != '')
    $query=($query . " AND site.cename like '%" . $_REQUEST['cename'] . "%'");
  if (isset($_REQUEST['siteid']) && $_REQUEST['siteid'] > 0)
    $query=($query . " AND site.ref = " . $_REQUEST['siteid']);
  if (isset($_REQUEST['status']) && $_REQUEST['status'] != '')
    $query=($query . " AND release_stat.status like '%" . $_REQUEST['status'] . "%'");
  $query=($query . " ORDER BY ");
  if (isset($_REQUEST['orderby']) && $_REQUEST['orderby'] != '') {
    $query=($query . $_REQUEST['orderby']);
  } else {
    $query = ($query . " release_stat.name,release_stat.status,site.name,site.cename");
  }
  if (isset($_REQUEST['orderdir']) && $_REQUEST['orderdir'] != '')
    $query=($query . " " . $_REQUEST['orderdir']);
  $result = mysql_query($query);
  if (!$result) {
    echo ("<P>ERROR: " . mysql_error() . "</P>");
    exit();
  } else {
    $category = array();
    while ( $row = mysql_fetch_array($result) ) {
      echo ("<TR>");
      if (!isset($category[$row[4]])) $category[$row[4]] = 0;
      $category[$row[4]]++;
      if (!$COLORS[$row[4]]) {
        $color = $COLORS['other'];
      } else {
        $color = $COLORS[$row[4]];
      }
      if (isset($roleid) && $roleid > 1) echo ('<TD bgcolor='.$color.'><input type="checkbox" name="relsel[]" value="'.$row[9].'" onclick="enableDisableField(this,'.$row[9].');"></td>');
      for ($i=0; $i<8; $i++) {
        echo ("<TD bgcolor=".$color.">");
        if ($i == 0) echo ($category[$row[4]]."</TD>\n<TD bgcolor=".$color.">");
        if ($i == 3) {
          echo ('<A HREF="jobs.php?relfk=' . $row[9] . '" onmouseover="Tip(\'');
          echo ($row[12] . '<BR>' . $row[10] . ' ' . $row[11]);
          echo ('\', WIDTH, 400, TITLE, \'Site Info\', SHADOW, true, FADEIN, 300, FADEOUT');
          echo (', 300, STICKY, 1, CLOSEBTN, true, CLICKCLOSE, true)" onmouseout="UnTip()">');
        }
        if ($i == 0) { echo ("<A HREF=\"list.php?rel=" . $row[0] . "\">"); }
        if ($i == 1) { echo ("<A HREF=\"protected/req.php?site=" . $row[1] . "&rel=".$row[0]."\">"); }
		if ($i == 5 && isset($roleid) && $roleid > 1) {
	  echo ('<input type="text" id="'.$row[9].'" name="comments[]" value="');
        }
        if ($i == 7 && $row[8] != "") { echo ("<A HREF=\"mailto:" . $row[8] . "\">"); }
        echo ($row[$i]);
        if ($i == 0 || ($i == 7 && $row[8] != "")) echo ("</A>");
        if ($i == 5) echo ('" disabled>');
        echo ("</TD>\n");
      }
      echo ("</TR><TBODY>");
    }
  }
?>
</TABLE>

<?php if (isset($roleid) && $roleid > 1) { echo '</form>'; } ?>

</CENTER></TD></TR></TABLE>

<?php
  if (isset($ssluserdetails) && $ssluserdetails != "") {
    echo ("You are logged in as ".$ssluserdetails);
    if (isset($role)) echo (" (".$role.")");
  echo ("<br>");
  }
  echo (date("l, F dS Y, H:m:s"));
?>
<P>
<A HREF="mailto:Alessandro.DeSalvo@roma1.infn.it">For comments or informations please drop me a mail (Alessandro.DeSalvo@roma1.infn.it)</A>
</BODY>
</HTML>
