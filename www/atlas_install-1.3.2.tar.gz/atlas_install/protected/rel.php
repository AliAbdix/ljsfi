<?php if (!isset($_POST['ws']) or $_POST['ws'] == '') { ?>
<?php require("config.php"); ?>
<HTML>
<HEAD>
<TITLE><?php echo $LJSFi_VO; ?> Installation Release Matrix</TITLE>

<link rel="STYLESHEET" type="text/css" href="../ai.css">
<link rel="shortcut icon" href="../img/favicon.ico">

<script language="JavaScript" type="text/javascript">
<!--
function checkform(form) {
  var retval=true;
  if (form.relstat.value=='') {
    alert ('Please select a status to update the record');
    retval=false;
  }
  return retval;
}
//-->
</script>

</HEAD>
<BODY>
<P>
<?php } ?>
<?php
  require("db.php");
  require("combo.php");
  require("user_info.php");

  # Get the user role
  $sslusername = getenv("SSL_CLIENT_S_DN_CN");
  $ssluserdetails = getenv("SSL_CLIENT_S_DN");
  $user_info = get_user_info();
  if (count($user_info) == 0) {
    $role="";
  } else {
    $adminfk=$user_info[0]['ref'];
    $role=$user_info[0]['role'];
    $enabled=$user_info[0]['enabled'];
  }

?>
<?php if (!isset($_POST['ws']) or $_POST['ws'] == '') { ?>

<TABLE id='frame_tbl' border="1" rules="groups" width="2200" summary="Release matrix">
<COLGROUP width="200"></COLGROUP>
<COLGROUP width="1000"></COLGROUP>
<TR><TD width="100%" height="30" background="img/bar.gif" class="captionimg" colspan="2">
<CENTER><?php echo $LJSFi_VO; ?> Software Installation Release matrix</CENTER>
</TD></TR>
<TR><TD height="50" background="../img/bar3.gif">&nbsp;</TD>
<TD>
<form method="post" name="rs_form" action="">
<FONT COLOR="RED"><B>Search release name (use % as wildcard)<B></FONT>&nbsp;
<input type='text' name='name'>
<input type="submit" value="Search">
</form>
</TD></TR>
<TR><TD background="../img/bar3.gif" height="100%" valign="top">
<? include ("sidebar.php"); ?>
</TD><TD valign="top">

<TABLE border="2" frame="hsides" rules="groups"
          summary="<?php echo $LJSFi_VO; ?> Software release matrix.">
<COLGROUP align="left">
<COLGROUP align="center">
<COLGROUP align="center">
<COLGROUP align="left">
<COLGROUP align="center">
<COLGROUP align="left">
<COLGROUP align="left">
<COLGROUP align="left">
<COLGROUP align="left">
<COLGROUP align="left">
<COLGROUP align="left">
<COLGROUP align="left">
<THEAD valign="top">
<TR>
<TH>Release name
<TH>Arch
<TH>Build type
<TH>Software<BR>name
<TH>Status
<TH>Type
<TH>Requires
<TH>DB release
<TH>Size
<?php if ($role == "admin" || $role == "master") { ?>
<BR>(physical):(logical):(temp)
<?php } ?>
<BR>[GB]
<TH>Autoinstall
<TH>Installation<BR>phys path
<TH>Installation<BR>log path
<TH>Tag
<TBODY>
<?php } ?>
<?php
  $COLORS     = array ( 0 => '#0000FF'
                     ,  1 => '#7F7F7F'
                     , 10 => '#00FF00'
                     , 11 => '#FF0000'
                     , 20 => '#EF00EF'
                     , 21 => '#00EF00'
                     , 30 => '#DAA520'
                     , 31 => '#32CD32'
                     , 40 => '#F08080'
                     , 41 => '#F0E68C'
                      );
  $ISOBSOLETE = array (0 => 'production'
                     , 1 => 'obsolete'
                      );

  $ISENABLED = array();
  $result = db_query("SELECT ref,description FROM autoinstall_target ORDER BY ref");
  while ($row = mysql_fetch_array($result)) {
    $ISENABLED[$row[0]] = $row[1];
  }

  $reltypes = array();
  $result  = db_query("SELECT ref, description FROM release_type");
  while ( $row = mysql_fetch_array($result) ) {
    $reltypes[$row[0]] = $row[1];
  }

  $relnames = array();
  $result  = db_query("SELECT distinct(name) FROM release_data WHERE name <> 'ALL'");
  while ( $row = mysql_fetch_array($result) ) {
    array_push($relnames,$row[0]);
  }

  $relarch = array();
  $result = db_query("SELECT description FROM release_arch");
  while ( $row = mysql_fetch_array($result) ) {
    array_push($relarch,$row[0]);
  }

  // Check if we need to update the status
  if (isset($_REQUEST["id"]) && $_REQUEST["id"] != "" && ($role == "admin" || $role == "master")) {
    // Check for request integrity
    if ((!isset($_REQUEST['obsolete'])    || $_REQUEST['obsolete']=='') ||
        (!isset($_REQUEST['reltype'])     || $_REQUEST['reltype']=='') ||
        (!isset($_REQUEST['relreq'])      || $_REQUEST['relreq']=='') ||
        (!isset($_REQUEST['autoinstall']) || $_REQUEST['autoinstall']=='')) {
      echo 'One of the needed fields have not been provided.';
    } else {
      $updateqry  = "UPDATE release_data ";
      $updateqry .= "   SET obsolete="    . $_REQUEST['obsolete'];
      $updateqry .= "     , typefk="      . $_REQUEST['reltype'];
      $updateqry .= "     , autoinstall=" . $_REQUEST['autoinstall'];
      if (isset($_REQUEST['diskspace']) && $_REQUEST['diskspace'] != '')
          $updateqry .= "     , sw_diskspace='" . $_REQUEST['diskspace'] . "'";
      if ($_REQUEST["relreq"]=="NULL") {
        $updateqry .= "     , requires=NULL";
      } else {
        $updateqry .= "     , requires='" . $_REQUEST['relreq'] . "'";
      }
      $updateqry .= " WHERE ref=" . $_POST["id"];
      db_query($updateqry);

      # Send the notification email
      $_SERVER['FULL_URL'] = 'http';
      if($_SERVER['HTTPS']=='on') {
        $_SERVER['FULL_URL'] .=  's';
      }
      $_SERVER['FULL_URL'] .=  '://';
      $hn = $_SERVER['SERVER_NAME'];
      if($_SERVER['SERVER_PORT']!='80' && $_SERVER['SERVER_PORT']!='443') {
        $_SERVER['FULL_URL'] .=  $hn.':'.$_SERVER['SERVER_PORT'].$_SERVER['DOCUMENT_ROOT'];
      } else {
        $_SERVER['FULL_URL'] .=  $hn.$_SERVER['SCRIPT_NAME'];
      }
      $link=dirname($_SERVER['FULL_URL']) . "/rel.php?name=" . $_REQUEST["name"];
      $subj='[RELEASE CHANGE]'
           .' Release '.$_REQUEST["name"].' status changed';
      $body='The status of the release '.$_REQUEST["name"]
           .' has been modified by "'.$sslusername.'".'."\n"
           .'See '.$link.' for details.';
      $from = "From: LJSFi agent <".$LJSFi_email.">";
      $emailqry = "SELECT u.email FROM subscription s, user u"
                . " WHERE s.userfk=u.ref"
                . "   AND s.release=1";
      $result = db_query($emailqry);
      $to = "";
      while ($email = mysql_fetch_array($result)) {
        if ($to != "") {
          $to .= ','.$email[0];
        } else {
          $to  = $email[0];
        }
      }
      mail($to, $subj, $body, $from);
      header("Location: $HTTP_REFERER");
    }
  }

  if (!isset($_POST['ws']) or $_POST['ws'] == '') {
  # Query header
  $q_hdr  = ("SELECT release_data.ref
                    ,release_data.name
                    ,release_arch.description
                    ,release_data.build
                    ,release_data.sw_name
                    ,release_data.obsolete
                    ,release_data.typefk
                    ,release_data.requires as relreq
                    ,release_data.dbrelease
                    ,release_data.sw_diskspace
                    ,release_data.autoinstall
                    ,CONCAT(release_data.sw_physicalpath,'/',release_data.sw_versionarea)
                    ,CONCAT(release_data.sw_logicalpath,'/',IF (release_data.requires IS NULL,release_data.name,release_data.requires))
                    ,release_data.tag
                    ,release_data.archfk
                    ,release_type.category
                    ,release_data.kit_cache
                    ,(SELECT rd.sw_name FROM release_data rd WHERE rd.name=relreq)");
  $q_body = (" FROM release_data,release_arch,release_type
              WHERE     release_data.typefk=release_type.ref
                    AND release_data.archfk=release_arch.ref
                    AND release_data.typefk > 1");
  if (isset($_REQUEST['name']))     $q_body .= (" AND release_data.name LIKE '" . $_REQUEST['name'] . "'");
  if (isset($_REQUEST['obsolete'])) $q_body .= (" AND release_data.obsolete=" . $_REQUEST['obsolete']);

  # Get the number of records
  $limit  = 15;
  if (isset($_REQUEST['limit'])) $limit = $_REQUEST['limit'];
  $offset = 0;
  $query = ("SELECT count(*) " . $q_body);
  $result = db_query($query);
  $row = mysql_fetch_row($result);
  $records = $row[0];
  $maxpage = intval(($records-1)/$limit);
  $pagerange = 15;
  $page = 0;

  # Check the requested page
  if (isset($_GET['page'])) {
    $page = $_GET['page']-1;
    if ($page < 0) $page = 0;
    if ($page > $maxpage) $page = $maxpage;
    $offset = $page*$limit;
  }

  # Build the current GET string
  $getstr = "";
  foreach($_GET as $key=>$value) {
    if ($key != "page") {
      if ($getstr != "") $getstr = $getstr . "&";
      $getstr = $getstr . $key;
      if ($value != "") $getstr = $getstr . "=" . $value;
    }
  }

  # Fetch the given page
  $query  = ($q_hdr . $q_body);
  $query .= (" ORDER BY release_data.obsolete, release_data.autoinstall DESC, release_data.name ASC");
  $query .= (" LIMIT " . $offset . "," . $limit);
  if (isset($_GET['show'])) echo $query;
  $result = db_query($query);
  while ( $row = mysql_fetch_array($result) ) {
    if (($role == "admin" && ($row[11] == $adminfk || $row[11] == NULL)) || $role == "master") {
      echo '<form method="post" name="' . $row[0] . '" action="" onsubmit="return checkform(this);">';
    }
    echo ("<TR>");
    echo "\n";
    for ($i=1; $i<14; $i++) {
      $color = $row[5]+$row[10]*10;
      echo ("<TD nowrap bgcolor=" . $COLORS[$color] . ">");
      echo "\n";
      if ($i == 1) {
        if ($role == "admin" || $role == "master") {
          echo ("<input type='hidden' name='id' value='" . $row[0] . "'>\n");
          echo ("<input type='hidden' name='name' value='" . $row[1] . "'>\n");
        }
        $arch = preg_replace('/^_/','', $row[2]);
        preg_match('/([^:]*):([^:]*)/', $row[1], $pkgparts);
        if (isset($pkgparts[2])) { $pkgname = $pkgparts[2]; } else { $pkgname = $row[1]; }
        $logpath_parts = preg_split('/\//',$row[12]);
        $physpath_parts = preg_split('/\//',$row[11]);
        $lpath = $logpath_parts[count($logpath_parts)-1];
        $ppath = $physpath_parts[count($physpath_parts)-2];
        if ($ppath != "releases") {
            $lpath = preg_replace("/(:[^:]+)$/", "/latest", $lpath);
            $ppath .= "/".$physpath_parts[count($physpath_parts)-1];
        }
        echo ('<A HREF="'.$LJSFi_swinst_proto.'://'.$row[4].'/'.$pkgname.'/'.$arch.'/?install='.$pkgname.'&project-opt=opt&logical='.$lpath.'&physical='.$ppath);
        $insttype_parts = preg_split('/:/',$row[15]);
        echo ('&project-type='.$insttype_parts[0]);
        for ($indx=1; $indx<count($insttype_parts); $indx++) {
            if (isset($insttype_parts[$indx])) {
                echo ('&'.$insttype_parts[$indx]);
            }
        }
        if (isset($row[17])) echo ('&require-prj='.$row[17]);
        if (isset($row[8])) echo ('&dbrelease='.$row[8]);
        if (isset($row[16])) echo ('&kit-cache='.$row[16]);
        echo ('">');
        echo ($row[1]);
        echo ('</A>');
        echo "\n";
      } elseif ($i == 5) {
        if ($role == "admin" || $role == "master") {
          echo ("<select name='obsolete' size='1'>");
          echo "\n";
          for ($j=0; $j < count($ISOBSOLETE); $j++) {
            echo ('<option value="'.$j.'" ');
            if ($row[$i] == $j) echo ('selected');
            echo ('>'.$ISOBSOLETE[$j].'</option>');
            echo "\n";
          }
          echo '</select>';
          echo "\n";
        } else {
          echo ($ISOBSOLETE[$row[$i]]);
          echo "\n";
        }
      } elseif ($i == 6) {
        if ($role == "admin" || $role == "master") {
          echo ("<select name='reltype' size='1'>");
          echo "\n";
          foreach ($reltypes as $indx => $type) {
            echo ('<option value="'.$indx.'" ');
            if ($row[$i] == $indx) echo ('selected');
            echo ('>'.$type.'</option>');
            echo "\n";
          }
          echo '</select>';
          echo "\n";
        } else {
          echo ($reltypes[$row[$i]]);
          echo "\n";
        }
      } elseif ($i == 7) {
        if ($role == "admin" || $role == "master") {
          echo ("<select name='relreq' size='1'>");
          echo "\n";
          echo ('<option value="NULL" ');
          if (!isset($row[$i])) echo ('selected');
          echo ('>none</option>');
          echo "\n";
          foreach ($relnames as $name) {
            echo ('<option value="'.$name.'" ');
            if (isset($row[$i]) && $row[$i] == $name) echo ('selected');
            echo ('>'.$name.'</option>');
            echo "\n";
          }
          echo '</select>';
          echo "\n";
        } else {
          if (isset($relnames[$row[$i]])) echo ($relnames[$row[$i]]);
          echo "\n";
        }
      } elseif ($i == 9) {
        if ($role == "admin" || $role == "master") {
          echo ("<input name='diskspace' size='25' value='".$row[$i]."'>");
          echo "\n";
        } else {
          list ($phys, $logic, $temp) = split (':', $row[$i]);
          $val = sprintf('%3.1f', $phys/1048576);
          echo ($val);
          echo "\n";
        }
      } elseif ($i == 10) {
        if ($role == "admin" || $role == "master") {
          echo ("<select name='autoinstall' size='1'>");
          echo "\n";
          foreach ($ISENABLED as $indx => $name) {
            echo ('<option value="'.$indx.'" ');
            if ($row[10] == $indx) echo ('selected');
            echo ('>'.$ISENABLED[$indx].'</option>');
            echo "\n";
          }
          echo '</select>';
          echo "\n";
        } else {
          echo ($ISENABLED[$row[$i]]);
          echo "\n";
        }
      } elseif ($i == 12) {
        $parts = split('-', $row[$i]);
        if (count($parts)>1) $plist = array_pop($parts);
        echo (join('-',$parts));
      } else {
        echo ($row[$i]);
        echo "\n";
      }
      echo ("</TD>");
      echo "\n";
    }
    if ($role == "admin" || $role == "master") {
      echo '<TD><input type="submit" value="Update"></TD></form>';
    }
    echo ("</TR><TBODY>");
  }
  echo ("</TABLE><P>");

  # Show the legend for moving around the pages
  $min = $page-$pagerange;
  if ($min < 1) $min = 1;
  $max = $page+$pagerange;
  if ($max > ($maxpage+1)) $max = $maxpage+1;
  $pagestr = "<STRONG>Page number <";
  for ($i=$min; $i<=$max; $i++) {
     if ($i > $min) $pagestr =  ($pagestr . " ");
     if ($i == $page+1) {
       $pagestr =  ($pagestr . $i);
     } else {
       $pagestr =  ($pagestr . " <A HREF='?");
       if ($getstr != "") $pagestr = ($pagestr . $getstr . "&");
       $pagestr =  ($pagestr . "page=" . $i . "'>" . $i . "</A>");
     }
  }
  $pagestr = $pagestr . "></STRONG>";
  echo ('<TABLE border="0" frame="hsides" rules="groups"');
  echo ('<TR>' . $pagestr . '</TR></TABLE>');
  echo '<P>';
  echo( date("l, F dS Y, H:m:s") );
  }
?>
<?php if (!isset($_POST['ws']) or $_POST['ws'] == '') { ?>
</TD></TR></TABLE>
<P>
<A HREF="mailto:Alessandro.DeSalvo@roma1.infn.it">For comments or informations please drop me a mail (Alessandro.DeSalvo@roma1.infn.it)</A>
</BODY>
</HTML>
<?php } ?>
