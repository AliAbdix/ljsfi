<?php if (!isset($_POST['ws']) or $_POST['ws'] == '') { ?>
<?php require("config.php"); ?>
<HTML>
<HEAD>
<TITLE><?php echo $LJSFi_VO; ?> Installation Requests</TITLE>

<link rel="STYLESHEET" type="text/css" href="../ai.css">
<link rel="shortcut icon" href="../img/favicon.ico">

<script language="JavaScript" type="text/javascript">
<!--
function checkform(form) {
  var retval=true;
  if (form.reqstat.value=='') {
    alert ('Please select a status to update the record');
    retval=false;
  }
  return retval;
}
//-->
</script>

</HEAD>
<BODY>
<P>
<?php } ?>
<?php
  require("db.php");
  require("combo.php");
  require("config.php");
  require("user_info.php");
?>
<?php if (!isset($_POST['ws']) or $_POST['ws'] == '') { ?>

<TABLE id='frame_tbl' border="1" rules="groups" width="100%" summary="Mail subscriptions">
<COLGROUP width="800"></COLGROUP>
<TR><TD width="100%" height="30" background="img/bar.gif" class="captionimg">
<CENTER><?php echo $LJSFi_VO; ?> Software Installation Request list</CENTER>
</TD></TR>
<TR><TD height="30">&nbsp</TD></TR>
<TR><TD><CENTER>


<TABLE border="2" frame="hsides" rules="groups"
          summary="<?php echo $LJSFi_VO; ?> software deployment status.">
<COLGROUP align="left">
<COLGROUP align="center">
<COLGROUP align="center">
<COLGROUP align="left">
<COLGROUP align="center">
<COLGROUP align="left">
<COLGROUP align="left">
<COLGROUP align="left">
<COLGROUP align="left">
<COLGROUP align="left">
<COLGROUP align="left">
<THEAD valign="top">
<TR>
<TH>Request ID
<TH>Type
<TH>Release
<TH>CE name
<TH>Status
<TH>Request Time
<TH>Update Time
<TH>Requested by
<TH>Requester<BR>comments
<TH>Operator<BR>comments
<TH>Assigned to
<TBODY>
<?php } ?>
<?php
  $COLORS = array (1  => '#DDDDDD'
                 , 2  => '#DDDD00'
                 , 3  => '#FF0000'
                 , 4  => '#FF00FF'
                 , 5  => '#7F7FFF'
                 , 6  => '#00FF00'
                 , 7  => '#7F7F7F'
                 , 8  => '#A020F0'
                 , 9  => '#00FFFF'
                 , 10 => '#8B0000'
                  );

  $sslusername = getenv("SSL_CLIENT_S_DN_CN");
  $ssluserdetails = getenv("SSL_CLIENT_S_DN");
  $qryuser = "SELECT user.ref, role.description, user.priv_update FROM user,role WHERE name='" . $sslusername . "' AND dn='" . $ssluserdetails . "' AND user.rolefk=role.ref";
  $result = db_query($qryuser);
  $row = mysql_fetch_row($result);
  if (!$row) {
    $insuser = "INSERT INTO user SET name='".$sslusername."', dn='".$ssluserdetails."'";
    $addres  = db_query($insuser);
    $result  = db_query($qryuser);
    $row     = mysql_fetch_row($result);
  }
  if (!$row) {
    $role = "";
  } else {
    $adminfk     = $row[0];
    $role        = $row[1];
    $priv_update = $row[2];
  }

  $reqstat = array();
  $result = db_query("SELECT description FROM request_status");
  while ( $row = mysql_fetch_array($result) ) {
    array_push($reqstat,$row[0]);
  }

  $reqtypefk = array();
  $reqtype   = array();
  $result = db_query("SELECT ref, description FROM request_type");
  while ( $row = mysql_fetch_array($result) ) {
    array_push($reqtypefk,$row[0]);
    array_push($reqtype,$row[1]);
  }

  // Check if we need to update the status
  #if ($_POST["id"] != "" && ($role == "admin" || $role == "master")) {
  if (isset($_POST["id"]) && $_POST["id"] != "") {
    // Current date/time
    $date = date("Y-m-d H:i:s");
    $result = db_query("SELECT ref FROM request_status WHERE description='" . $_POST["reqstat"] . "'");
    $row = mysql_fetch_row($result);
    $reqstatfk = $row[0];
    $updateqry = "UPDATE request SET statusfk=" . $reqstatfk;
    if ($_POST["reqstat"]=="not assigned") {
      $updateqry = $updateqry . ", adminfk=NULL";
    } else {
      $updateqry = $updateqry . ", adminfk=" . $adminfk;
    }
    $updateqry = $updateqry . ", update_date='" . $date . "'";
    $updateqry = $updateqry . ", admin_comments='" . ereg_replace("'","\'", $_POST["admincomm"]) . "'";
    if (isset($_POST["reqtypefk"]) && $_POST["reqtypefk"] != "") $updateqry .= ", typefk=".$_POST["reqtypefk"];
    $updateqry = $updateqry . " WHERE id='" . $_POST["id"] . "'";
    $id = $_POST["id"];
    $_POST["id"] = "";
    db_query($updateqry);

    # Send the notification email
    $infoqry = "SELECT rt.field, rl.name, s.cename, s.name, r.admin_comments"
             . "  FROM request_type rt, request r, release_stat rl, site s"
             . " WHERE r.relfk=rl.ref"
             . "   AND r.sitefk=s.ref"
             . "   AND r.typefk=rt.ref"
             . "   AND r.id='".$id."'";
    $result = db_query($infoqry);
    $info=mysql_fetch_row($result);
    $taskqry = "SELECT task.description, task.name"
             . "  FROM release_data, task"
             . " WHERE release_data.name='".$info[1]."'"
             . "   AND task.ref=release_data.".$info[0];
    $taskres = db_query($taskqry);
    $taskdata=mysql_fetch_row($taskres);
    $subj='['.strtoupper($_POST["reqstat"]).'] '
         .$taskdata[1].' of '.$info[1].' at '.$info[2]
         .' ('.$info[3].')';
    $_SERVER['FULL_URL'] = 'http';
    if($_SERVER['HTTPS']=='on') {
      $_SERVER['FULL_URL'] .=  's';
    }
    $_SERVER['FULL_URL'] .=  '://';
    $hn = $_SERVER['SERVER_NAME'];
    if($_SERVER['SERVER_PORT']!='80' && $_SERVER['SERVER_PORT']!='443') {
      $_SERVER['FULL_URL'] .=  $hn.':'.$_SERVER['SERVER_PORT'].$_SERVER['DOCUMENT_ROOT'];
    } else {
      $_SERVER['FULL_URL'] .=  $hn.$_SERVER['SCRIPT_NAME'];
    }
    $link=dirname($_SERVER['FULL_URL']) . "/req.php?id=" . $id;
    $body='The status of request ID '.$id."\n"
         .'('.$taskdata[0].' of release '.$info[1]
         .' on CE '.$info[2].', site name '.$info[3].')'."\n"
         .'has been changed to "'.$_POST["reqstat"].'" '
         .'by "'.$sslusername.'".'."\n"
         .'Admin comments are "'.$info[4].'".'."\n"
         .'See '.$link.' for details.';
    $from = "From: LJSFi agent <".$LJSFi_email.">";
    $user_info = get_user_info("subscribers",NULL,NULL,True,$info[3]);
    $emails = array();
    foreach ($user_info as $user_data) { array_push($emails,$user_data["email"]); }
    $to = implode(",",$emails);
    //$emailqry = "SELECT u.email FROM subscription s, user u"
    //          . " WHERE s.userfk=u.ref"
    //          . "   AND (s.sitename='".$info[3]."' OR s.sitename='*')";
    //$result = db_query($emailqry);
    //$to = "";
    //while ($email = mysql_fetch_array($result)) {
    //  if ($to != "") {
    //    $to .= ','.$email[0];
    //  } else {
    //    $to  = $email[0];
    //  }
    //}
    if ($to != "") mail($to, $subj, $body, $from);
    header("Location: $HTTP_REFERER");
  }

  if (!isset($_POST['ws']) or $_POST['ws'] == '') {
  # Query header
  $q_hdr  = ("SELECT request.id
                    ,request_type.description
                    ,release_stat.name
                    ,site.cename
                    ,request_status.description
                    ,request.request_date
                    ,request.update_date
                    ,user.name
                    ,request.user_comments
                    ,request.admin_comments
                    ,request.statusfk
                    ,request.adminfk
                    ,user.email
                    ,site.cs
                    ,request.relfk
                    ,request.typefk");
  $q_body = (" FROM request,release_stat,site,user,request_type,request_status
              WHERE     request.sitefk=site.ref
                    AND request.userfk=user.ref
                    AND request.relfk=release_stat.ref
                    AND request.typefk=request_type.ref
                    AND request.statusfk=request_status.ref");
  if (isset($_GET['id']))     $q_body .= (" AND request.id='" . $_GET['id'] . "'");
  if (isset($_GET['status'])) $q_body .= (" AND request.statusfk=" . $_GET['status']);
  if (isset($_GET['rel']))    $q_body .= (" AND release_stat.name like '" . $_GET['rel'] . "'");
  if (isset($_GET['ce']))   $q_body .= (" AND site.cename like '" . $_GET['ce'] . "'");
  if (isset($_GET['site']))   $q_body .= (" AND site.name like '" . $_GET['site'] . "'");

  # Get the number of records
  $limit  = 20;
  $offset = 0;
  $query = ("SELECT count(*) " . $q_body);
  $result = db_query($query);
  $row = mysql_fetch_row($result);
  $records = $row[0];
  $maxpage = intval(($records-1)/$limit);
  $pagerange = 20;
  $page = 0;

  # Check the requested page
  if (isset($_GET['page'])) {
    $page = $_GET['page']-1;
    if ($page < 0) $page = 0;
    if ($page > $maxpage) $page = $maxpage;
    $offset = $page*$limit;
  }

  # Build the current GET string
  $getstr = "";
  foreach($_GET as $key=>$value) {
    if ($key != "page") {
      if ($getstr != "") $getstr = $getstr . "&";
      $getstr = $getstr . $key;
      if ($value != "") $getstr = $getstr . "=" . $value;
    }
  }

  # Fetch the given page
  $query  = ($q_hdr . $q_body);
  $query .= (" ORDER BY request.request_date DESC, site.cename");
  $query .= (" LIMIT " . $offset . "," . $limit);
  if (isset($_GET['show'])) echo $query;
  $result = db_query($query);
  while ( $row = mysql_fetch_array($result) ) {
    if (   ($role == "admin" && ($row[11] == $adminfk || $row[11] == NULL)) || $role == "master"
        || (isset($priv_update) && $priv_update == 1)) {
      echo '<form method="post" name="' . $row[0] . '" action="" onsubmit="return checkform(this);">';
    }
    echo ("<TR>");
    for ($i=0; $i<10; $i++) {
      echo ("<TD bgcolor=" . $COLORS[$row[10]] . ">");
      if ($i == 0) {
        echo ('<A HREF="../jobs.php?relfk='.$row[14].'">'.$row[0].'</A>');
        #if (($role == "admin" && ($row[11] == $adminfk || $row[11] == NULL)) || $role == "master") {
          echo ("<input type='hidden' name='id' value='" . $row[0] . "'>");
        #}
      } elseif ($i == 1) {
        if ($role == "master") {
          echo ("<select name='reqtypefk' size='1'>");
          for ($j=0; $j < count($reqtypefk); $j++) {
            echo ('<option value="'.$reqtypefk[$j].'" ');
            if ($row[15] == $reqtypefk[$j]) echo ('selected');
            echo ('>'.$reqtype[$j].'</option>');
          }
          echo '</select>';
        } else {
          echo ($row[$i]);
        }
      } elseif ($i == 4) {
        if (($role == "admin" && ($row[11] == $adminfk || $row[11] == NULL)) || $role == "master") {
          echo ("<select name='reqstat' size='1'>");
          combo_box($reqstat,"-- select one --",$row[$i]);
          echo '</select>';
        } else {
          echo ($row[$i]);
        }
      } elseif ($i == 9) {
        if (($role == "admin" && ($row[11] == $adminfk || $row[11] == NULL)) || $role == "master") {
          $val = htmlentities($row[9]);
          print "<input type='text' name='admincomm' value=\"" . $val . "\">";
        } else {
          echo ($row[$i]);
        }
      } else {
        if ($i == 3) echo ("<A HREF='site.php?cs=" . $row[13] . "'>");
        if ($i == 7) echo ("<A HREF='mailto:" . $row[12] . "'>");
        echo ($row[$i]);
        if ($i == 3 || $i == 7) echo ("</A>");
      }
      echo ("</TD>");
    }
    if ($row[11] != "") {
      $resqry = "SELECT user.name,user.email FROM user WHERE ref=" . $row[11];
      $resadm = db_query($resqry);
      $rowadm = mysql_fetch_row($resadm);
      echo ("<TD bgcolor=" . $COLORS[$row[10]] . ">");
      echo ("<A HREF='mailto:" . $rowadm[1] . "'>" . $rowadm[0] . "</A></TD>");
    } else {
      echo ("<TD bgcolor=" . $COLORS[$row[10]] . ">-</TD>");
    }
    if (($role == "admin" && ($row[11] == $adminfk || $row[11] == NULL)) || $role == "master") {
      echo '<TD><input type="submit" value="Update"></TD></form>';
    } else {
      if (isset($priv_update) && $priv_update == 1) {
        echo '<TD>';
        echo '<input type="hidden" name="reqstat" value="autorun">';
        echo '<input type="hidden" name="admincomm" value="Restarting the task">';
        echo '<input type="submit" value="Restart">';
        echo '</TD></form>';
      }
    }
    echo ("</TR><TBODY>");
  }
  echo ("</TABLE><P>");

  # Show a message for non-privileged users
  if (isset($priv_update) && $priv_update != 1) {
    echo '<FONT COLOR=RED><B>';
    echo 'You don\'t have permissions to restart the tasks. ';
    echo 'Please go <A HREF="user.php">here</A> and ask for the restart privilege if you need it.';
    echo '</B></FONT><BR>';
  }

  # Show the legend for moving around the pages
  $min = $page-$pagerange;
  if ($min < 1) $min = 1;
  $max = $page+$pagerange;
  if ($max > ($maxpage+1)) $max = $maxpage+1;
  $pagestr = "<STRONG>Page number <";
  for ($i=$min; $i<=$max; $i++) {
     if ($i > $min) $pagestr =  ($pagestr . " ");
     if ($i == $page+1) {
       $pagestr =  ($pagestr . $i);
     } else {
       $pagestr =  ($pagestr . " <A HREF='?");
       if ($getstr != "") $pagestr = ($pagestr . $getstr . "&");
       $pagestr =  ($pagestr . "page=" . $i . "'>" . $i . "</A>");
     }
  }
  $pagestr = $pagestr . "></STRONG>";
  echo ('<TABLE border="0" frame="hsides" rules="groups"');
  echo ('<TR>' . $pagestr . '</TR></TABLE>');
  echo '<P>';
  echo( date("l, F dS Y, H:m:s") );
  }
?>
<?php if (!isset($_POST['ws']) or $_POST['ws'] == '') { ?>
</CENTER></TD></TR></TABLE>
<P>
<A HREF="mailto:Alessandro.DeSalvo@roma1.infn.it">For comments or informations please drop me a mail (Alessandro.DeSalvo@roma1.infn.it)</A>
</BODY>
</HTML>
<?php } ?>
