<HTML>
<HEAD>

<script language="JavaScript" type="text/javascript">
<!--
function checkform(form) {
  var retval=true;
  var rows = pin_tbl.getElementsByTagName("tr");   
  for(i = 0; i < rows.length; i++){
    rows[i].style.backgroundColor='#EFEFEF';
  }
  if (form.sitename.value=='') {
    sitename_tr.style.backgroundColor='#FFFFAA';
    retval=false;
  }
  if (form.rel.value=='') {
    rel_tr.style.backgroundColor='#FFFFAA';
    retval=false;
  }
  if (!retval) {
    alert('Please fill all the highlighted fields');
  }

  return retval;
}

function pageReload() {
  pin.action='pin.php';
  pin.submit();
}

//-->
</script>

<?php
  require("db.php");
  require("config.php");
  require("user_info.php");
  require("combo.php");
?>

<TITLE>Pin management for the <?php echo $LJSFi_VO; ?> Software Installation System</TITLE>
</HEAD>

<link rel="STYLESHEET" type="text/css" href="../ai.css">
<link rel="shortcut icon" href="../img/favicon.ico">

<BODY>

<P>

<TABLE id='frame_tbl' border="1" rules="groups" width="100%" summary="Add or remove pins to installed releases">
<COLGROUP width="100"></COLGROUP>
<COLGROUP width="700"></COLGROUP>
<TR><TD width="100%" height="30" background="img/bar.gif" class="captionimg" colspan="2">
<CENTER>Add or remove pins to installed releases</CENTER>
</TD></TR>
<TR><TD height="50" background="../img/bar3.gif">&nbsp;</TD><TD>&nbsp;</TD></TR>
<TR><TD background="../img/bar3.gif" height="100%" valign="top">
<? include ("sidebar.php"); ?>
</TD><TD>
<CENTER>

<?php
  // Username
  $sslusername = getenv("SSL_CLIENT_S_DN_CN");
  $ssluserdetails = getenv("SSL_CLIENT_S_DN");
  if (!isset($_POST["user"]) || $_POST["user"] == "") $_POST["user"] = $sslusername;
  $user_info = get_user_info();
  if (count($user_info) == 0) {
    echo ("<FONT COLOR='RED' SIZE=+2><B>Unknown user. Please <A HREF='user.php'>register to LJSFi</A> first.</B></FONT>");
  } elseif ($user_info[0]['enabled'] == 0) {
    echo ("<FONT COLOR='RED' SIZE=+2><B>Your user is disabled. Please contact the LJSFi admin.</B></FONT>");
  } elseif ($user_info[0]['priv_pin'] == 0) {
    echo ("<FONT COLOR='RED' SIZE=+2><B>Insufficient privileges to pin releases. Please <A HREF='user.php'>update your registration</A>.</B></FONT>");
  } else {
    $user_data = $user_info[0];
?>
<form method="post" name="pin" action="pin.php" onsubmit="return checkform(this);">
<TABLE id='pin_tbl' border="1" rules="groups" summary="Add pins">
<CAPTION><EM><CENTER><FONT SIZE=+2>
<P>
</FONT></CENTER></EM></CAPTION>
<COLGROUP width="130"></COLGROUP>
<COLGROUP width="470"></COLGROUP>
<?php
    // Site name combo box
    echo ("<TR id='sitename_tr' class='graytable'><TD><EM>Site Name</EM></TD><TD>");
    echo ("<select name='sitename' size='1' onchange=\"pageReload();\">");
    $sitename=array();
    $query = "SELECT DISTINCT site.name"
           . "  FROM site"
           . " WHERE site.name <> ''"
           . " ORDER BY site.name";
    $result = db_query($query);
    while ($row = mysql_fetch_array($result)) {
      array_push($sitename, $row[0]);
    }
    combo_box($sitename,"-- select one --",$_POST["sitename"]);
    echo '</select></TD></TR>';
    echo '<TR class="graytable"><TD></TD><TD>Select a site name to list all the installed releases</TD></TR>';

    // Release name combo box
    if (isset($_POST["sitename"]) && $_POST["sitename"] != "") {
      echo ("<TR id='rel_tr' class='graytable'><TD><EM>Release Name</EM></TD><TD>");
      echo ("<select name='rel' size='1'>");
      $rel=array();
      $query = "SELECT DISTINCT(release_stat.name)"
             . "  FROM release_stat, site"
             . " WHERE release_stat.sitefk=site.ref"
             . "   AND site.name='".$_POST["sitename"]."'"
             . "   AND release_stat.status='installed'"
             . " ORDER BY release_stat.name";
      $result = db_query($query);
      while ($row = mysql_fetch_array($result)) {
        array_push($rel, $row[0]);
      }
      combo_box($rel,"-- select one --",$_POST["rel"]);
      echo '</select></TD></TR>';
    }

  
    if (isset($_POST['add'])) {
      # Get the user id
      $userfk = $user_data['ref'];
      # Add the pin
      if ($userfk >= 0 && isset($_POST["sitename"]) && $_POST["sitename"] != ''
                       && isset($_POST["rel"]) && $_POST["rel"] != '') {
        $pinquery = "SELECT release_stat.ref"
                  . "  FROM release_stat, site"
                  . " WHERE release_stat.sitefk=site.ref"
                  . "   AND site.name='".$_POST["sitename"]."'"
                  . "   AND release_stat.name='".$_POST["rel"]."'"
                  . "   AND pin=0";
        $res = db_query($pinquery);
        $numrows = mysql_num_rows($res);
        echo '<TR><TD>&nbsp;</TD><TD>';
        if ($numrows > 0) {
          $date = date("Y-m-d H:i:s");
          $query = "UPDATE release_stat"
                 . "   SET pin=1, pinuserfk=".$userfk.", pindate='".$date."'"
                 . " WHERE release_stat.name='".$_POST["rel"]."'"
                 . "   AND sitefk in ("
                 . "SELECT ref"
                 . "  FROM site"
                 . " WHERE site.name='".$_POST["sitename"]."'"
                 . ")";
          $res = db_query($query);
          echo 'You have successfully pinned release '.$_POST["rel"].' in '.$_POST["sitename"];

          # Send the notification email
          $subj='[PIN ADD] Pin added for release '.$_POST["rel"].' in site '.$_POST["sitename"];
          $body='A pin for release '.$_POST["rel"].' in site '.$_POST["sitename"]
               .' has been added by '.$_POST["user"]." <".$user_data['email'].">\n";
          $from = "From: LJSFi agent <".$LJSFi_email.">";
          $user_info = get_user_info("subscribers",NULL,NULL,True,$_POST["sitename"]);
          $emails = array();
          foreach ($user_info as $user_data) { array_push($emails,$user_data["email"]); }
          $to = implode(",",$emails);
          if ($to != "") mail($to, $subj, $body, $from);

        } else {
          echo 'Release '.$_POST["rel"].' is already pinned in '.$_POST["sitename"];
        }
        echo '</TD></TR>';
      }
    }
?>
</TABLE>
<input type="submit" name="add" value="Add">
</form>

<?php if (isset($_POST["sitename"]) && $_POST["sitename"] != "") { ?>
<form method="post" name="updatepin" action="pin.php">
<TABLE border="1" rules="groups" summary="Remove pins">
<CAPTION><EM><CENTER><FONT SIZE=+2>
Pins in <?php echo $_POST["sitename"]; ?>
<P>
</FONT></CENTER></EM></CAPTION>
<COLGROUP width="500"></COLGROUP>
<TR class="graytable"><TD colspan="2">
<?php
    if (isset($_POST['remove'])) {
      # Check for the user id
      $userfk = $user_data['ref'];
      # Remove the pins
      if ($userfk >= 0) {
        while (list ($key,$val) = @each ($_POST['pins'])) {
          $pinquery = "SELECT release_stat.ref"
                    . "  FROM release_stat, site"
                    . " WHERE release_stat.sitefk=site.ref"
                    . "   AND site.name='".$_POST["sitename"]."'"
                    . "   AND release_stat.name='".$val."'"
                    . "   AND pin=1";
          $res = db_query($pinquery);
          $numrows = mysql_num_rows($res);
          echo '<CENTER>';
          if ($numrows>0) {
            $date = date("Y-m-d H:i:s");
            $query = "UPDATE release_stat"
                   . "   SET pin=0, pinuserfk=".$userfk.", pindate='".$date."'"
                   . " WHERE release_stat.name='".$val."'"
                   . "   AND sitefk in ("
                   . "SELECT ref"
                   . "  FROM site"
                   . " WHERE site.name='".$_POST["sitename"]."'"
                   . ")";
            $res = db_query($query);
            echo 'You have successfully removed the pin for release '.$val.' in '.$_POST["sitename"];
            # Send the notification email
            $subj='[PIN REMOVE] Pin removed for release '.$val.' in site '.$_POST["sitename"];
            $body='The pin for release '.$val.' in site '.$_POST["sitename"]
                 .' has been removed by '.$_POST["user"]." <".$user_data['email'].">\n";
            $from = "From: LJSFi agent <".$LJSFi_email.">";
            $user_info = get_user_info("subscribers",NULL,NULL,True,$_POST["sitename"]);
            $emails = array();
            foreach ($user_info as $user_data) { array_push($emails,$user_data["email"]); }
            $to = implode(",",$emails);
            if ($to != "") mail($to, $subj, $body, $from);

          } else {
            echo 'Release '.$val.' is not pinned in '.$_POST["sitename"];
          }
          echo '</CENTER></TD></TR>';
          echo '<TR><TD colspan="2"><HR>';
        }
      }
    }
?>
<TABLE border="0" rules="groups" summary="Pin list">
<COLGROUP width="150"></COLGROUP>
<COLGROUP width="200"></COLGROUP>
<COLGROUP width="150"></COLGROUP>
<COLGROUP width="100"></COLGROUP>
<TH align="left">Release</TH>
<TH align="left">Pinned by</TH>
<TH align="left">Date</TH>
<TH align="center">Remove</TH>
<TBODY>
<?php
    // Current pins
    $colors = array('#DFFFDF','#DFDFFF');
    $query = "SELECT DISTINCT(release_stat.name), user.name, release_stat.pindate"
           . "  FROM release_stat, site, user"
           . " WHERE release_stat.sitefk = site.ref"
           . "   AND release_stat.pinuserfk = user.ref"
           . "   AND site.name = '".$_POST["sitename"]."'"
           . "   AND release_stat.pin = 1"
           . " ORDER BY release_stat.name";
    $result = db_query($query);
    $indx   = 0;
    while ($row = mysql_fetch_array($result)) {
      echo '<TR><TD bgcolor="'.$colors[$indx%2].'">';
      echo $row[0];
      echo '</TD><TD bgcolor="'.$colors[$indx%2].'">';
      echo $row[1];
      echo '</TD><TD bgcolor="'.$colors[$indx%2].'">';
      echo $row[2];
      echo '</TD><TD bgcolor="'.$colors[$indx%2].'"><CENTER>';
      echo '<input type=checkbox name=pins[] value="'.$row[0].'">';
      echo '</CENTER></TD></TR>';
      $indx += 1;
    }
    echo '</TABLE>';
?>

</TD></TR></TABLE>
<input type="hidden" name="sitename" value="<?php echo $_POST["sitename"]; ?>">
<input type="submit" name="remove" value="Remove">
</form>
<?php
  }
}
?>

</CENTER></TD></TR></TABLE>

<P>
<A HREF="mailto:Alessandro.DeSalvo@roma1.infn.it">For comments or informations please drop me a mail (Alessandro.DeSalvo@roma1.infn.it)</A>
<BR>
</BODY>
</HTML>
