<?php
require('db.php');        // database connect script.
require('config.php');    // Main configuration
require('user_info.php'); // User informations
?>

<HTML>
<HEAD>
<TITLE><?php echo $LJSFi_VO; ?> Installation System - Release Definition</TITLE>

<link rel="STYLESHEET" type="text/css" href="../ai.css">
<link rel="shortcut icon" href="../img/favicon.ico">

<script type="text/javascript">
function openpop(url) {
    newWin = window.open(url,'Details','scrollbars=no,resizable=yes, width=300,
height=300,status=no,location=no,toolbar=no');
}
function closeWin() {
    self.close();
}
</script>

</HEAD>
<BODY>
<script type="text/javascript" src="../js/wz_tooltip.js"></script>
<P>

<TABLE id='ai_tbl' border="1" cellspacing="0" cellpadding="10" rules="groups" width="100%" summary="<?php echo $LJSFi_VO; ?> Installation Web Pages">
<COLGROUP width="220"></COLGROUP>
<COLGROUP></COLGROUP>
<TR><TD colspan="2" background="../img/bar.gif" height="10" class="captionimg">
<CENTER>
<?php echo $LJSFi_VO; ?> Installation Pages - Release Definition
</CENTER>
</TD></TR>
<TR><TD height="50" background="../img/bar3.gif">&nbsp;</TD><TD>&nbsp;</TD></TR>
<TR><TD background="../img/bar3.gif" height="100%" valign="top">
<? include ("sidebar.php"); ?>
</TD><TD>
<CENTER>
<IMG SRC="../img/sw_inst_icon.png" HEIGHT="150"><P>
<?php
  // Check the user's credentials
  $sslusername = getenv("SSL_CLIENT_S_DN_CN");
  $ssluserdetails = getenv("SSL_CLIENT_S_DN");
  $user_info = get_user_info();
  if (count($user_info) == 0) {
    $role="";
  } else {
    $userref = $user_info[0]['ref'];
    $role=$user_info[0]['role'];
    $enabled=$user_info[0]['enabled'];
  }

  if (!isset($userref)) {
    echo ("<FONT SIZE=+1 COLOR='red'><B>Unknown user. Please <A HREF='user.php'>register to LJSFi.</A></B></FONT>\n");
  } elseif ($enabled == 0) {
    echo ("<FONT SIZE=+1 COLOR='red'><B>Your user is disabled. Please contact the LJSFi administrator.</B></FONT>\n");
  } elseif ($role != "admin" && $role != "master") {
    echo ("<FONT SIZE=+1 COLOR='red'><B>You don't have enough privileges to manage releases</B></FONT>");
  } else {
    if (isset($_POST["mode"]) && $_POST["mode"] == "define") echo "<CENTER><FONT SIZE=+1 COLOR='GREEN'><B>New release definition</B></FONT></CENTER>\n";
    if (isset($_POST["mode"]) && $_POST["mode"] == "update") echo "<CENTER><FONT SIZE=+1 COLOR='GREEN'><B>Release data update</B></FONT></CENTER>\n";
?>
<TABLE id='select_tbl' border="1" rules="groups">
<COLGROUP></COLGROUP>
<COLGROUP width="350"></COLGROUP>
<COLGROUP></COLGROUP>
<?php
    if (isset($_POST['relsrc'])) {
      if (   isset($_POST["mode"]) && ($_POST["mode"] == "define" || $_POST["mode"] == "update")
          && isset($_POST["submit"]) && $_POST["submit"] == "Save" ) {
        // Check for needed fields
        if (!isset($_POST['reldef_name']) || $_POST['reldef_name'] == "") {
          echo "<FONT COLOR='RED' SIZE=+1><B>No release name specified</B></FONT>";
        } else {
          // Save the release definition in the Database
          $field_list = array();
          $value_list = array();
          $field_ext_list = array();
          foreach ($_POST as $field => $value) {
            // Process the main table
            if (substr($field,0,7) == "reldef_") {
              array_push($field_list,substr($field,7));
              if ($value == "") {
                array_push($value_list,'NULL');
              } else {
                array_push($value_list,'"'.addslashes($value).'"');
              }
            }
            // Process the extension table
            if (substr($field,0,7) == "relext_" && $value != "") $field_ext_list[substr($field,7)] = $value;
          }
          // Main table
          if ($_POST["mode"] == "define") {
            $query = "INSERT INTO release_data (".implode(',',$field_list).") VALUES (".implode(',',$value_list).")";
          } else {
            $query_fields = array();
            foreach ($value_list as $key => $value) array_push($query_fields,$field_list[$key]."=".$value."");
            $query = "UPDATE release_data SET ".implode(',',$query_fields)." WHERE name='".$_POST["reldef_name"]."'";
          }
          db_query($query);
          // Read the release definition and get the id
          $query = "SELECT ref FROM release_data WHERE name='".$_POST["reldef_name"]."'";
          $qry_res = db_query($query);
          $row = mysql_fetch_row($qry_res);
          if (!isset($row[0])) {
            // No id found for the release, insert failed
            echo "Release definition failed";
          } else {
            // Extension table
            foreach ($field_ext_list as $key => $value) {
              $extquery = "SELECT ref FROM release_data_ext WHERE relfk=".$row[0]." AND fieldfk=".$key;
              $qry_res = db_query($extquery);
              $extrow = mysql_fetch_row($qry_res);
              if (isset($extrow[0])) {
                $extquery = "UPDATE release_data_ext SET value='".$value."' WHERE ref=".$extrow[0];
              } else {
                $extquery = 'INSERT INTO release_data_ext (relfk, fieldfk, value) VALUES ('.$row[0].','.$key.',"'.$value.'")';
              }
              db_query($extquery);
            }
            // Insert done
            if ($_POST["mode"] == "define") {
              echo "Release definition completed successfully";
            } else {
              echo "Release ".$_POST["reldef_name"]." updated successfully";
            }
          }
        }
      } else {
        echo ('<form method="post" name="reldef" action="reldef.php">');
        // Get the field descriptions of the main table
        $qry_res = db_query("SELECT field_name, description, help, show_def FROM field_descriptions WHERE table_name='release_data'");
        $field_desc = array();
        while ($row = mysql_fetch_row($qry_res)) {
          if (isset($row[2])) { $field_help = $row[2]; } else { $field_help = NULL; }
          $field_desc[$row[0]] = array("description" => $row[1], "help" => $field_help, "show_def" => $row[3]);
        }
        // Get the field relations
        $qry_res = db_query("SELECT field1,table2,description FROM field_relations WHERE table1='release_data'");
        $foreign_keys = array();
        while ($row = mysql_fetch_row($qry_res)) {
          $qry_res1 = db_query("SELECT ref, ".$row[2]." FROM ".$row[1]);
          while ($row1 = mysql_fetch_row($qry_res1)) {
            if (!isset($foreign_keys[$row[0]])) { $foreign_keys[$row[0]] = array(); }
            array_push($foreign_keys[$row[0]],array($row1[0],$row1[1]));
          }
        }
        // Get the default data for the main table
        $query = "SELECT * FROM release_data";
        $where = array();
        if ($_POST['relsrc'] != "") array_push($where, "release_data.name='".$_POST['relsrc']."'");
        if (count($where) > 0) $query .= " WHERE ".implode(' AND ',$where);
        $query .= " ORDER BY date DESC LIMIT 1";
        $qry_res = db_query($query);
        $row = mysql_fetch_row($qry_res);
        $columns = mysql_num_fields($qry_res);
        for ($i=0; $i<$columns; $i++) {
          $field_name = mysql_field_name($qry_res,$i);
          if (isset($field_desc[$field_name]) && $field_desc[$field_name]["show_def"] == 1) {
            echo ('<tr><td class="selection">');
            if (isset($field_desc[$field_name]["help"])) {
              echo ('<img src="../img/help.gif" border="0"');
              echo ('onmouseover="Tip(\''.addslashes($field_desc[$field_name]["help"]).'\')" onmouseout="UnTip()"');
              echo ('>');
            }
            echo ('</td><td class="selection">');
            if (isset($field_desc[$field_name])) { echo ($field_desc[$field_name]["description"]); } else { echo ($field_name); }
            echo ("</td><td>");
            if ($_POST['relsrc'] != "") $defval = $row[$i]; else $defval = "";
            if ($field_name == "date" && $_POST['mode'] == "define") $defval = date("Y-m-d H:i:s");
            if (isset($foreign_keys[$field_name])) {
              echo ('<select name="reldef_'.$field_name.'">');
              $optcount = 0;
              foreach ($foreign_keys[$field_name] as $fk) {
                echo ('<option value="'.$fk[0].'"');
                if ($fk[0] == $defval || ($defval == "" && $optcount == 0)) { echo " selected "; }
                echo ('>'.$fk[1].'</option>');
                $optcount++;
              }
              echo ('</select>');
            } else {
              if ($field_name == "userfk") {
                echo ('<input type="hidden" name="reldef_userfk" value="'.$userref.'">'.$sslusername);
              } else {
                echo ('<input type="text" name="reldef_'.$field_name.'" size="30" value="'.$defval.'">');
              }
            }
            echo ("</td></tr>\n");
          }
        }
        // Get the default data for the extension table
        $query = "SELECT field_descriptions.ref AS fid, field_name, value, show_def, description, help FROM field_descriptions LEFT OUTER JOIN release_data_ext ON release_data_ext.fieldfk = field_descriptions.ref";
        $where = array("table_name = 'release_data_ext'");
        if ($_POST['relsrc'] != "") $query .= " AND release_data_ext.relfk = (SELECT ref FROM release_data WHERE name ='".$_POST['relsrc']."')";
        if (count($where) > 0) $query .= " WHERE ".implode(' AND ',$where);
        $query .= " ORDER BY field_descriptions.field_name DESC LIMIT 1";
        $qry_res = db_query($query);
        while ($row = mysql_fetch_assoc($qry_res)) {
          if ($row['show_def'] == 1) {
            if (isset($row['description']) && $row['description'] != "") $field_name = $row['description']; else $field_name = $row['field_name'];
            echo ('<tr><td class="selection">');
            if (isset($row['help']) && $row['help'] != "") {
              echo ('<img src="../img/help.gif" border="0"');
              echo ('onmouseover="Tip(\''.addslashes($row['help']).'\')" onmouseout="UnTip()">');
            }
            echo ('</td><td class="selection">'.$field_name);
            echo ("</td><td>");
            echo ('<input type="text" name="relext_'.$row['fid'].'" size="30" value="'.$row['value'].'">');
            echo ("</td></tr>\n");
          }
        }
        $action = "Save";
        echo ('<input type="hidden" name="mode" value="'.$_POST["mode"].'">');
        echo ('<input type="hidden" name="relsrc" value="'.$_POST['relsrc'].'">');
      }
    } else {
      // Source selection
      echo ('<form method="post" name="srcsel" action="reldef.php">');
      if (isset($_REQUEST["mode"]) && $_REQUEST["mode"] == "update") {
        echo ('<tr><td class="selection" colspan="3">Please select the release to update</td></tr><tr><td colspan="3">');
      } else {
        
        echo ('<tr><td class="selection" colspan="3">Please select the definition source</td></tr><tr><td colspan="3">');
      }
      echo ('<center>');
      echo ('<select name="relsrc">');
      $rowsel=0;
      if (isset($_REQUEST["mode"]) && $_REQUEST["mode"] == "define") echo ('<option value="">- new -</option>');
      $qry_res = db_query("SELECT ref,name FROM release_data ORDER BY date DESC");
      while ($row = mysql_fetch_row($qry_res)) {
        if ($row[0] == $rowsel) {
          echo ('<option value="'.$row[1].'" selected>'.$row[1].'</option>');
        } else {
          if (isset($_REQUEST["mode"]) && $_REQUEST["mode"] == "update") {
            echo ('<option value="'.$row[1].'">'.$row[1].'</option>');
          } else {
            echo ('<option value="'.$row[1].'">Clone release '.$row[1].'</option>');
          }
        }
      }
      echo ('</select>');
      echo ('</center>');
      if (isset($_REQUEST["mode"]) && $_REQUEST["mode"] == "update") {
        echo ('<input type="hidden" name="mode" value="update">');
      } else {
        echo ('<input type="hidden" name="mode" value="define">');
      }
      $action = "Select";
    }
  }
?>
</td></tr>
</TABLE>
<P>

<?php if (isset($action)) { ?>
<input type="submit" name="submit" value="<?php echo $action; ?>">
<input type="reset" name="reset" value="Reset">
</form>
<?php } ?>
</CENTER>
</TD></TR>
<TR><TD height="30" background="../img/bar2.gif">&nbsp;</TD><TD>&nbsp;</TD></TR>
</TABLE>

<P>
<A HREF="mailto:Alessandro.DeSalvo@roma1.infn.it">For comments or informations please send me a mail (Alessandro.DeSalvo@roma1.infn.it)</A>
<BR>
</BODY>
</HTML>
