<?php ?>
<?php require("config.php"); ?>
<div class="sidebarText" align="left">
Actions
</div>
<div class="sidebarLink" align="left">
<A HREF="" title="Main page">
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="12">
Home page
</A></div>
<div class="sidebarLink" align="left">
<A HREF="protected/user.php" title="User registration">
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="12">
User registration
</A></div>
<div class="sidebarLink" align="left">
<A HREF="protected/rai.php" title="Request an installation">
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="12">
Request an installation
</A></div>
<div class="sidebarLink" align="left">
<A HREF="protected/pin.php" title="Pin an installed release">
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="12">
Pin a release
</A></div>
<div class="sidebarLink" align="left">
<A HREF="protected/subscribe.php" title="Subscribe to email notifications">
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="12">
Mail subscriptions
</A></div>
<div class="sidebarLink" align="left">
<A HREF="protected/req.php" title="Show the installation requests">
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="12">
Show requests
</A></div>
<div class="sidebarLink" align="left">
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="12">
Releases
<!-- <img align="absmiddle" src="../img/new.gif" border="0" height="30"> -->
<ul>
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="12">
<A HREF="protected/reldef.php?mode=define" title="Define a new release">
Definition
</A><BR>
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="12">
<A HREF="protected/reldef.php?mode=update" title="Update a release definition">
Update
</A><BR>
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="12">
<A HREF="protected/rel.php" title="Show the release matrix">
Matrix
</A><BR>
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="12">
<A HREF="protected/pardef.php" title="Release parameters management">
Parameters
</A>
</ul>
</div>
<div class="sidebarLink" align="left">
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="12">
Sites
<ul>
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="12">
<A HREF="protected/sitedef.php?mode=define" title="Define a new site">
Definition
</A><BR>
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="12">
<A HREF="protected/sitedef.php?mode=update" title="Update a site definition">
Update
</A><BR>
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="12">
<A HREF="protected/sitedef.php?mode=delete" title="Remove a site">
Removal
</A><BR>
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="12">
<A HREF="protected/sitepardef.php" title="Site parameters management">
Parameters
</A>
</ul>
</div>
<div class="sidebarLink" align="left">
<A HREF="protected/tags.php" title="Show the tags matrix">
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="12">
Tags matrix
</A></div>
<div class="sidebarLink" align="left">
<A HREF="firefox" title="Download the <?php echo $LJSFi_VO; ?> Firefox plugin for software installation">
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="12">
Firefox plugin
</A></div>
<HR>
<div class="sidebarLink" align="center">
Powered by<BR>
<img align="absmiddle" src="img/LJSFi_logo_4.gif" border="0" hspace="8" width="120">
</div>
<?php ?>
