<HTML>
<HEAD>
<TITLE>Site Info Viewer</TITLE>

<link rel="STYLESHEET" type="text/css" href="ai.css">
<link rel="shortcut icon" href="img/favicon.ico">

<style>
TR {background-color: #CCCCCC;}
TD {width: 150;}
</style>

</HEAD>
<BODY>
<P>
<?php
  require("combo.php");
  require("db.php");
?>

<TABLE border="2" frame="hsides" rules="groups"
          summary="Atlas Installation: site view">
<CAPTION><EM><FONT SIZE=+2>Atlas Software Installation: site view</FONT></EM></CAPTION>
<COLGROUP align="left">
<COLGROUP align="left">
<THEAD valign="top">
<TBODY>

<?php
  $COLORS = array (1 => '#DDDDDD'
                 , 2 => '#00FF00'
                 , 3 => '#FF0000'
                 , 4 => '#FF00FF'
                 , 5 => '#AADD88'
                  );
  $DBFIELDS = array ('cename'   => 'cename'
                   , 'sitename' => 'name'
                   , 'cs'       => 'cs');

  $qry = "SELECT name,cename,cs,osname,osrelease,osversion,arch FROM site";
  $first = true;
  foreach ($_GET as $key => $val) {
    if ($first) {
      $qry .= " WHERE ";
      $first = false;
    } else {
      $qry .= " AND ";
    }
    if (isset($DBFIELDS[$key])) $qry .= $DBFIELDS[$key] . "='" . $val . "'"; 
  }
  $result = db_query($qry);
  $numrows = mysql_num_rows($result);
  if ($numrows == 1) {
    $row = mysql_fetch_row($result);
    echo '<TR><TD><EM>Site Name</EM></TD><TD>'    . $row[0] . '</TD></TR>';
    echo '<TR><TD><EM>CE FQDN</EM></TD><TD>'      . $row[1] . '</TD></TR>';
    echo '<TR><TD><EM>Resource</EM></TD><TD>'     . $row[2] . '</TD></TR>';
    echo '<TR><TD><EM>OS Name</EM></TD><TD>'      . $row[3] . '</TD></TR>';
    echo '<TR><TD><EM>OS Release</EM></TD><TD>'   . $row[4] . '</TD></TR>';
    echo '<TR><TD><EM>OS Version</EM></TD><TD>'   . $row[5] . '</TD></TR>';
    echo '<TR><TD><EM>Install Arch</EM></TD><TD>' . $row[6] . '</TD></TR>';
  } else {
    echo '<form name="site" method="get" action="">';
    echo '<TR><TD><EM>Please select a CE FQDN</EM></TD><TD>';
    $cenames = array();
    while ($row = mysql_fetch_array($result)) {
      array_push($cenames, $row[1]);
    }
    echo '<select name="',cename,'" size="1" onchange="document.site.submit();">';
    combo_box ($cenames);
    echo '</select></TD>';
  }
?>
</TABLE>
<?php
  echo( date("l, F dS Y, H:m:s") );
?>
<P>
<A HREF="mailto:Alessandro.DeSalvo@roma1.infn.it">For comments or informations please drop me a mail (Alessandro.DeSalvo@roma1.infn.it)</A>
</BODY>
</HTML>
