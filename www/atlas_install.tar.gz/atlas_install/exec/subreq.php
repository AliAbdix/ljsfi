<?php
  require("guid.php");
  require("db.php");
  function send_mail($link,$guid) {
    /*
    $infoqry = "SELECT rt.field, rl.name, s.cename, s.name, r.admin_comments"
             . "  FROM request_type rt, request r, release rl, site s"
             . " WHERE r.relfk=rl.ref"
             . "   AND r.sitefk=s.ref"
             . "   AND r.typefk=rt.ref"
             . "   AND r.id='".$guid."'";
    $result = db_query($infoqry);
    $info=mysql_fetch_row($result);
    $emailqry = "SELECT u.email FROM subscription s, user u"
              . " WHERE s.userfk=u.ref"
              . "   AND (s.sitename='".$info[3]."' OR s.sitename='*')";
    $result = db_query($emailqry);
    $to = "";
    while ($email = mysql_fetch_array($result)) {
      if ($to != "") {
        $to .= ','.$email[0];
      } else {
        $to  = $email[0];
      }
    }
    */

    $to = "Alessandro.DeSalvo@roma1.infn.it";
    //$to = $to . ",Alex.Barchiesi@roma1.infn.it";
    //$to = $to . ",k.gnanvo@qmul.ac.uk";
    //$to = $to . ",kennedyj@mail.cern.ch";
    //$to = $to . ",gernot.krobath@physik.uni-muenchen.de";
    //$to = $to . ",Andrzej.Olszewski@ifj.edu.pl";
    //$to = $to . ",gwilliam@hep.ph.liv.ac.uk";
    //$to = $to . ",Grigori.Rybkine@rhul.ac.uk";

    $from_header = "From: nobody <no-reply@atlas-install.roma1.infn.it>";
    $contents = "Dear Atlas SGM,\n";
    $contents = $contents . "a request for installation/manteinance has been submitted by\n";
    $contents = $contents . $_POST["user"] . " <" . $_POST["email"] . ">\n";
    $contents = $contents . "on " . date("l, F dS Y, H:m:s") . "\n";
    $contents = $contents . "The request concerns an operation on release '". $_POST["rel"] . "'";
    if ($_POST["rel"] == 'other') $contents = $contents . " (" . $_POST["relnew"] . ").";
    $contents = $contents . "\n";
    $contents = $contents . "on the CE " . $_POST["cename"] . ", indentified by\n";
    $contents = $contents . $_POST["cs"] . "\n";
    $contents = $contents . "Additional comments are reported below:\n------------\n" . $_POST["comments"] . "\n------------\n";
    $contents = $contents . "Additional info is available from the URL below:\n\n" . $link;
    $contents = $contents . "\n\nPlease process this request as soon as possible.\nBest regards.";
    $subject  = "Installation request for release " . $_POST["rel"] . " at " . $_POST["cename"];
 
    if($contents != "") {
      mail($to, $subject, $contents, $from_header);
      header("Location: $HTTP_REFERER");
    } else {
      print("Error, no mail submitted!");
    }
  }

  function check_pin() {
    $pinval=0;
    $qry = "SELECT release.pin "
            ."FROM release, site "
           ."WHERE release.sitefk = site.ref "
             ."AND site.cename = '".$_POST["cename"]."' "
             ."AND release.name='".$_POST["rel"]."'"
             ."AND release.status<>'removed'";
    $res = db_query($qry);
    $row = mysql_fetch_row($res);
    if ($row) $pinval = $row[0];
    return $pinval;
  }

  function check_requirements() {
    // Process the requirements
    $requirementsok = 1;   // By default the requirements are satisfied
    $qry = "SELECT rd.requires FROM release_data rd WHERE rd.name='".$_POST["rel"]."' LIMIT 1";
    $res = db_query($qry);
    while ($row = mysql_fetch_array($res)) {
      if (isset($row[0]) && $row[0] != "") {
        $requires = $row[0];
        $requirementsok = 0;
        if (isset($_POST["sitename"]) && $_POST["sitename"] != "") {
          $qryreq = "SELECT release.status FROM release, site"
                  . " WHERE release.name = '".$requires."'"
                  .   " AND release.sitefk = site.ref"
                  .   " AND site.name = '".$_POST["sitename"]."'";
          $resreq = db_query($qryreq);
          while ($row = mysql_fetch_array($resreq)) {
            if (isset($row[0]) && strtolower($row[0]) == "installed") $requirementsok = 1;
          }
        }
      }
    }
    return $requirementsok;
  }

  function check_required() {
    // Process the requirements
    $requiredby = "";   // By default the release is not required by anybody
    $qry = "SELECT rd.name FROM release_data rd WHERE rd.requires='".$_POST["rel"]."'";
    $res = db_query($qry);
    while ($row = mysql_fetch_array($res)) {
      if (isset($row[0]) && $row[0] != "") {
        $relnum = $row[0];
        if (isset($_POST["sitename"]) && $_POST["sitename"] != "") {
          $qryreq = "SELECT release.status FROM release, site"
                  . " WHERE release.name = '".$relnum."'"
                  .   " AND release.sitefk = site.ref"
                  .   " AND (site.name = '".$_POST["sitename"]."'";
          if (isset($_POST["cs"]) && $_POST["cs"] != "") {
            $qryreq .= " OR site.cs = '".$_POST["cs"]."'";
          }
          $qryreq .= ")";
          $resreq = db_query($qryreq);
          $isfound = 0;
          while ($row = mysql_fetch_array($resreq)) {
            if (isset($row[0]) && strtolower($row[0]) != "removed" && strtolower($row[0]) != "aborted") $isfound=1;
          }
          if ($isfound == 1) {
            if ($requiredby != "") $requiredby .= ", ";
            $requiredby .= $relnum;
          }
        } else {
          if ($requiredby != "") $requiredby .= ", ";
          $requiredby .= $relnum;
        }
      }
    }
    return $requiredby;
  }

  function set_site_info() {
    $sres = db_query("SELECT name,cs FROM site WHERE cename='" . $_POST['cename'] . "' ORDER BY ref DESC LIMIT 1");
    $srow = mysql_fetch_row($sres);
    if ($srow) {
      if (!isset($_POST["sitename"])) $_POST["sitename"]=$srow[0];
      if (!isset($_POST["cs"])) $_POST["cs"]=$srow[1];
    }
    return 0;
  }

  function insert_data() {
    // Current date/time
    $date = date("Y-m-d H:i:s");

    // Process the site
    $res = db_query("SELECT ref FROM site WHERE cs='" . $_POST['cs'] . "'");
    $row = mysql_fetch_row($res);
    if (!$row) {
      print "INSTALL SERVER> Unknown site. Please contact the installation team (atlas-grid-install@cern.ch).\n";
      exit;
    }
    $siteref = $row[0];

    // Process the user
    $ssluserdetails = getenv("SSL_CLIENT_S_DN");
    $ssluserdetails = ereg_replace("/CN=proxy", "", $ssluserdetails);
    $res = db_query("SELECT ref,name,email FROM user WHERE dn='" . $ssluserdetails . "' ORDER BY ref DESC");
    $row = mysql_fetch_row($res);
    if (!$row) {
      print "INSTALL SERVER> DN: ".$ssluserdetails."\n";
      print "INSTALL SERVER> CN: ".$sslusername."\n";
      print "INSTALL SERVER> role: ".$role."\n";
      print "INSTALL SERVER> Unknown user. Please register to the installation system first.\n";
      exit;
    }
    $userref = $row[0];
    $_POST["user"] = $row[1];
    $_POST["email"] = $row[2];

    // Process the release
    if ($_POST["rel"] == "other") {
      $relname = $_POST["relnew"];
    } else {
      $relname = $_POST["rel"];
    }
    $res = db_query("SELECT ref FROM release WHERE name='" . $relname . "' AND sitefk=" . $siteref);
    $row = mysql_fetch_row($res);
    if (!$row) {
      $res = db_query("INSERT INTO release SET name='" . $relname . "', sitefk=" . $siteref . ", userfk=" . $userref . ", status='pending', date='" . $date . "'");
      $res = db_query("SELECT ref FROM release WHERE name='" . $relname . "' AND sitefk=" . $siteref);
      $row = mysql_fetch_row($res);
    }
    $relref = $row[0];

    // Process the bdii
    $res = db_query("SELECT ref FROM bdii WHERE hostname='" . $_POST["bdii"] . "'");
    $row = mysql_fetch_row($res);
    $bdiiref = $row[0];

    // Process the type
    $res = db_query("SELECT ref FROM request_type WHERE description='" . $_POST["reqtype"] . "'");
    $row = mysql_fetch_row($res);
    $typeref = $row[0];

    // Transaction ID
    $guid = guid();

    // Process the status
    if (isset($_POST["autoinstall"]) && $_POST["autoinstall"] == "yes") {
        $statusfk = 7;  // autorun
    } else {
        $statusfk = 1;  // not assigned
    }
    if (isset($_POST["status"]) && $_POST["status"] != "") {
        $res = db_query("SELECT ref FROM request_status WHERE description='" . $_POST["status"] . "'");
        $row = mysql_fetch_row($res);
        if ($row) {
            $statusfk = $row[0];
        }
    }

    if (!isset($_POST['multi']) ||
       (isset($_POST['multi']) && $_POST['multi']=='n')) {
        // Check for duplicate requests
        $query = "SELECT id, request_date FROM request WHERE sitefk=" . $siteref;
        $query = $query . " AND typefk=" . $typeref;
        $query = $query . " AND relfk=" . $relref;
        $query = $query . " AND statusfk <> 4";
        $resdp = db_query($query);
        $row   = mysql_fetch_row($resdp);
    } else {
        unset($row);
    }

    if (!$row) {
        // Insert the data
        $query =  "INSERT INTO request SET id='" . $guid . "', bdiifk=" . $bdiiref;
        $query = $query . ", sitefk=" . $siteref . ", relfk=" . $relref;
        $query = $query . ", typefk=" . $typeref . ", userfk=" . $userref;
        $query = $query . ", statusfk=" . $statusfk . ", request_date='" . $date . "'";
        if (isset($_POST["comments"]))
          $query = $query . ", user_comments='" . ereg_replace("'","\'", $_POST["comments"]) . "'";
        $res   = db_query($query);
    } else {
        $guid  = "-" . $row[0]; 
    }

    return $guid;
  }


  // Check the credentials
  $ssluserdetails = getenv("SSL_CLIENT_S_DN");
  $ssluserdetails = ereg_replace("/CN=proxy", "", $ssluserdetails);
  $sslvalid = getenv("SSL_CLIENT_V_REMAIN");
  if ($ssluserdetails == "" || $sslvalid == 0) {
    print "INSTALL SERVER> Bad credentials\n";
    exit;
  }
  $_POST["validated"] = "no";

  // Get the site name, if not yet available
  if (!isset($_POST['sitename']) || !isset($_POST['cs'])) {
    set_site_info();
    if (!isset($_POST['cs'])) {
      print "INSTALL SERVER> Cannot find resource name for CE '".$_POST['cename']."'\n";
      exit;
    }
  }

  // Default BDII
  if (!isset($_POST['bdii'])) $_POST['bdii'] = 'exp-bdii.cern.ch';

  // Check pins and requirements
  $pin            = check_pin();
  $requirementsok = check_requirements();
  $reqby          = check_required();
  if ($requirementsok == 1) {
    if ($reqby == "" || ($reqby != "" && $_POST['reqtype'] != 'removal' && $_POST['reqtype'] != 'cleanup')) {
      if ($pin == 0 || ($pin != 0 && $_POST['reqtype'] != 'removal' && $_POST['reqtype'] != 'cleanup')) {
        $guid = insert_data();
        $_SERVER['FULL_URL'] = 'http';
        if($_SERVER['HTTPS']=='on') {
          $_SERVER['FULL_URL'] .=  's';
        }
        $_SERVER['FULL_URL'] .=  '://';
        $ip = gethostbyname($_SERVER['HTTP_HOST']);
        $hn = gethostbyaddr($ip);
        if($_SERVER['SERVER_PORT']!='80' && $_SERVER['SERVER_PORT']!='443') {
          $_SERVER['FULL_URL'] .=  $hn.':'.$_SERVER['SERVER_PORT'].$_SERVER['DOCUMENT_ROOT'].$_SERVER['SCRIPT_NAME'];
        } else {
          $_SERVER['FULL_URL'] .=  $hn.$_SERVER['SCRIPT_NAME'];
        }
        $_SERVER['FULL_URL'] = ereg_replace("/exec/","/protected/",$_SERVER['FULL_URL']);
        if ($guid{0} == "-") {
          $guidlen = strlen($guid);
          $guid    = substr($guid,1,$guidlen-1);
          $link=dirname($_SERVER['FULL_URL']) . "/req.php?id=" . $guid;
          echo ("INSTALL SERVER> Another request has been already submitted with the same parameters.\n");
          echo ("INSTALL SERVER> See " . $link . " for further details.\n");
        } else {
          echo "INSTALL SERVER> request id ".$guid." submitted\n";
          send_mail($link,$guid);
        }
      } else {
        echo ("INSTALL SERVER> You cannot remove a pinned release.\n");
      }
    } else {
      echo ("INSTALL SERVER> This release is required by ".$reqby.". Please remove the dependencies first.\n");
    }
  } else {
    echo ("INSTALL SERVER> The selected software requires a release which is not installed in the site.\n");
  }
?>
