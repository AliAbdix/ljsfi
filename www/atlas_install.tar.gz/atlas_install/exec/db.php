<?php
  function db_conn($dbserv="localhost",$dbname="atlas_install") {
    $dbconn = @mysql_connect($dbserv,"dbwriter","dbwriter");
    if (!$dbconn) {
      echo ( "<P>Cannot connect to db server $dbserv</P>");
      exit();
    }
    if (!@mysql_select_db($dbname, $dbconn)) {
      echo ( "<P>Unable to select db $dbname</P>" );
      exit();
    }
  }

  function db_err($err) {
    echo ("<P>ERROR: " . $err . "</P>");
    exit();
  }

  function db_query($query) {
    if (!isset($dbconn)) db_conn();
    $result = mysql_query($query);
    if (!$result) {
      db_err(mysql_error());
    } else {
      return $result;
    }
  }
?>
