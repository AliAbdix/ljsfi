<?php
  require("db.php");

  # Query header
  # Exclude internal (typefk=1) releases
  $q_hdr  = "SELECT DISTINCT(rd.name),r.status";
  $q_body =  " FROM release_data rd,release r,site s"
           ." WHERE rd.name=r.name AND r.sitefk=s.ref"
             ." AND rd.typefk <> 1";

  # Fetch the records
  $query  = ($q_hdr . $q_body);
  if (isset($_REQUEST['rel']))      $query .= (" AND rd.name like '" . $_REQUEST['rel'] . "'");
  if (isset($_REQUEST['cename']))   $query .= (" AND s.cename='" . $_REQUEST['cename'] . "'");
  if (isset($_REQUEST['sitename'])) $query .= (" AND s.name='" . $_REQUEST['sitename'] . "'");
  if (isset($_REQUEST['status']))   $query .= (" AND r.status='" . $_REQUEST['status'] . "'");
  if (isset($_REQUEST['swarea']))   $query .= (" AND s.swarea='" . $_REQUEST['swarea'] . "'");
  # Select obsolete/production releases
  # Exclude nightly (typefk=3) releases
  if (isset($_REQUEST['obsolete'])) $query .= (" AND rd.obsolete=" . $_REQUEST['obsolete']." AND rd.typefk <> 3");
  $query .= (" ORDER BY rd.tag ASC");
  $result = db_query($query);
  while ( $row = mysql_fetch_row($result) ) {
    printf ("%-20s : [%s]\n", $row[0],$row[1]);
  }
  if (isset($_REQUEST['show'])) echo $query;
?>
