<?php
  require("db.php");

  $sslusername = getenv("SSL_CLIENT_S_DN_CN");
  $ssluserdetails = getenv("SSL_CLIENT_S_DN");
  $result = db_query("SELECT user.ref, role.description FROM user,role WHERE name='" . $sslusername . "' AND dn='" . $ssluserdetails . "' AND user.rolefk=role.ref");
  $row = mysql_fetch_row($result);
  if (!$row) {
    $role="";
  } else {
    $adminfk=$row[0];
    $role=$row[1];
  }

  # Query header
  $q_hdr  = ("SELECT request.id
                    ,request.typefk
                    ,request_type.description
                    ,release.name
                    ,site.cename
                    ,site.cs
                    ,request.statusfk
                    ,request_status.description
                    ,request.request_date
                    ,request.update_date
                    ,user.name
                    ,bdii.ns
                    ,bdii.lb
                    ,bdii.ld
                    ,bdii.wmproxy
                    ,bdii.myproxy
                    ,request.userfk
                    ,IF(request.adminfk IS NOT NULL,request.adminfk,request.userfk)");
  $q_body = (" FROM request,release,site,user,request_type,request_status,bdii
              WHERE     request.sitefk=site.ref
                    AND request.userfk=user.ref
                    AND request.relfk=release.ref
                    AND request.typefk=request_type.ref
                    AND request.statusfk=request_status.ref
                    AND request.bdiifk=bdii.ref");

  # Fetch the records
  $query  = ($q_hdr . $q_body);
  if (isset($_GET['id'])) $query .= (" AND request.id='" . $_GET['id'] . "'");
  if (isset($_GET['statusid'])) $query .= (" AND request.statusfk=" . $_GET['statusid']);
  if (isset($_GET['status'])) $query .= (" AND request_status.description='" . $_GET['status'] . "'");
  if (isset($_GET['rel'])) $query .= (" AND release.name like '" . $_GET['rel'] . "'");
  $query .= (" ORDER BY request.request_date DESC, site.cename");
  $result = db_query($query);
  while ( $row = mysql_fetch_array($result) ) {
    for ($i=0; $i<18; $i++) {
      echo ($row[$i]);
      if ($i<17) { echo(','); }
    }
    print "\n";
  }
?>
