<?php ?>
<div class="sidebarText" align="left">
Actions
</div>
<div class="sidebarLink" align="left">
<A HREF=".." title="Main page">
<img align="absmiddle" src="../img/BlurMetalDg0.gif" border="0" hspace="8" height="
12">
Home page
</A></div>
<div class="sidebarLink" align="left">
<A HREF="user.php" title="User registration">
<img align="absmiddle" src="../img/BlurMetalDg0.gif" border="0" hspace="8" height="
12">
User registration
</A></div>
<div class="sidebarLink" align="left">
<A HREF="rai.php" title="Request an installation">
<img align="absmiddle" src="../img/BlurMetalDg0.gif" border="0" hspace="8" height="
12">
Request an installation
</A></div>
<div class="sidebarLink" align="left">
<A HREF="pin.php" title="Pin an installed release">
<img align="absmiddle" src="../img/BlurMetalDg0.gif" border="0" hspace="8" height="
12">
Pin a release
</A></div>
<div class="sidebarLink" align="left">
<A HREF="subscribe.php" title="Subscribe to email notifications">
<img align="absmiddle" src="../img/BlurMetalDg0.gif" border="0" hspace="8" height="
12">
Mail subscriptions
</A></div>
<div class="sidebarLink" align="left">
<A HREF="req.php" title="Show the installation requests">
<img align="absmiddle" src="../img/BlurMetalDg0.gif" border="0" hspace="8" height="
12">
Show requests
</A></div>
<div class="sidebarLink" align="left">
<A HREF="rel.php" title="Show the release matrix">
<img align="absmiddle" src="../img/BlurMetalDg0.gif" border="0" hspace="8" height="
12">
Release matrix
</A></div>
<div class="sidebarLink" align="left">
<A HREF="tags.php" title="Show the tags matrix">
<img align="absmiddle" src="../img/BlurMetalDg0.gif" border="0" hspace="8" height="
12">
Tags matrix
</A></div>
<div class="sidebarLink" align="left">
<A HREF="../atlassw" title="Download the ATLASsw Firefox plugin">
<img align="absmiddle" src="../img/BlurMetalDg0.gif" border="0" hspace="8" height="
12">
ATLASsw plugin
<img align="absmiddle" src="../img/new.gif" border="0" height="30">
</A></div>
<?php ?>
