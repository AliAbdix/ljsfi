<?php
   require("site-info2.php");
   get_cluster_info("atlas-ce-01.roma1.infn.it:2119/jobmanager-lcglsf-atlasglong","exp-bdii.cern.ch");
?>
