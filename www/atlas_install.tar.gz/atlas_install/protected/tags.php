<?php if (!isset($_POST['ws']) or $_POST['ws'] == '') { ?>
<HTML>
<HEAD>
<TITLE>Atlas Installation Tags Matrix</TITLE>

<link rel="STYLESHEET" type="text/css" href="../ai.css">
<link rel="shortcut icon" href="../img/favicon.ico">
</HEAD>
<BODY>
<P>
<?php } ?>
<?php
  require("db.php");

  $sslusername = getenv("SSL_CLIENT_S_DN_CN");
  $ssluserdetails = getenv("SSL_CLIENT_S_DN");
  $result = db_query("SELECT user.ref, role.description FROM user,role WHERE name='" . $sslusername . "' AND dn='" . $ssluserdetails . "' AND user.rolefk=role.ref");
  $row = mysql_fetch_row($result);
  if (!$row) {
    $role="";
  } else {
    $adminfk=$row[0];
    $role=$row[1];
  }
?>
<?php if (!isset($_POST['ws']) or $_POST['ws'] == '') { ?>
<TABLE id='frame_tbl' border="1" rules="groups" width="100%" summary="Release matrix">
<COLGROUP width="800"></COLGROUP>
<TR><TD width="100%" height="30" background="img/bar.gif" class="captionimg">
<CENTER>Atlas Software Installation Tags matrix</CENTER>
</TD></TR>
<TR><TD height="30">&nbsp</TD></TR>
<TR><TD><CENTER>


<TABLE border="2" frame="hsides" rules="groups"
          summary="Atlas Tags matrix in LCG.">
<COLGROUP align="left">
<COLGROUP align="left">
<COLGROUP align="left">
<TR>
<TH>Site name
<TH>CE name
<TH>Tags
<TBODY>
<?php } ?>
<?php
  # Define the colors
  $COLORS     = array ( 0 => '#33FFFF'
                     ,  1 => '#FFFF33'
                      );

  # Prepare the arrays
  $sitetags = array();

  # Query header
  $q_hdr  = "SELECT s.name, s.cename, rd.tag, r.name";
  $q_body =  " FROM release_data rd,release r,site s"
           ." WHERE s.ref=r.sitefk"
             ." AND rd.name=r.name"
             ." AND rd.tag <> ''"
             ." AND r.status='installed'"
             ." AND s.name <> ''";

  # Fetch the release tag records
  $query  = ($q_hdr . $q_body);
  $query .= "ORDER BY s.name, s.cename,r.name";
  if (isset($_GET['rel'])) $query .= (" AND rd.name like '" . $_GET['rel'] . "'");
  $result = db_query($query);
  while ( $row = mysql_fetch_array($result) ) {
    if (!array_key_exists($row[0],$sitetags)) {
      $sitetags[$row[0]] = array();
    }
    if (!array_key_exists($row[1],$sitetags[$row[0]])) $sitetags[$row[0]][$row[1]] = array();
    $sitetags[$row[0]][$row[1]][$row[2]] = $row[3];
  }

  # Query header
  $q_hdr  = "SELECT s.name, s.cename, s.tags";
  $q_body =  " FROM site s"
           ." WHERE  s.tags <> ''";

  # Fetch the site tag records
  $query  = ($q_hdr . $q_body);
  $query .= "ORDER BY s.cename";
  $result = db_query($query);
  while ( $row = mysql_fetch_array($result) ) {
    if (array_key_exists($row[0],$sitetags)) {
      if (array_key_exists($row[1],$sitetags[$row[0]])) {
        foreach (split(",",$row[2]) as $key => $val) {
          $sitetags[$row[0]][$row[1]][$val] = $val;
        }
      }
    }
  }

  $color = 0;
  foreach ($sitetags as $sitename => $cedata) {
    foreach ($cedata as $ce => $reldata) {
      if ($color == 0) { $color = 1; } else { $color = 0; }
      echo ("<TR>"); 
      echo ("<TD nowrap bgcolor=" . $COLORS[$color] . ">".$sitename."</TD>");
      echo ("<TD nowrap bgcolor=" . $COLORS[$color] . ">".$ce."</TD>");
      echo ("<TD nowrap bgcolor=" . $COLORS[$color] . ">");
      asort($reldata);
      foreach ($reldata as $reltag => $relname) {
        echo ($reltag.'<BR>');
      }
      echo ('</TD>');
      echo ('</TR>');
    }
  }
?>
<?php if (!isset($_POST['ws']) or $_POST['ws'] == '') { ?>
</TABLE></CENTER></TD></TR></TABLE>
<P>
<A HREF="mailto:Alessandro.DeSalvo@roma1.infn.it">For comments or informations please drop me a mail (Alessandro.DeSalvo@roma1.infn.it)</A>
</BODY>
</HTML>
<?php } ?>
