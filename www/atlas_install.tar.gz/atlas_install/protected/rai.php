<HTML>
<HEAD>

<script language="JavaScript" type="text/javascript">
<!--
function checkform(form) {
  var retval=true;
  var rows = rai_tbl.getElementsByTagName("tr");   
  for(i = 0; i < rows.length; i++){
    rows[i].style.backgroundColor='#AAFFAA';
  }
  if (form.bdii.value=='') {
    bdii_tr.style.backgroundColor='#AAAAAA';
    retval=false;
  }
  if (form.cename.value=='') {
    cename_tr.style.backgroundColor='#AAAAAA';
    retval=false;
  }
  if (form.cs.value=='') {
    cs_tr.style.backgroundColor='#AAAAAA';
    retval=false;
  }
  if (form.rel.value=='') {
    rel_tr.style.backgroundColor='#AAAAAA';
    retval=false;
  }
  if (form.rel.value=='other') {
    if (form.relnew.value=='') {
      relnew_tr.style.backgroundColor='#AAAAAA';
      retval=false;
    }
  }
  if (form.user.value=='') {
    user_tr.style.backgroundColor='#AAAAAA';
    retval=false;
  }
  if (form.email.value=='') {
    email_tr.style.backgroundColor='#AAAAAA';
    retval=false;
  }
  if (form.reqtype.value=='') {
    reqtype_tr.style.backgroundColor='#AAAAAA';
    retval=false;
  }
  if (!retval) {
    alert('Please fill all the highlighted fields');
  }

  if (retval) {
    if (form.reltype.value=='production' && form.reqtype.value=='removal') {
      answ = confirm('WARNING: You are requesting the removal of a production release.\n Do you really want to continue?');
      if (!answ) {
        retval=false
      }
    }
    if (form.pin.value=='pinned' && (form.reqtype.value=='removal' || form.reqtype.value=='cleanup')) {
      alert('You cannot remove a pinned release');
      retval=false;
    }
    if (form.requiredby.value!='') {
      if (form.reqtype.value=='removal') {
        alert('Release '+form.rel.value+' is required by '+form.requiredby.value+'. Please remove the dependencies first.');
        retval=false;
      } else if (form.reqtype.value=='cleanup') {
        answ = confirm('WARNING: Removing this release will break dependencies.\n Do you really want to continue?');
        if (!answ) {
          retval=false;
        }
      }
    }
    if (form.requirementsok.value=='0') {
      alert('The selected software requires release '+form.requires.value+' which is not available in the selected site. Please install '+form.requires.value+' first');
      retval=false
    }
    if (form.pin.value=='not available' && form.reqtype.value=='removal') {
      alert('This release is not available in the selected site\nor it\'s already removed.');
      retval=false
    }
  }
  return retval;
}

function pageReload() {
  rai.action='rai.php';
  rai.submit();
}

function checkRel() {
  if (rai.rel.value=='other') {
    relnew_tr.style.display='table-row';
  } else {
    relnew_tr.style.display='none';
    rai.relnew.value='';
    rai.action='rai.php';
    rai.submit();
  }
}

//-->
</script>

<TITLE>Request An Install for the Atlas software</TITLE>
</HEAD>

<link rel="STYLESHEET" type="text/css" href="../ai.css">
<link rel="shortcut icon" href="../img/favicon.ico">

<BODY>

<P>

<TABLE id='frame_tbl' border="1" rules="groups" width="100%" summary="Request An Installation">
<COLGROUP width="800"></COLGROUP>
<TR><TD width="100%" height="30" background="img/bar.gif" class="captionimg">
<CENTER>Installation/Maintenance request of the Atlas Software in LCG</CENTER>
</TD></TR>
<TR><TD height="30">&nbsp</TD></TR>
<TR><TD><CENTER>


<?php
  require("guid.php");
  require("db.php");
  require("combo.php");
  require("site-info.php");
?>

<?php
  function get_ce($bdii="atlas-bdii.cern.ch") {
    $ce = array();
    $ds=ldap_connect($bdii,2170);
    $r=ldap_bind($ds);
    $filter='(&(objectclass=gluece)(glueceaccesscontrolbaserule=*atlas*))';
    $items=array('glueceinfohostname');
    $sr=ldap_search($ds, "o=grid", $filter, $items);
    $info = ldap_get_entries($ds, $sr);
    for ($i=0; $i<$info["count"]; $i++) {
      for ($k=0; $k<count($info[$i]["glueceinfohostname"]); $k++) {
        if (isset($info[$i]["glueceinfohostname"][$k])) $glueceinfohostname = $info[$i]["glueceinfohostname"][$k];
        if ($glueceinfohostname != "") array_push($ce, $glueceinfohostname);
      }
    }
    ldap_close($ds);
    $cename = array_unique($ce);
    sort($cename);
    return $cename;
  }

  function update_cs($ce,$bdii="atlas-bdii.cern.ch") {
    $cs = array();
    $ds=ldap_connect($bdii,2170);
    $r=ldap_bind($ds);
    $filter='(&(objectclass=gluece)(glueceaccesscontrolbaserule=*atlas*)(glueceinfohostname=' . $ce . '))';
    $items=array('glueceuniqueid');
    $sr=ldap_search($ds, "o=grid", $filter, $items);
    $info = ldap_get_entries($ds, $sr);
    for ($i=0; $i<$info["count"]; $i++) {
      for ($k=0; $k<count($info[$i]["glueceuniqueid"]); $k++) {
        $glueceuniqueid = $info[$i]["glueceuniqueid"][$k];
        if ($glueceuniqueid != "") array_push($cs, $glueceuniqueid);
      }
    }
    ldap_close($ds);
    return $cs;
  }
?>

<?php
  // Defaults
  if (!isset($_POST['hideobsolete'])) { $_POST['hideobsolete'] = 'no'; }

  // User info
  $sslusername = getenv("SSL_CLIENT_S_DN_CN");
  $ssluserdetails = getenv("SSL_CLIENT_S_DN");
  if (!isset($_POST["user"])) $_POST["user"] = $sslusername;
  //$sslcaname  = getenv("SSL_CLIENT_I_DN_CN");
  //$sslexpire = getenv("SSL_CLIENT_V_END");
  $rolefk=0;
  $res = db_query("SELECT email,rolefk,priv_insert FROM user WHERE name='" . $_POST["user"] . "' AND dn='" . $ssluserdetails . "'");
  $row = mysql_fetch_row($res);
  if ($row) {
    $_POST["email"]=$row[0];
    $rolefk = $row[1];
    $priv_insert = $row[2];
  }

  if (!isset($priv_insert)) {
    echo ("Unknown user. Please register <A HREF='user.php'>here</A>\n");
  } elseif ($priv_insert != 1) {
    echo ("<FONT SIZE=+1 COLOR='red'><B>");
    echo ("You don't have permissions to insert requests.<BR>\n");
    echo ("Please check your registration and ask for the insert privilege <A HREF='user.php'>here</A>\n");
    echo ("</B></FONT>");
  } else {
    // Start the form
    echo '<form method="post" name="rai" action="subreq.php" onsubmit="return checkform(this);">';
    echo '<TABLE id="rai_tbl" border="1" rules="groups" summary="Request An Install interface">';
    echo '<P>';
    echo '</FONT></CENTER></EM></CAPTION>';
    echo '<COLGROUP width="130" span=2></COLGROUP>';

    // BDII combo box
    $res = db_query("SELECT ref,hostname,port FROM bdii");
    $bdii_list = array();
    while ($row = mysql_fetch_array($res)) {
      array_push($bdii_list, $row[1]);
    }
    if (!isset($_POST["bdii"])) $_POST["bdii"] = $bdii_list[1];
    echo ("<TR id='bdii_tr' class='greentable'><TD><EM>BDII</EM></TD><TD><select name='bdii' size='1' onchange=\"pageReload();\">");
    combo_box($bdii_list,"-- select one --",$_POST["bdii"]);
    echo '</select></TD>';

    // CE FQDN combo box
    echo ("<TR id='cename_tr' class='greentable'><TD><EM>CE FQDN</EM></TD><TD>");
    echo ("<select name='cename' size='1' onchange=\"pageReload();\">");
    $cename = get_ce($_POST["bdii"]);
    if (!isset($_POST["cename"])) $_POST["cename"] = "-";
    combo_box($cename,"-- select one --",$_POST["cename"]);
    echo '</select></TD>';

    // Resource (CS) combo box
    $cs = update_cs($_POST["cename"],$_POST["bdii"]);
    echo ("<TR id='cs_tr' class='greentable'><TD><EM>Resource</EM></TD><TD>");
    echo ("<select name='cs' size='1' onchange=\"pageReload();\">");
    if (!isset($_POST["cs"])) $_POST["cs"] = "-";
    $has_selection = combo_box($cs,"-- select one --",$_POST["cs"]);
    echo '</select></TD>';
    $siteinfo = array();
    if (isset($_POST["cs"]) && $_POST["cs"] != "" && $has_selection)
      $siteinfo = get_cluster_info($_POST["cs"],$_POST["bdii"]);
    if ($has_selection && isset($siteinfo[0])) {
      echo ("<TR class='greentable'><TD><EM>Site Name</EM></TD><TD>" . $siteinfo[0] . "</TD>\n");
      echo ("<input type='hidden' name='sitename' value='" . $siteinfo[0] . "'>\n");
      echo ("<TR class='greentable'><TD><EM>OS type</EM></TD><TD>" . $siteinfo[1] . "</TD>\n");
      echo ("<input type='hidden' name='osname' value='" . $siteinfo[1] . "'>\n");
      echo ("<TR class='greentable'><TD><EM>OS version</EM></TD><TD>" . $siteinfo[2] . "</TD>\n");
      echo ("<input type='hidden' name='osver' value='" . $siteinfo[2] . "'>");
      echo ("<TR class='greentable'><TD><EM>OS release</EM></TD><TD>" . $siteinfo[3] . "</TD>\n");
      echo ("<input type='hidden' name='osrel' value='" . $siteinfo[3] . "'>\n");
    }

    // Release combo box
    $obsolete=array('production','obsolete');
    echo ("<TR id='rel_tr' class='greentable'><TD><EM>Release</EM></TD><TD>");
    $qry = "SELECT rd.name,rt.description, rd.obsolete, ra.platform_type"
                 .",ra.os_type,ra.gcc_ver, ra.mode as opt "
                 .",rd.sw_name as sw_name "
            ."FROM release_data rd, release_type rt, release_arch ra "
           ."WHERE rd.typefk = rt.ref AND rd.archfk = ra.ref AND rd.name != 'ALL' AND rd.tag != 'TEST'";
    if ($rolefk < 3) $qry .= " AND rt.ref > 2";
    if ($_POST['hideobsolete'] == 'yes') { $qry .= " AND rd.obsolete <> 1"; }
    $qry .= " ORDER BY rd.name ASC";
    $res = db_query($qry);
    $list     = array();
    $listdesc = array();
    $reltype  = "";
    while ($row = mysql_fetch_array($res)) {
      array_push($list, $row[0]);
      array_push($listdesc, $row[0].' ('.$row[7].', '.$row[3].', '.$row[4].', gcc '.$row[5].', '.$row[6].', '.$row[1].', '.$obsolete[$row[2]].')');
      if (isset($_POST["rel"]) && $row[0] == $_POST["rel"]) { $reltype = $obsolete[$row[2]]; }
    }
    echo ("<select name='rel' size='1' onchange=\"checkRel();\">");
    if (!isset($_POST["rel"])) $_POST["rel"] = "-";
    combo_box($list,"-- select one --",$_POST["rel"],$listdesc);
    echo '</select>';
    echo '<BR><input type="checkbox" name="hideobsolete" size=80 value="yes" onchange="pageReload();"';
    if ($_POST['hideobsolete'] == 'yes') { echo ' checked'; }
    echo '>Hide obsolete releases';
    echo '</TD>';
    $pinstatus = array('free','pinned','not available');
    $requirements = array('not available','ok');
    $pin = 2;
    $requires = "";
    $requiredby = "";
    if (   isset($_POST["cename"]) && $_POST["cename"] != ""
        && isset($_POST["rel"])    && $_POST["rel"] != "") {
      // Process the pins
      $qry = "SELECT release.pin "
              ."FROM release, site "
             ."WHERE release.sitefk = site.ref "
               ."AND site.cename = '".$_POST["cename"]."' "
               ."AND release.name='".$_POST["rel"]."'"
               ."AND release.status<>'removed'";
      $res = db_query($qry);
      $row = mysql_fetch_row($res);
      if ($row) $pin = $row[0];
      // Process the requirements
      $requirementsok = 1;   // By default the requirements are satisfied
      $qry = "SELECT rd.requires FROM release_data rd WHERE rd.name='".$_POST["rel"]."' LIMIT 1";
      $res = db_query($qry);
      while ($row = mysql_fetch_array($res)) {
        if (isset($row[0]) && $row[0] != "") {
          $requires = $row[0];
          $requirementsok = 0;
          if (isset($_POST["sitename"]) && $_POST["sitename"] != "") {
            $qryreq = "SELECT release.status FROM release, site"
                    . " WHERE release.name = '".$requires."'"
                    .   " AND release.sitefk = site.ref"
                    .   " AND site.name = '".$_POST["sitename"]."'";
            $resreq = db_query($qryreq);
            while ($row = mysql_fetch_array($resreq)) {
              if (isset($row[0]) && strtolower($row[0]) == "installed") $requirementsok = 1;
            }
          }
        }
      }
      $qry = "SELECT rd.name FROM release_data rd WHERE rd.requires='".$_POST["rel"]."'";
      $res = db_query($qry);
      while ($row = mysql_fetch_array($res)) {
        if (isset($row[0]) && $row[0] != "") {
          $relnum=$row[0];
          if (isset($_POST["sitename"]) && $_POST["sitename"] != "") {
            $qryreq = "SELECT release.status FROM release, site"
                    . " WHERE release.name = '".$relnum."'"
                    .   " AND release.sitefk = site.ref"
                    .   " AND (site.name = '".$_POST["sitename"]."'";
            if (isset($_POST["cs"]) && $_POST["cs"] != "") {
              $qryreq .= " OR site.cs = '".$_POST["cs"]."'";
            }
            $qryreq .= ")";
            $resreq = db_query($qryreq);
            while ($row = mysql_fetch_array($resreq)) {
              if (isset($row[0]) && strtolower($row[0]) != "removed" && strtolower($row[0]) != "aborted") {
                if ($requiredby != "") $requiredby .= ", ";
                $requiredby .= $relnum;
              }
            }
          }
        }
      }
    }
    echo ("<TR class='greentable'><TD><EM>Release Status</EM></TD><TD>" . $pinstatus[$pin] . "</TD>\n");
    echo ("<input type='hidden' name='pin' value='" . $pinstatus[$pin] . "'>\n");
    echo ("<input type='hidden' name='requires' value='" . $requires . "'>\n");
    echo ("<input type='hidden' name='requiredby' value='" . $requiredby . "'>\n");
    if ($requires != "") {
      echo ("<TR class='greentable'><TD><EM>Requires</EM></TD><TD>".$requires." (".$requirements[$requirementsok].")</TD>\n");
    }
    if ($requiredby != "") {
      echo ("<TR class='greentable'><TD><EM>Required by</EM></TD><TD>".$requiredby."</TD>\n");
    }
    echo ("<input type='hidden' name='requirementsok' value='" . $requirementsok . "'>\n");
    if ($reltype != '') {
      echo ("<TR class='greentable'><TD><EM>Release Type</EM></TD><TD>" . $reltype . "</TD>\n");
      echo ("<input type='hidden' name='reltype' value='" . $reltype . "'>\n");
    }
    echo '<TR id=\'relnew_tr\' style="display:none" class="greentable"><TD><EM>Requested release</EM></TD>';
    echo '<TD><input type="text" name="relnew" value="' . $_POST["relnew"] . '"></TD>';
    echo '<br/>';
  
    // Request type combo box
    echo ("<TR id='reqtype_tr' class='greentable'><TD><EM>Request type</EM></TD><TD>");
    $res = db_query("SELECT description,comment,level FROM request_type");
    $list = array();
    $listdesc = array();
    while ($row = mysql_fetch_array($res)) {
      if ($rolefk>=$row[2]) {
        array_push($list, $row[0]);
        array_push($listdesc, $row[0].' ('.$row[1].')');
      }
    }
    echo ("<select name='reqtype' size='1'>");
    combo_box($list,"-- select one --",$_POST["reqtype"],$listdesc);
    echo '</select></TD>';
  
    // Username
    echo '<TR id=\'user_tr\' class="greentable"><TD><EM>Your name</EM></TD><TD><input type="text" name="user" size=60 value="';
    echo $_POST["user"] . '"></TD>';
  
    // Email
    echo '<TR id=\'email_tr\' class="greentable"><TD><EM>Your e-mail</EM></TD><TD><input type="text" name="email" size=60 value="';
    echo $_POST["email"];
    echo '"></TD>';
  
    // Comments
    if (!$_POST["comments"]) $_POST["comments"]="No comments";
    echo '<TR class="greentable"><TD id=\'comm_tr\'><EM>Comments</EM></TD><TD><input type="text" name="comments" size=80 value="';
    echo $_POST["comments"];
    echo '"></TD>';

    echo '<TR class="greentable"><TD id="ai_tr"><EM>Autoinstall</EM></TD><TD><input type="checkbox" name="autoinstall" size=80 value="yes" checked></TD>';
    echo '</TABLE>';
    echo '<input type="submit" value="Submit">';
    echo '<input type="reset" value="Reset">';
    echo '</form>';
  }
?>

</CENTER></TD></TR></TABLE>

<P>
<A HREF="mailto:Alessandro.DeSalvo@roma1.infn.it">For comments or informations please drop me a mail (Alessandro.DeSalvo@roma1.infn.it)</A>
<BR>
<A HREF="req.php">Follow this link to go to the list of the installation requests</A>
</BODY>
</HTML>
