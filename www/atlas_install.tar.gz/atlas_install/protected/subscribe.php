<HTML>
<HEAD>

<script language="JavaScript" type="text/javascript">
<!--
function checkform(form) {
  var retval=true;
  var rows = subscribe_tbl.getElementsByTagName("tr");   
  for(i = 0; i < rows.length; i++){
    rows[i].style.backgroundColor='#EFEFEF';
  }
  if (form.sitename.value=='') {
    sitename_tr.style.backgroundColor='#FFFFAA';
    retval=false;
  }
  if (form.user.value=='') {
    user_tr.style.backgroundColor='#FFFFAA';
    retval=false;
  }
  if (form.email.value=='') {
    email_tr.style.backgroundColor='#FFFFAA';
    retval=false;
  }
  if (!retval) {
    alert('Please fill all the highlighted fields');
  }

  return retval;
}

function pageReload() {
  subscribe.action='subscribe.php';
  subscribe.submit();
}

//-->
</script>

<TITLE>Notifications from the ATLAS Software Installation System</TITLE>
</HEAD>

<link rel="STYLESHEET" type="text/css" href="../ai.css">
<link rel="shortcut icon" href="../img/favicon.ico">

<BODY>

<P>

<TABLE id='frame_tbl' border="1" rules="groups" width="100%" summary="Mail subscriptions">
<COLGROUP width="800"></COLGROUP>
<TR><TD width="100%" height="30" background="img/bar.gif" class="captionimg">
<CENTER>Subscribe to notifications</CENTER>
</TD></TR>
<TR><TD height="30">&nbsp</TD></TR>
<TR><TD><CENTER>

<form method="post" name="subscribe" action="subscribe.php" onsubmit="return checkform(this);">
<TABLE id='subscribe_tbl' border="1" rules="groups" summary="Subscribe to notifications">
<CAPTION><EM><CENTER><FONT SIZE=+2>
<P>
</FONT></CENTER></EM></CAPTION>
<COLGROUP width="130"></COLGROUP>
<COLGROUP width="470"></COLGROUP>
<?php
  require("db.php");
  require("combo.php");
?>

<?php
  // Site name combo box
  echo ("<TR id='sitename_tr' class='graytable'><TD><EM>Site Name</EM></TD><TD>");
  echo ("<select name='sitename' size='1' onchange=\"pageReload();\">");
  $sitename=array();
  $query = "SELECT DISTINCT site.name"
         . "  FROM site"
         . " WHERE site.name <> ''"
         . " ORDER BY site.name";
  $result = db_query($query);
  array_push($sitename, "ALL");
  while ($row = mysql_fetch_array($result)) {
    array_push($sitename, $row[0]);
  }
  combo_box($sitename,"-- select one --",$_POST["sitename"]);
  echo '</select></TD></TR>';
  echo '<TR class="graytable"><TD></TD><TD>Choose "ALL" to subscribe to all notifications</TD></TR>';

  // Username
  $sslusername = getenv("SSL_CLIENT_S_DN_CN");
  $ssluserdetails = getenv("SSL_CLIENT_S_DN");
  if (!$_POST["user"]) $_POST["user"] = $sslusername;
  echo '<TR id=\'user_tr\' class="graytable"><TD><EM>Your name</EM></TD><TD><input type="text" name="user" size=60 value="';
  echo $_POST["user"] . '"></TD>';

  // Email
  $res = db_query("SELECT email FROM user WHERE name='" . $_POST["user"] . "' AND dn='" . $ssluserdetails . "'");
  $row = mysql_fetch_row($res);
  if ($row) $_POST["email"]=$row[0];
  echo '<TR id=\'email_tr\' class="graytable"><TD><EM>Your e-mail</EM></TD><TD><input type="text" name="email" size=60 value="';
  echo $_POST["email"];
  echo '"></TD>';

  if (isset($_POST['subscribe'])) {
    # Check for the user id
    $userfk = -1;
    $userquery = "SELECT user.ref, user.name, user.dn"
               . "  FROM user"
               . " WHERE user.name='".$_POST["user"]."'"
               . "   AND user.dn='".$ssluserdetails."'";
    $res = db_query($userquery);
    $row = mysql_fetch_row($res);
    if ($row) {
      $userfk = $row[0];
    } else {
      $userins = "INSERT INTO user (name, dn, email)"
                        . " VALUES ('".$_POST["user"]."'"
                               . ", '".$ssluserdetails."'"
                               . ", '".$_POST["email"]."')";
      $res = db_query($userins);
      $res = db_query($userquery);
      $row = mysql_fetch_row($res);
      if ($row) $userfk=$row[0];
    }
    # Insert the subscription
    if ($userfk > 0 && isset($_POST["sitename"]) && $_POST["sitename"] != '') {
      if ($_POST["sitename"] == "ALL") {
        $sitename = '*';
      } else {
        $sitename = $_POST["sitename"];
      }
      $subscrquery = "SELECT ref "
                   . "  FROM subscription"
                   . " WHERE sitename='".$sitename."'"
                   . "   AND userfk=".$userfk;
      $res = db_query($subscrquery);
      $row = mysql_fetch_row($res);
      echo '<TR><TD>&nbsp;</TD><TD>';
      if (!$row) {
        $query = "INSERT INTO subscription"
                    .   " SET sitename='".$sitename."', userfk=".$userfk;
        $res = db_query($query);
        echo 'You are have successfully subscribed to '.$_POST["sitename"];
      } else {
        echo 'You are already subscribing to '.$_POST["sitename"];
      }
      echo '</TD></TR>';
    }
  }
?>
</TABLE>
<input type="submit" name="subscribe" value="Subscribe">
</form>

<form method="post" name="updatesubscription" action="subscribe.php">
<TABLE border="1" rules="groups" summary="Subscriptions">
<CAPTION><EM><CENTER><FONT SIZE=+2>
Current subscriptions
<P>
</FONT></CENTER></EM></CAPTION>
<COLGROUP width="300"></COLGROUP>
<TR class="graytable"><TD colspan="2">
<?php
  if (isset($_POST['unsubscribe'])) {
    # Check for the user id
    $userfk = -1;
    $userquery = "SELECT user.ref, user.name, user.dn"
               . "  FROM user"
               . " WHERE user.name='".$_POST["user"]."'"
               . "   AND user.dn='".$ssluserdetails."'";
    $res = db_query($userquery);
    $row = mysql_fetch_row($res);
    if ($row) $userfk = $row[0];
    # Remove the subscription
    if ($userfk > 0) {
      while (list ($key,$val) = @each ($_POST['subscriptions'])) {
        $value = $val;
        if ($val == "ALL") $value = '*';
        $subscrquery = "SELECT ref "
                     . "  FROM subscription"
                     . " WHERE sitename='".$value."'"
                     . "   AND userfk=".$userfk;
        $res = db_query($subscrquery);
        $row = mysql_fetch_row($res);
        echo '<CENTER>';
        if ($row) {
          $query = "DELETE FROM subscription"
                      . " WHERE ref=".$row[0];
          $res = db_query($query);
          echo 'You are have successfully removed the subscription to '.$val;
        } else {
          echo 'You are not subscribing to '.$val;
        }
        echo '</CENTER></TD></TR>';
        echo '<TR><TD colspan="2"><HR>';
      }
    }
  }
?>
<TABLE border="0" rules="groups" summary="Subscriptions list">
<COLGROUP width="200"></COLGROUP>
<COLGROUP width="100"></COLGROUP>
<TH align="left">Site</TH>
<TH align="center">Remove</TH>
<TBODY>
<?php
  // Current subscriptions
  $colors = array('#DFFFDF','#DFDFFF');
  $query = "SELECT DISTINCT(sitename)"
         . "  FROM user, subscription"
         . " WHERE subscription.userfk = user.ref"
         . "   AND user.dn = '".$ssluserdetails."'"
         . "   AND user.name = '".$_POST['user']."'"
         . " ORDER BY sitename";
  $result = db_query($query);
  $indx   = 0;
  while ($row = mysql_fetch_array($result)) {
    echo '<TR><TD bgcolor="'.$colors[$indx%2].'">';
    if ($row[0]=="*") {
      $value = "ALL";
    } else {
      $value = $row[0];
    }
    echo $value;
    echo '</TD><TD bgcolor="'.$colors[$indx%2].'"><CENTER>';
    echo '<input type=checkbox name=subscriptions[] value="'.$value.'">';
    echo '</CENTER></TD></TR>';
    $indx += 1;
  }
  echo '</TABLE>';
?>

</TD></TR></TABLE>
<input type="submit" name="unsubscribe" value="Update">
</form>

</CENTER></TD></TR></TABLE>

<P>
<A HREF="mailto:Alessandro.DeSalvo@roma1.infn.it">For comments or informations please drop me a mail (Alessandro.DeSalvo@roma1.infn.it)</A>
<BR>
</BODY>
</HTML>
