<HTML>
<HEAD>

<script language="JavaScript" type="text/javascript">
<!--
function checkform(form) {
  var retval=true;
  var rows = rai_tbl.getElementsByTagName("tr");   
  for(i = 0; i < rows.length; i++){
    rows[i].style.backgroundColor='#AAFFAA';
  }
  if (form.bdii.value=='') {
    bdii_tr.style.backgroundColor='#AAAAAA';
    retval=false;
  }
  if (form.cename.value=='') {
    cename_tr.style.backgroundColor='#AAAAAA';
    retval=false;
  }
  if (form.cs.value=='') {
    cs_tr.style.backgroundColor='#AAAAAA';
    retval=false;
  }
  if (form.rel.value=='') {
    rel_tr.style.backgroundColor='#AAAAAA';
    retval=false;
  }
  if (form.rel.value=='other') {
    if (form.relnew.value=='') {
      relnew_tr.style.backgroundColor='#AAAAAA';
      retval=false;
    }
  }
  if (form.user.value=='') {
    user_tr.style.backgroundColor='#AAAAAA';
    retval=false;
  }
  if (form.email.value=='') {
    email_tr.style.backgroundColor='#AAAAAA';
    retval=false;
  }
  if (form.reqtype.value=='') {
    reqtype_tr.style.backgroundColor='#AAAAAA';
    retval=false;
  }
  if (!retval) {
    alert('Please fill all the highlighted fields');
  }
  return retval;
}

function pageReload() {
  rai.action='rai.php';
  rai.submit();
}

function checkRel() {
  if (rai.rel.value=='other') {
    relnew_tr.style.display='table-row';
  } else {
    relnew_tr.style.display='none';
    rai.relnew.value='';
  }
}

//-->
</script>

<style>
TR {background-color: #AAFFAA;}
</style>
<TITLE>Request An Install for the Atlas software</TITLE>
</HEAD>

<link rel="STYLESHEET" type="text/css" href="../ai.css">
<link rel="shortcut icon" href="../img/favicon.ico">

<BODY>

<P>

<form method="post" name="rai" action="subreq_nomail.php" onsubmit="return checkform(this);">
<TABLE id='rai_tbl' border="1" rules="groups" summary="Request An Install interface">
<CAPTION><EM><CENTER><FONT SIZE=+2>
Installation/Maintenance request of the Atlas Software in LCG
<P>
</FONT></CENTER></EM></CAPTION>
<COLGROUP width="130" span=2></COLGROUP>
<?php
  require("guid.php");
  require("db.php");
  require("combo.php");
  require("site-info.php");
?>

<?php
  function get_ce($bdii="atlas-bdii.cern.ch") {
    $ce = array();
    $ds=ldap_connect($bdii,2170);
    $r=ldap_bind($ds);
    #$filter='(&(objectclass=gluece)(glueceaccesscontrolbaserule=*atlas*)(gluecepolicymaxcputime>=30))';
    $filter='(&(objectclass=gluece)(glueceaccesscontrolbaserule=*atlas*))';
    $items=array('glueceinfohostname');
    $sr=ldap_search($ds, "o=grid", $filter, $items);
    $info = ldap_get_entries($ds, $sr);
    for ($i=0; $i<$info["count"]; $i++) {
      for ($k=0; $k<count($info[$i]["glueceinfohostname"]); $k++) {
        $glueceinfohostname = $info[$i]["glueceinfohostname"][$k];
        if ($glueceinfohostname != "") array_push($ce, $glueceinfohostname);
      }
    }
    ldap_close($ds);
    $cename = array_unique($ce);
    sort($cename);
    return $cename;
  }

  function update_cs($ce,$bdii="atlas-bdii.cern.ch") {
    $cs = array();
    $ds=ldap_connect($bdii,2170);
    $r=ldap_bind($ds);
    #$filter='(&(objectclass=gluece)(glueceaccesscontrolbaserule=*atlas*)(gluecepolicymaxcputime>=30)(glueceinfohostname=' . $ce . '))';
    $filter='(&(objectclass=gluece)(glueceaccesscontrolbaserule=*atlas*)(glueceinfohostname=' . $ce . '))';
    $items=array('glueceuniqueid');
    $sr=ldap_search($ds, "o=grid", $filter, $items);
    $info = ldap_get_entries($ds, $sr);
    for ($i=0; $i<$info["count"]; $i++) {
      for ($k=0; $k<count($info[$i]["glueceuniqueid"]); $k++) {
        $glueceuniqueid = $info[$i]["glueceuniqueid"][$k];
        if ($glueceuniqueid != "") array_push($cs, $glueceuniqueid);
      }
    }
    ldap_close($ds);
    return $cs;
  }
?>

<?php

  // BDII combo box
  $res = db_query("SELECT ref,hostname,port FROM bdii");
  $bdii_list = array();
  while ($row = mysql_fetch_array($res)) {
    array_push($bdii_list, $row[1]);
  }
  if (!$_POST["bdii"]) $_POST["bdii"] = $bdii_list[1];
  echo ("<TR id='bdii_tr'><TD><EM>BDII</EM></TD><TD><select name='bdii' size='1' onchange=\"pageReload();\">");
  combo_box($bdii_list,"-- select one --",$_POST["bdii"]);
  echo '</select></TD>';

  // CE FQDN combo box
  echo ("<TR id='cename_tr'><TD><EM>CE FQDN</EM></TD><TD>");
  echo ("<select name='cename' size='1' onchange=\"pageReload();\">");
  $cename = get_ce($_POST["bdii"]);
  combo_box($cename,"-- select one --",$_POST["cename"]);
  echo '</select></TD>';
  $siteinfo = get_cluster_info($_POST["cename"],$_POST["bdii"]);
  if ($siteinfo[0]) {
    echo ("<TR><TD><EM>Site Name</EM></TD><TD>" . $siteinfo[0] . "</TD>\n");
    echo ("<input type='hidden' name='sitename' value='" . $siteinfo[0] . "'>\n");
    echo ("<TR><TD><EM>OS type</EM></TD><TD>" . $siteinfo[1] . "</TD>\n");
    echo ("<input type='hidden' name='osname' value='" . $siteinfo[1] . "'>\n");
    echo ("<TR><TD><EM>OS version</EM></TD><TD>" . $siteinfo[2] . "</TD>\n");
    echo ("<input type='hidden' name='osver' value='" . $siteinfo[2] . "'>");
    echo ("<TR><TD><EM>OS release</EM></TD><TD>" . $siteinfo[3] . "</TD>\n");
    echo ("<input type='hidden' name='osrel' value='" . $siteinfo[3] . "'>\n");
  }

  // Resource (CS) combo box
  $cs = update_cs($_POST["cename"],$_POST["bdii"]);
  echo ("<TR id='cs_tr'><TD><EM>Resource</EM></TD><TD>");
  echo ("<select name='cs' size='1'>");
  combo_box($cs,"-- select one --",$_POST["cs"]);
  echo '</select></TD>';

  // Release combo box
  echo ("<TR id='rel_tr'><TD><EM>Release</EM></TD><TD>");
  $res = db_query("SELECT DISTINCT(name) FROM release WHERE name != 'ALL' ORDER BY name ASC");
  $list = array();
  while ($row = mysql_fetch_array($res)) {
    array_push($list, $row[0]);
  }
  array_push($list,"other");
  echo ("<select name='rel' size='1' onchange=\"checkRel();\">");
  combo_box($list,"-- select one --",$_POST["rel"]);
  echo '</select></TD>';
  echo '<TR id=\'relnew_tr\' style="display:none"><TD><EM>Requested release</EM></TD>';
  echo '<TD><input type="text" name="relnew" value="' . $_POST["relnew"] . '"></TD>';
  echo '<br/>';

  // Request type combo box
  echo ("<TR id='reqtype_tr'><TD><EM>Request type</EM></TD><TD>");
  $res = db_query("SELECT description FROM request_type");
  $list = array();
  while ($row = mysql_fetch_array($res)) {
    array_push($list, $row[0]);
  }
  echo ("<select name='reqtype' size='1'>");
  combo_box($list,"-- select one --",$_POST["reqtype"]);
  echo '</select></TD>';

  // Username
  $sslusername = getenv("SSL_CLIENT_S_DN_CN");
  $ssluserdetails = getenv("SSL_CLIENT_S_DN");
  if (!$_POST["user"]) $_POST["user"] = $sslusername;
  //$sslcaname  = getenv("SSL_CLIENT_I_DN_CN");
  //$sslexpire = getenv("SSL_CLIENT_V_END");
  echo '<TR id=\'user_tr\'><TD><EM>Your name</EM></TD><TD><input type="text" name="user" size=60 value="';
  echo $_POST["user"] . '"></TD>';

  // Email
  $res = db_query("SELECT email FROM user WHERE name='" . $_POST["user"] . "' AND dn='" . $ssluserdetails . "'");
  $row = mysql_fetch_row($res);
  if ($row) $_POST["email"]=$row[0];
  echo '<TR id=\'email_tr\'><TD><EM>Your e-mail</EM></TD><TD><input type="text" name="email" size=60 value="';
  echo $_POST["email"];
  echo '"></TD>';

  // Comments
  if (!$_POST["comments"]) $_POST["comments"]="No comments";
  echo '<TR><TD id=\'comm_tr\'><EM>Comments</EM></TD><TD><input type="text" name="comments" size=80 value="';
  echo $_POST["comments"];
  echo '"></TD>';
?>
</TABLE>
<input type="submit" value="Submit">
<input type="reset" value="Reset">
</form>

<P>
<A HREF="mailto:Alessandro.DeSalvo@roma1.infn.it">For comments or informations please drop me a mail (Alessandro.DeSalvo@roma1.infn.it)</A>
</BODY>
</HTML>
