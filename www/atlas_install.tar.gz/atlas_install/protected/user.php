<HTML>
<HEAD>

<script language="JavaScript" type="text/javascript">
<!--
function checkform(form) {
  var retval=true;
  var rows = usermanage_tbl.getElementsByTagName("tr");   
  for(i = 0; i < rows.length; i++){
    rows[i].style.backgroundColor='#AAFFAA';
  }
  if (form.user.value=='') {
    user_tr.style.backgroundColor='#AAAAAA';
    retval=false;
  }
  if (form.email.value=='') {
    email_tr.style.backgroundColor='#AAAAAA';
    retval=false;
  }
  if (form.role.value=='') {
    role_tr.style.backgroundColor='#AAAAAA';
    retval=false;
  }
  if (!retval) {
    alert('Please fill all the highlighted fields');
  }

  return retval;
}

//-->
</script>

<TITLE>LJSFi user management</TITLE>
</HEAD>

<link rel="STYLESHEET" type="text/css" href="../ai.css">
<link rel="shortcut icon" href="../img/favicon.ico">

<BODY>

<P>

<TABLE id='frame_tbl' border="1" cellpadding="10" rules="groups" width="100%" summary="User Management">
<COLGROUP width="10"></COLGROUP>
<COLGROUP></COLGROUP>
<TR><TD width="100%" height="30" background="img/bar.gif" class="captionimg" colspan="2">
<CENTER>LJSFi User Management</CENTER>
</TD></TR>
<TR><TD height="50" background="../img/bar3.gif">&nbsp;</TD><TD>&nbsp;</TD></TR>
<TR><TD background="../img/bar3.gif" height="100%" valign="top">
<? include ("sidebar.php"); ?>
</TD><TD>
<CENTER>

<IMG SRC="../img/atlassw_icon.png" HEIGHT="150"><P>
<?php
  require("db.php");
  require("combo.php");
?>

<?php
  function send_approval_request($name, $id) {
    # Send the approval request email
    $subj='[USER CHANGE REQUEST] Request of membership change for user '.$name;
    $_SERVER['FULL_URL'] = 'http';
    if($_SERVER['HTTPS']=='on') {
      $_SERVER['FULL_URL'] .=  's';
    }
    $_SERVER['FULL_URL'] .=  '://';
    $hn = $_SERVER['SERVER_NAME'];
    if($_SERVER['SERVER_PORT']!='80' && $_SERVER['SERVER_PORT']!='443') {
      $_SERVER['FULL_URL'] .=  $hn.':'.$_SERVER['SERVER_PORT'].$_SERVER['DOCUMENT_ROOT'];
    } else {
      $_SERVER['FULL_URL'] .=  $hn.$_SERVER['SCRIPT_NAME'];
    }
    $link=dirname($_SERVER['FULL_URL']) . "/user.php?action=approve&id=" . $id;
    $body='The user '.$name." has requested one or more changes.\n"
         ."Follow this link to approve or deny the requests\n"
         .$link;
    $from = "From: LJSFi agent <no-reply@".$_SERVER['SERVER_NAME'].">";
    $emailqry = "SELECT DISTINCT(u.email) FROM role r, user u"
              . " WHERE u.rolefk=r.ref"
                . " AND r.description='master'"
                . " AND u.rolefk > 0";
    $result = db_query($emailqry);
    $to = array();
    while ($email = mysql_fetch_array($result)) array_push($to,$email[0]);
    mail(join(",",$to), $subj, $body, $from);
  }

  function send_notification($adminemail, $adminname, $useremail, $name, $id, $notifydata) {
    $_SERVER['FULL_URL'] = 'http';
    if($_SERVER['HTTPS']=='on') {
      $_SERVER['FULL_URL'] .=  's';
    }
    $_SERVER['FULL_URL'] .=  '://';
    $hn = $_SERVER['SERVER_NAME'];
    if($_SERVER['SERVER_PORT']!='80' && $_SERVER['SERVER_PORT']!='443') {
      $_SERVER['FULL_URL'] .=  $hn.':'.$_SERVER['SERVER_PORT'].$_SERVER['DOCUMENT_ROOT'];
    } else {
      $_SERVER['FULL_URL'] .=  $hn.$_SERVER['SCRIPT_NAME'];
    }
    // Send the notification email to the admins
    $subj='[USER CHANGE] Notification of membership change for user '.$name;
    $link=dirname($_SERVER['FULL_URL']) . "/user.php?action=approve&id=" . $id;
    $body='The membership of user '.$name." <".$useremail."> has been modified by "
         .$adminname." <".$adminemail."> with:\n\n".$notifydata."\n\n"
         ."Follow this link to further info\n"
         .$link;
    $from = "From: LJSFi agent <no-reply@".$_SERVER['SERVER_NAME'].">";
    $emailqry = "SELECT DISTINCT(u.email) FROM role r, user u"
              . " WHERE u.rolefk=r.ref"
                . " AND r.description='master'"
                . " AND u.rolefk > 0";
    $result = db_query($emailqry);
    $to = array();
    while ($email = mysql_fetch_array($result)) array_push($to,$email[0]);
    mail(join(",",$to), $subj, $body, $from);
    // Send the notification email to the user
    $subj='[LJSFi USER CHANGE] Notification of membership change for user '.$name;
    $link=dirname($_SERVER['FULL_URL']) . "/user.php";
    $body='The membership of user '.$name." <".$useremail."> has been modified by "
         .$adminname." <".$adminemail."> with:\n\n".$notifydata."\n"
         ."Please follow this link for further changes\n"
         .$link;
    $from = "From: LJSFi agent <no-reply@".$_SERVER['SERVER_NAME'].">";
    mail($useremail, $subj, $body, $from);
  }

  function get_user_info($id=NULL) {
    $ssluserdetails = getenv("SSL_CLIENT_S_DN");
    $userquery = "SELECT u.ref"
                      .",u.name"
                      .",u.email"
                      .",u.rolefk"
                      .",r.description"
                      .",u.priv_view"
                      .",u.priv_insert"
                      .",u.priv_update"
                 ." FROM user u, role r";
    if ($id) {
      $userquery .= " WHERE u.ref=".$id
                     ." AND ABS(u.rolefk)=r.ref";
    } else {
      $userquery .= " WHERE u.name='" . $_POST["user"] . "'"
                     ." AND u.dn='" . $ssluserdetails . "'"
                     ." AND ABS(u.rolefk)=r.ref";
    }
    $res = db_query($userquery);
    $row = mysql_fetch_row($res);
    if ($row) return $row;
    return NULL;
  }

  function get_role_id($rolename) {
    $rolequery = "SELECT ref FROM role WHERE description='".$rolename."'";
    $roleres = db_query($rolequery);
    $rolerow = mysql_fetch_row($roleres);
    if ($rolerow) return $rolerow[0];
    return 0;
  }

  function get_user_list($mode,$filter=NULL,$limit=15,$offset=NULL) {
    $where = array();
    if ($mode == 'count') {
      $userquery = "SELECT COUNT(u.ref) FROM user u";
    } else {
      $userquery = "SELECT u.ref"
                        .",u.name"
                        .",u.email"
                        .",u.rolefk"
                        .",r.description"
                        .",u.priv_view"
                        .",u.priv_insert"
                        .",u.priv_update"
                        .",u.dn"
                   ." FROM user u, role r";
      array_push($where,"ABS(u.rolefk)=r.ref");
    }
    if ($filter) array_push($where, "u.name LIKE '".$filter."'");
    if ($where)  $userquery .= " WHERE ".join(" AND ",$where);
    if ($mode != 'count' && $limit) $userquery .= " LIMIT ".$offset.",".$limit;
    $res = db_query($userquery);
    if ($res) return $res;
    return NULL;
  }

  function show_admin_toolbar() {
    echo ('<FORM method="post" name="ljsfadmin" action="user.php">');
    echo ("\n");
    echo '<table id="toolbar_tbl" border="0" bgcolor="#ffffff" width="100%" cellpadding="1" rules="groups">';
    echo '<COLGROUP width="100"></COLGROUP>';
    echo '<COLGROUP width="100"></COLGROUP>';
    echo '<tr><td align="center">';
    echo ('<input type="image" src="../img/listing.jpg" name="action" value="list" height="50" alt="List users">');
    echo '</td><td align="center">';
    echo ('<input type="image" src="../img/search.jpg" name="action" value="search" height="50" alt="Search users">');
    echo '</td><td>';
    echo '</td></tr>';
    echo '<tr><td class="parTextSmall">';
    echo 'List users';
    echo '</td><td class="parTextSmall">';
    echo 'Search users';
    echo '</td><td>';
    echo '</td></tr>';
    echo '</table>';
  }

  ///////////////////////
  // MAIN PROGRAM
  ///////////////////////

  // User info
  $sslusername = getenv("SSL_CLIENT_S_DN_CN");
  $ssluserdetails = getenv("SSL_CLIENT_S_DN");
  if (!isset($_POST["user"])) $_POST["user"] = $sslusername;
  //$sslcaname  = getenv("SSL_CLIENT_I_DN_CN");
  //$sslexpire = getenv("SSL_CLIENT_V_END");
  if (   !isset($sslusername)    || (isset($sslusername) && $sslusername == "")
      || !isset($ssluserdetails) || (isset($ssluserdetails) && $ssluserdetails == "")) {
      echo "No credentials found. Please import your personal certificate in your browser.\n";
  } else {
    // Handle the data changes
    if (isset($_POST['submit'])) {
      // User request
      // Get the current the user info
      if (!isset($_POST["user"]) || !isset($_POST["email"]) || !isset($_POST["role"])) {
        echo "Missing parameters. Cannot update user data\n";
      } else {
        $row = get_user_info();
        if (!$row) {
          // Insert the new user
          $query = "INSERT INTO user SET name='".$_POST["user"]."'"
                                     .",email='".$_POST["email"]."'"
                                     .",dn='" . $ssluserdetails . "'"
                                     .",rolefk=(SELECT -ref FROM role WHERE description='".$_POST["role"]."')";
          if (isset($_POST["view"]))   $query .= ",priv_view=-1";   else $query .= ",priv_view=0";
          if (isset($_POST["insert"])) $query .= ",priv_insert=-1"; else $query .= ",priv_insert=0";
          if (isset($_POST["update"])) $query .= ",priv_update=-1"; else $query .= ",priv_update=0";
          $res = db_query($query);
          error_log("[INSTALL_USER_ADD] ".$query."\n");
          // Read back the record and check if the insert has been successful
          $res = db_query($infoquery);
          $row = mysql_fetch_row($res);
          if ($row) {
            send_approval_request($_POST["user"],$row[0]);
            echo "Your request has been submitted to the sysadmins for approval.<BR>";
          } else {
            echo "Unable to send the request. Please contact the administrators.<BR>";
          }
        } else {
          // Update the user data
          $query_arr = array();
          // If we are masters we do not need any approval, so set all directly
          if ($row[4] == "master" && $row[3]>0) $sep=""; else $sep="-";
          $needsapproval = False;
          if (isset($_POST["role"])   && $_POST["role"]   != "" && $_POST["role"]   != $row[4]) {
            array_push($query_arr, "rolefk=(SELECT ".$sep."ref FROM role WHERE description='".$_POST["role"]."')");
            if ($sep == "-") $needsapproval = True;
          }
          if (isset($_POST["view"])   && $_POST["view"]   != "" && $_POST["view"]   != $row[5]) {
            array_push($query_arr, "priv_view=".$sep."1");
            if ($sep == "-") $needsapproval = True;
          } else {
            array_push($query_arr, "priv_view=0");
          }
          if (isset($_POST["insert"]) && $_POST["insert"] != "" && $_POST["insert"] != $row[6]) {
            array_push($query_arr, "priv_insert=".$sep."1");
            if ($sep == "-") $needsapproval = True;
          } else {
            array_push($query_arr, "priv_insert=0");
          }
          if (isset($_POST["update"]) && $_POST["update"] != "" && $_POST["update"] != $row[7]) {
            array_push($query_arr, "priv_update=".$sep."1");
            if ($sep == "-") $needsapproval = True;
          } else {
            array_push($query_arr, "priv_update=0");
          }
          if ($query_arr) {
            $query = "UPDATE user SET ".join(",",$query_arr);
            $query .= " WHERE ref=".$row[0];
            $res = db_query($query);
            error_log("[INSTALL_USER_UPDATE] ".$query);
            if ($needsapproval) {
              send_approval_request($_POST["user"],$row[0]);
              echo "Your request has been submitted to the LJSFi administrators for approval.<BR>";
            } else {
              echo "Your request has been approved.<BR>";
            }
          }
        }
      }
    } elseif (isset($_POST['validate']) && isset($_POST['aid'])) {
      // Check if we are can validate this user
      // Only masters can validate other members (rolefk > 2)
      $row = get_user_info($_POST['aid']);
      if ($row) $rolefk = $row[3];
      if ($rolefk > 2) {
        $adminname  = $row[1];
        $adminemail = $row[2];
        if (!isset($_POST["id"]) || (isset($_POST["id"]) && $_POST["id"] == "")) {
          echo "<FONT COLOR=red><B>Cannot find the user id to validate</B></FONT><BR>";
        } else {
          $query_arr = array();
          $priv_map = array("0" => "disabled", "1" => "enabled");
          $actions = "";
          $row = get_user_info($_REQUEST["id"]);
          if ($row) {
            $username       = $row[1];
            $useremail      = $row[2];
            $rolefk         = $row[3];
            $priv_view      = $row[5];
            $priv_insert    = $row[6];
            $priv_update    = $row[7];
          }
          if (isset($_POST["role"])   && $_POST["role"]   != "" && get_role_id($_POST["role"]) != $row[3]) {
            array_push($query_arr, "rolefk=(SELECT ref FROM role WHERE description='".$_POST["role"]."')");
            $actions .= "Role = ".$_POST["role"]."\n";
          }
          if (isset($_POST["view"])) $reqpriv_view = 1; else $reqpriv_view = 0;
          if ($priv_view != $reqpriv_view) {
            array_push($query_arr, "priv_view=".$reqpriv_view);
            $actions .= "View protected info = ".$priv_map[$reqpriv_view]."\n";
          }
          if (isset($_POST["insert"])) $reqpriv_insert = 1; else $reqpriv_insert = 0;
          if ($priv_insert != $reqpriv_insert) {
            array_push($query_arr, "priv_insert=".$reqpriv_insert);
            $actions .= "Post installation requests = ".$priv_map[$reqpriv_insert]."\n";
          }
          if (isset($_POST["update"])) $reqpriv_update = 1; else $reqpriv_update = 0;
          if ($priv_update != $reqpriv_update) {
            array_push($query_arr, "priv_update=".$reqpriv_update);
            $actions .= "Restart installation tasks = ".$priv_map[$reqpriv_update]."\n";
          }
          if ($query_arr) {
            $query = "UPDATE user SET ".join(",",$query_arr)." WHERE ref=".$_POST["id"];
            $res = db_query($query);
            error_log("[INSTALL_USER_UPDATE] ".$query);
            send_notification($adminemail, $adminname, $useremail, $username, $_POST["id"], $actions);
            $_REQUEST['action'] = "approve";
            echo "<FONT SIZE=+1 COLOR=green><B>You have successfully validated the user requests</B></FONT><BR>";
          } else {
            echo "<FONT COLOR=RED><B>No changes to validate</B></FONT><BR>";
          }
        }
      } else {
        echo "<FONT SIZE=+1 COLOR=RED><B>You have no privileges to validate user requests</B></FONT><BR>";
      }
    }

    // User info
    $row = get_user_info();
    if ($row) {
      $_POST["email"] = $row[2];
      $rolefk         = $row[3];
      $priv_view      = $row[5];
      $priv_insert    = $row[6];
      $priv_update    = $row[7];
    }

    // Check if we are trying to approve a user and if we are entitled to do that
    // Only masters can approve other members (rolefk > 2)
    if (isset($_REQUEST['action']) && $_REQUEST['action'] == "approve") {  
      if ($rolefk > 2) {
        $canapprove = True;
        $adminref = $row[0];
        if (isset($_REQUEST["id"]) && $_REQUEST["id"] != "") {
          $row = get_user_info($_REQUEST["id"]);
          if ($row) {
            $userid         = $row[0];
            $_POST["user"]  = $row[1];
            $_POST["email"] = $row[2];
            $rolefk         = $row[3];
            $priv_view      = $row[5];
            $priv_insert    = $row[6];
            $priv_update    = $row[7];
          }
        } else {
          echo "No user id specified<BR>";
        }
      } else {
        echo "<FONT SIZE=+1 COLOR=RED><B>You have no privileges to approve user requests</B></FONT>";
        $canapprove = False;
      }
    }

    // Display the form, if we are entitled
    if (!isset($_REQUEST['action']) || (isset($_REQUEST['action']) && ($_REQUEST['action'] == "approve" && $canapprove))) {

      // Admin toolbar
      if (isset($rolefk) && $rolefk > 2) show_admin_toolbar();

      // Header
      if (isset($_REQUEST['action']) && $_REQUEST['action'] == "approve") {
        echo ('<FONT SIZE=+1 COLOR=GREEN><B>Please validate the user requests</B></FONT>');
      } elseif (isset($rolefk)) {
        echo ('Please modify your membership parameters');
      } else {
        echo ('Please register to LJSFi');
      }

      // Start the form
      echo '<form method="post" name="manageuser" action="user.php" onsubmit="return checkform(this);">';
      echo '<TABLE id="usermanage_tbl" border="1" rules="groups" summary="User Management interface">';
      echo '<P>';
      echo '</FONT></CENTER></EM></CAPTION>';
      echo '<COLGROUP width="250" span=2></COLGROUP>';

      // Username
      if (isset($_REQUEST['action']) && $_REQUEST['action'] == "approve") {  
        echo '<TR id="user_tr" class="whitetable"><TD><EM>User name</EM></TD><TD>'.$_POST["user"].'</TD>';
      } else {
        echo '<TR id="user_tr" class="whitetable"><TD><EM>Your name</EM></TD><TD><input type="text" name="user" size=60 value="';
        echo $_POST["user"] . '"></TD>';
      }
 
      // Email
      if (isset($_REQUEST['action']) && $_REQUEST['action'] == "approve") {  
        echo '<TR id="email_tr" class="whitetable"><TD><EM>User e-mail</EM></TD><TD>'.$_POST["email"].'</TD>';
      } else {
        echo '<TR id="email_tr" class="whitetable"><TD><EM>Your e-mail</EM></TD><TD><input type="text" name="email" size=60 value="';
        echo $_POST["email"] . '"></TD>';
      }

      // Role
      $res = db_query("SELECT ref,description FROM role");
      $role_list = array();
      while ($row = mysql_fetch_array($res)) {
        $role_list[$row[0]-1] = $row[1];
      }
      if (!isset($rolefk)) $role = $role_list[0]; else $role = $role_list[abs($rolefk)-1];
      echo ("<TR id='role_tr' class='whitetable'><TD><EM>Role</EM></TD><TD><select name='role' size='1'>");
      combo_box($role_list,"-- select one --",$role);
      echo '</select>';
      if ($rolefk < 0) echo "[NOT YET APPROVED]";
      echo '</TD>';

      // View privilege
      echo '<TR id="vp_tr" class="whitetable"><TD><EM>View protected info</EM></TD><TD><input type="checkbox" name="view" value="1"';
      if (abs($priv_view) == 1) echo " checked";
      echo '>';
      if ($priv_view < 0) echo "[NOT YET APPROVED]";
      echo "</TD>\n";

      // Insert privilege
      echo '<TR id="ip_tr" class="whitetable"><TD><EM>Post installation requests</EM></TD><TD><input type="checkbox" name="insert" value="1"';
      if (abs($priv_insert) == 1) echo " checked";
      echo '>';
      if ($priv_insert < 0) echo "[NOT YET APPROVED]";
      echo "</TD>\n";

      // Update privilege
      echo '<TR id="up_tr" class="whitetable"><TD><EM>Restart installation tasks</EM></TD><TD><input type="checkbox" name="update" value="1"';
      if (abs($priv_update) == 1) echo " checked";
      echo '>';
      if ($priv_update < 0) echo "[NOT YET APPROVED]";
      echo "</TD>\n";

      echo '</TABLE>';
      if (isset($_REQUEST['action']) && $_REQUEST['action'] == "approve") {
        echo '<input type="hidden" name="id" value="'.$userid.'">';
        echo '<input type="hidden" name="aid" value="'.$adminref.'">';
        echo '<input type="submit" name="validate" value="Validate">';
      } else {
        echo '<input type="submit" name="submit" value="Submit">';
        echo '<input type="reset" value="Reset">';
      }
      echo '</form>';
    } elseif (isset($_REQUEST['action']) && $_REQUEST['action'] == "list" && $rolefk > 2) {
      // Admin toolbar
      if (isset($rolefk) && $rolefk > 2) show_admin_toolbar();

      echo '<TABLE id="userlist_tbl" border="1" rules="groups" summary="User List">';
      echo '<COLGROUP width="250"></COLGROUP>';
      echo '<COLGROUP width="250"></COLGROUP>';
      echo '<COLGROUP width="250"></COLGROUP>';
      echo '<TH class="tablehead">User Name</TH>';
      echo '<TH class="tablehead">Email</TH>';
      echo '<TH class="tablehead">DN</TH>';
      if (isset($_REQUEST["filter"]) && $_REQUEST["filter"] != "") $filter = $_REQUEST["filter"]; else $filter = NULL;
      $res = get_user_list('count',$filter);
      $row = mysql_fetch_row($res);
      $numrows = $row[0];
      // Paginate every 15 users
      $pagesize = 15;
      $pagenum  = 1;
      if (isset($_REQUEST["page"]) && $_REQUEST["page"] > 0) $pagenum = $_REQUEST["page"];
      $maxpages = floor($numrows / $pagesize) + 1;
      if ($pagenum > $maxpages) $pagenum = $maxpages;
      $offset   = ($pagenum - 1) * $pagesize;
      $rowtype = 1;
      $res = get_user_list('list', $filter, $pagesize, $offset);
      while ($row = mysql_fetch_row($res)) {
        if ($rowtype == 1) $rowtype = 2; else $rowtype = 1;
        echo '<TR class="userlist'.$rowtype.'"><TD><A HREF="user.php?action=approve&id='.$row[0].'">'.$row[1].'</A></TD>';
        echo '<TD><A HREF="mailto:'.$row[2].'">'.$row[2].'</A></TD>'."\n";
        echo '<TD>'.$row[8].'</TD></TR>'."\n";
      }
      echo "</TABLE>\n";
      // Show the page navigator
      $minpage = $pagenum - 5;
      $maxpage = $pagenum + 5;
      if ($minpage < 1) $minpage = 1;
      if ($maxpage > $maxpages) $maxpage = $maxpages;
      if ($pagenum != 1) {
        echo '<A HREF="user.php?action=list&page=1';
        if ($filter) echo "&filter=".$filter;
        echo '">';
      }
      echo '[first]';
      if ($pagenum != 1) echo '</A>';
      echo ' - ';
      for ($i=$minpage; $i<=$maxpage; $i++) {
        if ($i != $pagenum) {
          echo '<A HREF="user.php?action=list&page='.$i;
          if ($filter) echo "&filter=".$filter;
          echo '">';
        }
        echo '['.$i.'] ';
        if ($i != $pagenum) echo "</A>";
      }
      if ($pagenum != $maxpages) {
        echo ' - <A HREF="user.php?action=list&page='.$maxpages;
        if ($filter) echo "&filter=".$filter;
        echo '">';
      }
      echo '[last]';
      if ($pagenum != $maxpages) echo '</A>';
    } elseif (isset($_REQUEST['action']) && $_REQUEST['action'] == "search" && $rolefk > 2) {
      // Admin toolbar
      if (isset($rolefk) && $rolefk > 2) show_admin_toolbar();

      echo '<form method="post" name="searchuser" action="user.php">';
      echo '<TABLE id="usersearch_tbl" border="1" rules="groups" summary="User Search">';
      echo '<COLGROUP width="200"></COLGROUP>';
      echo '<COLGROUP width="400"></COLGROUP>';
      echo '<TR class="graytable"><TD class="parText"><EM>User Name</EM><BR>(use % as wildcard)</TD><TD><INPUT TYPE="text" size="60" NAME="filter"></TD></TD></TR>';
      echo "</TABLE>\n";
      echo '<input type="submit" name="submit" value="Search">';
      echo '</form>';
    }
  }
?>

</CENTER></TD></TR></TABLE>

<P>
<A HREF="mailto:Alessandro.DeSalvo@roma1.infn.it">For comments or informations please drop me a mail (Alessandro.DeSalvo@roma1.infn.it)</A>
</BODY>
</HTML>
