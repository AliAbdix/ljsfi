<?php

# Path where to upload the files
$upload_path = "/data/logfiles_dev/";

# Debug flag (0 --> no debug output, > 0 --> debug output)
$debug = 1;

# Log prefix for debug messages
$logprefix = "[LJSFi]";

?>
