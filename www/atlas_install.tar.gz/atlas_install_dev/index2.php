<?php
require('dbr.php');     // database connect script.
?>

<HTML>
<HEAD>
<TITLE>ATLAS LCG Installation System</TITLE>

<link rel="STYLESHEET" type="text/css" href="ai.css">
<link rel="shortcut icon" href="img/favicon.ico">

<script type="text/javascript">
function openpop(url) {
    newWin = window.open(url,'Details','scrollbars=no,resizable=yes, width=300,
height=300,status=no,location=no,toolbar=no');
}
function closeWin() {
    self.close();
}
</script>

</HEAD>
<BODY>

<P>

<TABLE id='ai_tbl' border="1" cellspacing="0" cellpadding="10" rules="groups" width="100%" summary="Atlas Installation Web Pages">
<COLGROUP width="220"></COLGROUP>
<COLGROUP></COLGROUP>
<TR><TD colspan="2" background="img/bar.gif" height="10" class="captionimg">
<CENTER>
Atlas Installation Pages
</CENTER>
</TD></TR>
<TR><TD height="50" background="img/bar3.gif">&nbsp;</TD><TD>&nbsp;</TD></TR>
<TR><TD background="img/bar3.gif" height="100%" valign="top">
<div class="sidebarText" align="left">
Actions
</div>
<div class="sidebarLink" align="left">
<A HREF="protected/rai.php" title="Request an installation">
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="
12">
Request
</A></div>
<div class="sidebarLink" align="left">
<A HREF="protected/pin.php" title="Pin an installed release">
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="
12">
Pin
</A></div>
<div class="sidebarLink" align="left">
<A HREF="protected/subscribe.php" title="Subscribe to email notifications">
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="
12">
Subscribe
</A></div>
<div class="sidebarLink" align="left">
<A HREF="protected/req.php" title="Show the installation requests">
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="
12">
Show
</A></div>
<div class="sidebarLink" align="left">
<A HREF="protected/rel.php" title="Show the release matrix">
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="
12">
Release matrix
</A></div>
<div class="sidebarLink" align="left">
<A HREF="protected/tags.php" title="Show the tags matrix">
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="
12">
Tags matrix
</A></div>
<div class="sidebarLink" align="left">
<A HREF="atlassw" title="Download the ATLASsw Firefox plugin">
<img align="absmiddle" src="img/BlurMetalDg0.gif" border="0" hspace="8" height="
12">
ATLASsw plugin
<img align="absmiddle" src="img/new.gif" border="0" height="30">
</A></div>
</TD><TD>
<CENTER>
<form method="post" name="select" action="list2.php">
<TABLE id='select_tbl' border="1" rules="groups">
<COLGROUP width="200"></COLGROUP>
<tr><td class="selection">Release</td><td>
<?php
  echo ('<select name="rel">');
  $rowsel=0;
  echo ('<option value="">- any -</option>');
  $qry_res = $db_object->query("SELECT ref,name as value FROM release_data WHERE typefk > 1 ORDER BY value");
  while ($row = $qry_res->fetchRow ()) {
    if ($row['ref'] == $rowsel) {
      echo ('<option value="'.$row['value'].'" selected>'.$row['value'].'</option>');
    } else {
      echo ('<option value="'.$row['value'].'">'.$row['value'].'</option>');
    }
  }
  echo ('</select>');
?>
</td></tr>
<tr><td class="selection">Site name</td><td>
<?php
  echo ('<select name="sitename">');
  $rowsel='';
  echo ('<option value="" selected>- any -</option>');
  $qry_res = $db_object->query("SELECT DISTINCT(name) as value FROM site WHERE name <> '' ORDER BY value");
  while ($row = $qry_res->fetchRow ()) {
    if ($row['value'] == $rowsel) {
      echo ('<option value="'.$row['value'].'" selected>'.$row['value'].'</option>');
    } else {
      echo ('<option value="'.$row['value'].'">'.$row['value'].'</option>');
    }
  }
  echo ('</select>');
?>
</td></tr>
<tr><td class="selection">Site arch</td><td>
<?php
  echo ('<select name="arch">');
  $rowsel='';
  echo ('<option value="" selected>- any -</option>');
  $qry_res = $db_object->query("SELECT DISTINCT(arch) as value FROM site WHERE arch <> '' ORDER BY value");
  while ($row = $qry_res->fetchRow ()) {
    if ($row['value'] == $rowsel) {
      echo ('<option value="'.$row['value'].'" selected>'.$row['value'].'</option>');
    } else {
      echo ('<option value="'.$row['value'].'">'.$row['value'].'</option>');
    }
  }
  echo ('</select>');
?>
</td></tr>
<tr><td class="selection">Computing Element</td><td>
<?php
  echo ('<select name="cename">');
  $rowsel='';
  echo ('<option value="" selected>- any -</option>');
  $qry_res = $db_object->query("SELECT DISTINCT(cename) as value FROM site WHERE cename <> '' ORDER BY value");
  while ($row = $qry_res->fetchRow ()) {
    if ($row['value'] == $rowsel) {
      echo ('<option value="'.$row['value'].'" selected>'.$row['value'].'</option>');
    } else {
      echo ('<option value="'.$row['value'].'">'.$row['value'].'</option>');
    }
  }
  echo ('</select>');
?>
</td></tr>
<tr><td class="selection">User</td><td>
<?php
  echo ('<select name="user">');
  $rowsel='';
  echo ('<option value="">- any -</option>');
  $qry_res = $db_object->query("SELECT DISTINCT(name) as value FROM user WHERE name <> '' ORDER BY value");
  while ($row = $qry_res->fetchRow ()) {
    if ($row['value'] == $rowsel) {
      echo ('<option value="'.$row['value'].'" selected>'.$row['value'].'</option>');
    } else {
      echo ('<option value="'.$row['value'].'">'.$row['value'].'</option>');
    }
  }
  echo ('</select>');
?>
</td></tr>
</TABLE>
<P>

<input type="submit" name="submit" value="Search">
<input type="reset" name="reset" value="Reset">
</form>
</CENTER>
</TD></TR>
<TR><TD height="30" background="img/bar2.gif">&nbsp;</TD><TD>&nbsp;</TD></TR>
</TABLE>

<P>
<A HREF="mailto:Alessandro.DeSalvo@roma1.infn.it">For comments or informations please send me a mail (Alessandro.DeSalvo@roma1.infn.it)</A>
<BR>
</BODY>
</HTML>

