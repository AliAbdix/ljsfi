<HTML>
<HEAD>
<TITLE>Atlas Installation DB viewer</TITLE>
</HEAD>

<link rel="STYLESHEET" type="text/css" href="ai.css">
<link rel="shortcut icon" href="img/favicon.ico">

<BODY>
<P>
<?php
  $dbserv="localhost";
  $dbname="atlas_install_dev";

  $dbconn = @mysql_connect($dbserv,"dbreader","dbreader");
  if (!$dbconn) {
    echo ( "<P>Cannot connect to db server $dbserv</P>");
    exit();
  }
  if (!@mysql_select_db($dbname, $dbconn)) {
    echo ( "<P>Unable to select db $dbname</P>" );
    exit();
  }
?>

<?php
  function db_err($err) {
    echo ("<P>ERROR: " . $err . "</P>");
    exit();
  }
?>

<?php

  $lists  = array();
  $queries = array(
                   "SELECT DISTINCT(name) FROM release WHERE name <> 'all' ORDER BY name"
                  ,"SELECT DISTINCT(name) FROM site ORDER BY name"
                  ,"SELECT DISTINCT(arch) FROM site ORDER BY arch"
                  ,"SELECT DISTINCT(cename) FROM site ORDER BY cename"
                  ,"SELECT DISTINCT(status) FROM release ORDER BY status"
                  ,""
                  ,""
                  ,"SELECT DISTINCT(LEFT(name, LOCATE('@',name)-1)) AS username FROM user ORDER BY username"
                  );
  foreach ($queries as $query) {
    $list = array();
    if ($query != "") {
      $result = mysql_query($query);
      if (!$result) {
        db_err(mysql_error());
      } else {
        while ($row = mysql_fetch_array($result)) {
          array_push($list, $row[0]);
        }
      }
    }
    array_push($lists, $list);
  }


?>

<TABLE id='frame_tbl' border="1" rules="groups" width="100%" summary="Mail subscriptions">
<COLGROUP width="800"></COLGROUP>
<TR><TD width="100%" height="30" background="img/bar.gif" class="captionimg">
<CENTER>Atlas Software deployment status in LCG</CENTER>
</TD></TR>
<TR><TD height="30">&nbsp</TD></TR>
<TR><TD><CENTER>


<TABLE border="2" frame="hsides" rules="groups"
          summary="Atlas Software deployment status in LCG.">
<COLGROUP align="center">
<COLGROUP align="center">
<COLGROUP align="left">
<COLGROUP align="center">
<COLGROUP align="left">
<COLGROUP align="left">
<COLGROUP align="left">
<COLGROUP align="left">
<THEAD valign="top">
<TR>
<?php
  require("combo.php");
  $COLUMNS = array (
                    'Release<BR>number' => array('release.name','rel')
                   ,'Site name<BR>'     => array('site.name','sitename')
                   ,'Release arch<BR>'  => array('site.arch','arch')
                   ,'Site CE<BR>'       => array('site.cename','cename')
                   ,'Status<BR>'        => array('release.status','status')
                   ,'Comments<BR>'      => array('release.comments','comments')
                   ,'Date<BR>'          => array('release.date','date')
                   ,'Installer<BR>'     => array('user.name','user')
                   );
  $indx = 0;
  echo ('<form method="get" action="">');
  echo ('<TH>Num');
  foreach($COLUMNS as $text=>$data) {
    $keyword = $data[0];
    $optname = $data[1];
    echo ('<TH>');
    if (count($lists[$indx]) > 0) {
      echo '<select name="',$optname,'" size="1">';
      combo_box ($lists[$indx]);
      echo '</select><br/>';
      echo '<input type="submit" value="Filter">';
      echo '<br/>';
    }
    $indx++;
    echo ("<A HREF='index.php?");
    $first = 0;
    foreach($_GET as $key=>$value) {
      if ($key != "orderby" && $key != "orderdir" && $value != "") {
        if ($first == 1) echo ("&");
        echo ($key . "=" . $value);
        $first = 1;
      }
    }
    if ($first == 1) echo ("&");
    echo ("orderby=" . $keyword);
    if ($_GET['orderdir'] == 'asc') {
      echo ("&orderdir=desc'>" . $text . "</A><BR><img width=30 src='b_up.png'>\n");
    } else {
      echo ("&orderdir=asc'>" . $text . "</A><BR><img width=30 src='b_down.png'>\n");
    }
  }
  echo '</form>';
?>
<TBODY>

<?php
  $COLORS = array ('installed' => '#00FF00'
                 , 'failed' => '#FF0000'
                 , 'aborted' => '#00AAFF'
                 , 'removed' => '#7F7F7F'
                 , 'other' => '#DDDDDD'
                  );

  $query  = ("SELECT release.name,site.name,release_arch.description,site.cename
                    ,release.status,release.comments,release.date,user.name
                    ,user.email,release.ref
                    ,site.osname,site.osrelease,site.cs
              FROM release,release_data,release_arch,site,user
              WHERE release.sitefk=site.ref AND release.name=release_data.name
                    AND release_data.archfk=release_arch.ref AND release.userfk=user.ref
                    AND release.name != 'ALL'");
  if (isset($_GET['rel']) && $_GET['rel'] != '')
    $query=($query . " AND release.name='" . $_GET['rel'] . "'");
  if (isset($_POST['rel']) && $_POST['rel'] != '')
    $query=($query . " AND release.name='" . $_POST['rel'] . "'");
  if (isset($_GET['user']) && $_GET['user'] != '')
    $query=($query . " AND user.name like '%" . $_GET['user'] . "%'");
  if (isset($_POST['user']) && $_POST['user'] != '')
    $query=($query . " AND user.name like '%" . $_POST['user'] . "%'");
  if (isset($_GET['sitename']) && $_GET['sitename'] != '')
    $query=($query . " AND site.name like '%" . $_GET['sitename'] . "%'");
  if (isset($_POST['sitename']) && $_POST['sitename'] != '')
    $query=($query . " AND site.name like '%" . $_POST['sitename'] . "%'");
  if (isset($_GET['arch']) && $_GET['arch'] != '')
    $query=($query . " AND site.arch like '%" . $_GET['arch'] . "%'");
  if (isset($_POST['arch']) && $_POST['arch'] != '')
    $query=($query . " AND site.arch like '%" . $_POST['arch'] . "%'");
  if (isset($_GET['cename']) && $_GET['cename'] != '')
    $query=($query . " AND site.cename like '%" . $_GET['cename'] . "%'");
  if (isset($_POST['cename']) && $_POST['cename'] != '')
    $query=($query . " AND site.cename like '%" . $_POST['cename'] . "%'");
  if (isset($_GET['status']) && $_GET['status'] != '')
    $query=($query . " AND release.status like '%" . $_GET['status'] . "%'");
  $query=($query . " ORDER BY ");
  if (isset($_GET['orderby']) && $_GET['orderby'] != '') {
    $query=($query . $_GET['orderby']);
  } else {
    $query = ($query . " release.name,release.status,site.name,site.cename");
  }
  if (isset($_GET['orderdir']) && $_GET['orderdir'] != '')
    $query=($query . " " . $_GET['orderdir']);
  $result = mysql_query($query);
  if (!$result) {
    echo ("<P>ERROR: " . mysql_error() . "</P>");
    exit();
  } else {
    $category = array();
    while ( $row = mysql_fetch_array($result) ) {
      echo ("<TR>");
      if (!isset($category[$row[4]])) $category[$row[4]] = 0;
      $category[$row[4]]++;
      if (!$COLORS[$row[4]]) {
        $color = $COLORS['other'];
      } else {
        $color = $COLORS[$row[4]];
      }
      for ($i=0; $i<8; $i++) {
        echo ("<TD bgcolor=".$color.">");
        if ($i == 0) echo ($category[$row[4]]."</TD>\n<TD bgcolor=".$color.">");
        if ($i == 3) {
          echo ("<A HREF=\"jobs.php?relfk=" . $row[9] . "\">");
          echo ("<span>");
          echo ($row[12] . "<BR>");
          echo ($row[10] . " " . $row[11] . "<BR>");
          echo ("</span>");
        }
        if ($i == 0) { echo ("<A HREF=\"index.php?rel=" . $row[0] . "\">"); }
        if ($i == 1) { echo ("<A HREF=\"protected/req.php?site=" . $row[1] . "&rel=".$row[0]."\">"); }
        if ($i == 7 && $row[8] != "") { echo ("<A HREF=\"mailto:" . $row[8] . "\">"); }
        echo ($row[$i]);
        if ($i == 0 || ($i == 7 && $row[8] != "")) echo ("</A>");
        echo ("</TD>\n");
      }
      echo ("</TR><TBODY>");
    }
  }
?>
</TABLE>

</CENTER></TD></TR></TABLE>

<?php
  echo( date("l, F dS Y, H:m:s") );
?>
<P>
<A HREF="mailto:Alessandro.DeSalvo@roma1.infn.it">For comments or informations please drop me a mail (Alessandro.DeSalvo@roma1.infn.it)</A>
</BODY>
</HTML>
