<?php

   foreach ($_SERVER as $key => $val) {
     echo ($key." ==> ".$val."<BR>\n");
   }

?>
