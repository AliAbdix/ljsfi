<?php
  require_once("db.php");
  function get_user_info($mode='select',$id=NULL,$role=NULL,$valid=NULL,$filter=NULL,$limit=15,$offset=0) {
    $ssluserdetails = getenv("SSL_CLIENT_S_DN");
    $sslusername = getenv("SSL_CLIENT_S_DN_CN");
    $where = array();
    if ($mode == 'count') {
      $userquery = "SELECT COUNT(u.ref) AS counts FROM user u, role r";
    } elseif ($mode == 'emails') {
      $userquery = "SELECT DISTINCT(u.email) AS email"
                   ." FROM user u, role r";
      array_push($where,"email IS NOT NULL");
      array_push($where,"email <> ''");
    } elseif ($mode == 'subscribers') {
      $userquery = "SELECT DISTINCT(u.email) AS email FROM subscription s, user u, role r";
      array_push($where,"s.userfk=u.ref");
      array_push($where,"(s.sitename='".$filter."' OR s.sitename='*')");
      array_push($where,"email IS NOT NULL");
      array_push($where,"email <> ''");
    } else {
      $userquery = "SELECT u.ref"
                        .",u.name"
                        .",u.dn"
                        .",u.email"
                        .",u.rolefk"
                        .",r.description as role"
                        .",u.priv_view"
                        .",u.priv_insert"
                        .",u.priv_update"
                        .",u.priv_pin"
                        .",u.valid_start"
                        .",u.valid_end"
                        .",u.enabled"
                   ." FROM user u, role r";
    }
    array_push($where,"ABS(u.rolefk)=r.ref");
    if ($mode != 'subscribers') {
      if (isset($id)) {
        array_push($where, "u.ref=".$id);
      } else {
        if ($filter) {
          array_push($where, "u.name LIKE '".$filter."'");
        } elseif ($mode == 'select') {
          array_push($where, "u.dn='" . $ssluserdetails . "'");
          if (isset($_POST['user'])) {
            array_push($where, "u.name='" . $_POST["user"] . "'");
          } elseif (isset($sslusername)) {
            array_push($where, "u.name='" . $sslusername . "'");
          }
        }
      }
    }
    if (isset($role)) array_push($where, "r.description='".$role."'");
    if ($valid) {
      $now = date('Y-m-d H:i:s');
      array_push($where, "u.enabled=1");
      array_push($where, "u.valid_start <= '".$now."'");
      array_push($where, "u.valid_end > '".$now."'");
    }
    if ($where)  $userquery .= " WHERE ".join(" AND ",$where);
    if ($mode != 'count' && $limit) $userquery .= " LIMIT ".$offset.",".$limit;
    $res = db_query($userquery);
    $user_info = array();
    while ($row = mysql_fetch_assoc($res)) {
      array_push($user_info,$row);
    }
    return $user_info;
  }

  function add_user ($name,$email,$dn,$role
                    ,$priv_view=False,$priv_insert=False,$priv_update=False,$priv_pin=False
                    ,$valid_start=NULL, $valid_end=NULL) {
    // Insert the new user
    $now = date('Y-m-d H:i:s');
    if (isset($name) && isset($email) && isset($dn)) {
      $query = "INSERT INTO user SET name='".$name."'"
                                  .",email='".$email."'"
                                  .",dn='".$dn."'"
                                  .",rolefk=(SELECT -ref FROM role WHERE description='".$role."')";
      if ($priv_view)   $query .= ",priv_view=-1";   else $query .= ",priv_view=0";
      if ($priv_insert) $query .= ",priv_insert=-1"; else $query .= ",priv_insert=0";
      if ($priv_update) $query .= ",priv_update=-1"; else $query .= ",priv_update=0";
      if ($priv_pin)    $query .= ",priv_pin=-1";    else $query .= ",priv_pin=0";
      if ($valid_start) $query .= ",valid_start='".$valid_start."'"; else $query .= ",valid_start='".$now."'";
      if ($valid_end)   $query .= ",valid_end='".$valid_end."'";
      error_log("[USER_ADD] ".$query."\n");
      $res = db_query($query);
      error_log("[USER_ADD] User added successfully\n");
    }
  }

  function update_user ($id=NULL,$name=NULL,$email=NULL,$dn=NULL,$rolefk=NULL
                       ,$priv_view=NULL,$priv_insert=NULL,$priv_update=NULL,$priv_pin=NULL
                       ,$valid_start=NULL, $valid_end=NULL,$enabled=NULL) {
    if (isset($id)) {
      $query_list = array();
      if ($name != NULL)        array_push($query_list,"name='".$name."'");
      if ($email != NULL)       array_push($query_list,"email='".$email."'");
      if ($dn != NULL)          array_push($query_list,"dn='".$dn."'");
      if ($rolefk != NULL)      array_push($query_list,"rolefk=".$rolefk);
      if ($priv_view != NULL)   array_push($query_list,"priv_view=".$priv_view);
      if ($priv_insert != NULL) array_push($query_list,"priv_insert=".$priv_insert);
      if ($priv_update != NULL) array_push($query_list,"priv_update=".$priv_update);
      if ($priv_pin != NULL)    array_push($query_list,"priv_pin=".$priv_pin);
      if ($valid_start != NULL) array_push($query_list,"valid_start='".$valid_start."'");
      if ($valid_end != NULL)   array_push($query_list,"valid_end='".$valid_end."'");
      if ($enabled != NULL)     array_push($query_list,"enabled=".$enabled);
      if (count($query_list) > 0) {
        $query = "UPDATE user SET ".implode(",",$query_list)." WHERE ref=".$id;
        error_log("[USER_UPDATE] ".$query."\n");
        $res = db_query($query);
        error_log("[USER_UPDATE] User data updated successfully\n");
      } else {
        echo "No data to update<BR>";
      }
    }
  }

  function get_role_id($rolename) {
    $rolequery = "SELECT ref FROM role WHERE description='".$rolename."'";
    $roleres = db_query($rolequery);
    $rolerow = mysql_fetch_row($roleres);
    if ($rolerow) return $rolerow[0];
    return 0;
  }
?>
