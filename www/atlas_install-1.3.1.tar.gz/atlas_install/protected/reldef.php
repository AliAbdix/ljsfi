<?php
require('db.php');     // database connect script.
require('config.php'); // Main configuration
?>

<HTML>
<HEAD>
<TITLE><?php echo $LJSFi_VO; ?> Installation System - Release Definition</TITLE>

<link rel="STYLESHEET" type="text/css" href="../ai.css">
<link rel="shortcut icon" href="../img/favicon.ico">

<script type="text/javascript">
function openpop(url) {
    newWin = window.open(url,'Details','scrollbars=no,resizable=yes, width=300,
height=300,status=no,location=no,toolbar=no');
}
function closeWin() {
    self.close();
}
</script>

</HEAD>
<BODY>
<script type="text/javascript" src="../js/wz_tooltip.js"></script>
<P>

<TABLE id='ai_tbl' border="1" cellspacing="0" cellpadding="10" rules="groups" width="100%" summary="<?php echo $LJSFi_VO; ?> Installation Web Pages">
<COLGROUP width="220"></COLGROUP>
<COLGROUP></COLGROUP>
<TR><TD colspan="2" background="../img/bar.gif" height="10" class="captionimg">
<CENTER>
<?php echo $LJSFi_VO; ?> Installation Pages - Release Definition
</CENTER>
</TD></TR>
<TR><TD height="50" background="../img/bar3.gif">&nbsp;</TD><TD>&nbsp;</TD></TR>
<TR><TD background="../img/bar3.gif" height="100%" valign="top">
<? include ("sidebar.php"); ?>
</TD><TD>
<CENTER>
<IMG SRC="../img/sw_inst_icon.png" HEIGHT="150"><P>
<TABLE id='select_tbl' border="1" rules="groups">
<COLGROUP width="350"></COLGROUP>
<COLGROUP></COLGROUP>
<?php
  // Check the user's credentials
  $sslusername = getenv("SSL_CLIENT_S_DN_CN");
  $ssluserdetails = getenv("SSL_CLIENT_S_DN");
  $qryuser = "SELECT user.ref, role.description FROM user,role WHERE name='" . $sslusername . "' AND dn='" . $ssluserdetails . "' 
AND user.rolefk=role.ref";
  $result = db_query($qryuser);
  $row = mysql_fetch_row($result);
  if (!$row) {
    $role = "";
  } else {
    $userref     = $row[0];
    $role        = $row[1];
  }

  if (!isset($userref)) {
    echo ('User not registered. Please register to LJSFi via the <A href="user.php">registration form</A>');
  } elseif ($role != "admin" && $role != "master") {
    echo ("You don't have enough privileges to define releases");
  } else {
    if (!isset($_POST["define"])) echo ('<form method="post" name="select" action="reldef.php">');
    if (isset($_POST['relsrc'])) {
      if (isset($_POST["define"])) {
        // Save the release definition in the Database
        $field_list = array();
        $value_list = array();
        foreach ($_POST as $field => $value) {
          if (substr($field,0,7) == "reldef_") {
            array_push($field_list,substr($field,7));
            if ($value == "") {
              array_push($value_list,'NULL');
            } else {
              array_push($value_list,'"'.$value.'"');
            }
          }
        }
        $query = "INSERT INTO release_data (".implode(',',$field_list).") VALUES (".implode(',',$value_list).")";
        db_query($query);
        echo "Release definition completed successfully";
      } else {
        // Get the field descriptions
        $qry_res = db_query("SELECT field_name, description, help FROM field_descriptions WHERE table_name='release_data'");
        $field_desc = array();
        $field_help = array();
        while ($row = mysql_fetch_row($qry_res)) {
          $field_desc[$row[0]] = $row[1];
          if (isset($row[2])) { $field_help[$row[0]] = $row[2]; }
        }
        // Get the field relations
        $qry_res = db_query("SELECT field1,table2,field2 FROM field_relations WHERE table1='release_data'");
        $foreign_keys = array();
        while ($row = mysql_fetch_row($qry_res)) {
          $qry_res1 = db_query("SELECT ref, ".$row[2]." FROM ".$row[1]);
          while ($row1 = mysql_fetch_row($qry_res1)) {
            if (!isset($foreign_keys[$row[0]])) { $foreign_keys[$row[0]] = array(); }
            array_push($foreign_keys[$row[0]],array($row1[0],$row1[1]));
          }
        }
        // Get the default data
        $query = "SELECT * FROM release_data";
        if ($_POST['relsrc'] != "") { $query .= " WHERE name='".$_POST['relsrc']."'"; }
        $query .= " ORDER BY date DESC LIMIT 1";
        $qry_res = db_query($query);
        $row = mysql_fetch_row($qry_res);
        $columns = mysql_num_fields($qry_res);
        for ($i=0; $i<$columns; $i++) {
          $field_name = mysql_field_name($qry_res,$i);
          if ($field_name != "ref") {
            echo ('<tr><td class="selection">');
            if (isset($field_desc[$field_name])) { echo ($field_desc[$field_name]); } else { echo ($field_name); }
            if (isset($field_help[$field_name])) {
              echo ('&nbsp;<img src="../img/help.gif" border="0"');
              echo ('onmouseover="Tip(\''.$field_help[$field_name].'\')" onmouseout="UnTip()"');
              echo ('>');
            }
            echo ('</td><td>');
            if ($_POST['relsrc'] != "") { $defval = $row[$i]; } else { $defval = ""; }
            if ($field_name == "date") { $defval = date("Y-m-d H:i:s"); }
            if (isset($foreign_keys[$field_name])) {
              echo ('<select name="reldef_'.$field_name.'">');
              $optcount = 0;
              foreach ($foreign_keys[$field_name] as $fk) {
                echo ('<option value="'.$fk[0].'"');
                if ($fk[0] == $defval || ($defval == "" && $optcount == 0)) { echo " selected "; }
                echo ('>'.$fk[1].'</option>');
                $optcount++;
              }
              echo ('</select>');
            } else {
              if ($field_name == "userfk") {
                echo ('<input type="hidden" name="reldef_userfk" value="'.$userref.'">'.$sslusername);
              } else {
                echo ('<input type="text" name="reldef_'.$field_name.'" size="30" value="'.$defval.'">');
              }
            }
            echo ('</td></tr>');
          }
        }
      }
      $mode = "Send";
      echo ('<input type="hidden" name="define" value="yes">');
      echo ('<input type="hidden" name="relsrc" value="'.$_POST['relsrc'].'">');
    } else {
      // Definition source selection
      echo ('<tr><td class="selection">Please select the definition source</td></tr><tr><td>');
      echo ('<center>');
      echo ('<select name="relsrc">');
      $rowsel=0;
      echo ('<option value="">- new -</option>');
      $qry_res = db_query("SELECT ref,name FROM release_data ORDER BY date DESC");
      while ($row = mysql_fetch_row($qry_res)) {
        if ($row[0] == $rowsel) {
          echo ('<option value="'.$row[1].'" selected>'.$row[1].'</option>');
        } else {
          echo ('<option value="'.$row[1].'">Clone release '.$row[1].'</option>');
        }
      }
      echo ('</select>');
      echo ('</center>');
      $mode = "Select";
    }
  }
?>
</td></tr>
</TABLE>
<P>

<?php if (isset($mode)) { ?>
<input type="submit" name="submit" value="<?php echo $mode; ?>">
<input type="reset" name="reset" value="Reset">
</form>
<?php } ?>
</CENTER>
</TD></TR>
<TR><TD height="30" background="../img/bar2.gif">&nbsp;</TD><TD>&nbsp;</TD></TR>
</TABLE>

<P>
<A HREF="mailto:Alessandro.DeSalvo@roma1.infn.it">For comments or informations please send me a mail (Alessandro.DeSalvo@roma1.infn.it)</A>
<BR>
</BODY>
</HTML>
