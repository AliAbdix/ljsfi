<?php
  require("user_info.php");
  $admin_list = get_user_info("emails",NULL,"master",True,"%");
  $to = array();
  foreach ($admin_list as $emails) { array_push($to,$emails["email"]); }
  print "ADMINS: ".implode(",",$to)."\n";
  $to = array();
  $user_info = get_user_info("subscribers",NULL,NULL,True,"INFN-ROMA1");
  foreach ($user_info as $emails) { array_push($to,$emails["email"]); }
  print "SUBSCRIBERS: ".implode(",",$to)."\n";
  $to = array();
  $user_info = get_user_info("subscribers",NULL,NULL,True,"UKI-NORTHGRID-LIV-HEP");
  foreach ($user_info as $emails) { array_push($to,$emails["email"]); }
  print "SUBSCRIBERS: ".implode(",",$to)."\n";
?>
