<?php
  require("db.php");
  require("guid.php");
  require("config.php");
?>
<HTML>
<HEAD>
<TITLE><?php echo $LJSFi_VO; ?> Installation Logfile Access</TITLE>

<link rel="STYLESHEET" type="text/css" href="../ai.css">
<link rel="shortcut icon" href="../img/favicon.ico">

</HEAD>
<BODY>

<P>

<TABLE id='jdl_tbl' border="1" cellspacing="0" rules="groups" width="100%" summary="<?php echo $LJSFi_VO; ?> Installation JDL viewer">
<TR><TD colspan="3" class="caption"><?php echo $LJSFi_VO; ?> Installation JDL viewer</TD></TR>
<TR><TD colspan="3" height="30">&nbsp</TD></TR>
<TR><TD width="20">&nbsp&nbsp</TD><TD class="graytable">
<?php
  $sslusername = getenv("SSL_CLIENT_S_DN_CN");
  $ssluserdetails = getenv("SSL_CLIENT_S_DN");
  $result = db_query("SELECT user.ref, role.description FROM user,role WHERE name='" . $sslusername . "' AND dn='" . $ssluserdetails . "' AND user.rolefk=role.ref");
  $row = mysql_fetch_row($result);
  if (!$row) {
    $role="";
  } else {
    $adminfk=$row[0];
    $role=$row[1];
  }

  # Get the ID
  if (isset($_REQUEST['id']) && $_REQUEST['id'] != '') $jid=$_REQUEST['id'];

  # Fetch the record
  if (isset($jid)) {
      $query  = ("SELECT jdl.content FROM jdl WHERE ref=".$jid);
      $result = db_query($query);
      $row = mysql_fetch_row($result);
      if ($row) {
          echo nl2br(htmlentities($row[0]));
      } else {
          echo ('<center>No jdl found</center>');
      }
  } else {
      echo ("<center>No ID specified</center>");
  }
?>
</TD><TD width="20">&nbsp&nbsp</TD></TR>
<TR><TD colspan="3" height="30">&nbsp</TD></TR>
</TABLE>

<P>
<A HREF="mailto:Alessandro.DeSalvo@roma1.infn.it">For comments or informations please send me a mail (Alessandro.DeSalvo@roma1.infn.it)</A>
<BR>
</BODY>
</HTML>
