<?php
  require("db.php");
  require("guid.php");
  require("config.php");
?>
<?php if (!isset($_POST['mode'])) { ?>
<HTML>
<HEAD>
<TITLE><?php echo $LJSFi_VO; ?> Installation Logfile Access</TITLE>

<link rel="STYLESHEET" type="text/css" href="../ai.css">
<link rel="shortcut icon" href="../img/favicon.ico">

</HEAD>
<BODY>

<P>

<TABLE id='log_tbl' border="1" cellspacing="0" rules="groups" width="100%" summary="<?php echo $LJSFi_VO; ?> Installation Logfile Access">
<TR><TD colspan="3" class="caption"><?php echo $LJSFi_VO; ?> Installation Logfile Access</TD></TR>
<TR><TD colspan="3" height="30">&nbsp</TD></TR>
<TR><TD width="20">&nbsp&nbsp</TD><TD class="graytable">
<?php } ?>
<?php
  $sslusername = getenv("SSL_CLIENT_S_DN_CN");
  $ssluserdetails = getenv("SSL_CLIENT_S_DN");
  $result = db_query("SELECT user.ref, role.description, user.priv_view FROM user,role WHERE name='" . $sslusername . "' AND dn='" . $ssluserdetails . "' AND user.rolefk=role.ref");
  $row = mysql_fetch_row($result);
  if (!$row) {
    $role="";
  } else {
    $adminfk=$row[0];
    $role=$row[1];
    $priv_view=$row[2];
  }

  if (!isset($priv_view)) {
    echo ("Unknown user. Please register <A HREF='user.php'>here</A>\n");
  } elseif ($priv_view != 1) {
    echo ("<FONT SIZE=+1 COLOR='red'><B>");
    echo ("You don't have permissions to view logs.<BR>\n");
    echo ("Please check your registration and ask for the view privilege <A HREF='user.php'>here</A>\n");
    echo ("</B></FONT>");
  } else {
    // Start the form
    # Get the ID
    if (isset($_POST['id']) && $_POST['id'] != '') $rid=$_POST['id'];
    if (isset($_GET['id'])  && $_GET['id'] != '')  $rid=$_GET['id'];

    if (isset($_POST['mode']) && $_POST['mode'] == 'upload') {
      if (isset($_FILES['file']['name']) && isset($_POST['jobid'])) {
        # Check the job id
        $query   = "SELECT job.ref FROM job WHERE id='".$_POST['jobid']."'";
        $checkid = db_query($query);
        $numrows = mysql_num_rows($checkid);
        if ($numrows > 0) {
          $guid            = guid();
          $logfile         = $_FILES['file']['name'];
          $fpath_container = date('Y-m-d');
          $fpath           = $fpath_container."/".$guid."/";
          $fname           = $upload_path.$fpath.$logfile;
          if (!file_exists($upload_path.$fpath_container))
            mkdir($upload_path.$fpath_container, 0777);
          if (!file_exists($upload_path.$fpath))
            mkdir($upload_path.$fpath, 0777);
  
          if (!move_uploaded_file($_FILES['file']['tmp_name'],$fname)) {
            echo ("Error while saving the logfile");
            die();
          }
          $query  = "UPDATE job SET logfile='".$fpath.$logfile."' WHERE id='".$_POST['jobid']."'";
          $result = db_query($query);
          if(isset($result)) echo $fpath.$logfile;
        }
      }
    } else {
      # Fetch the record
      if (isset($rid)) {
        $query  = ("SELECT job.logfile FROM job WHERE ref=".$rid);
        $result = db_query($query);
        $row = mysql_fetch_row($result);
        $logfile = $row[0];
        $fname = $upload_path.$logfile;
        if ($logfile != '' && file_exists($fname)) {
          $gzfile = gzopen($fname, "r");
          while (!gzeof($gzfile)) {
            $chunk = gzread($gzfile,4096);
            echo nl2br(htmlentities($chunk));
          }
          gzclose($gzfile);
        } else {
          echo ('<center>No logfile available for this job</center>');
        }
      } else {
        echo ("<center>No ID specified</center>");
      }
    }
  }
?>
<?php if (!isset($_POST['mode'])) { ?>
</TD><TD width="20">&nbsp&nbsp</TD></TR>
<TR><TD colspan="3" height="30">&nbsp</TD></TR>
</TABLE>

<P>
<A HREF="mailto:Alessandro.DeSalvo@roma1.infn.it">For comments or informations please send me a mail (Alessandro.DeSalvo@roma1.infn.it)</A>
<BR>
</BODY>
</HTML>
<?php } ?>
