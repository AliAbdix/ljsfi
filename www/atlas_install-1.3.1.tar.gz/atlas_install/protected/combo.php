<?php
function combo_box ($values="",$def_choice="-",$selection="",$descr=""){
    $has_selection = false;
    if ($descr == "") {
      $descr=$values;
    }
    echo '<option value="" ';
    if ($selection == "") echo ' selected';
    echo '>' . $def_choice . '</option>';
    for ($i=0;$i<count($values);$i++) {
      echo '<option value="',$values[$i],'"';
      if ($selection == $values[$i]) {
        echo 'selected';
        $has_selection = true;
      }
      echo '>',$descr[$i],'</option>';
      echo "\n";
    }
    return $has_selection;
}
?>
