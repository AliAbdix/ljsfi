<?php
  require("db.php");

  function set_site_info() {
    $sres = db_query("SELECT ref FROM site WHERE cename='" . $_POST['cename'] . "' ORDER BY ref DESC LIMIT 1");
    $srow = mysql_fetch_row($sres);
    if ($srow) {
      $query = "UPDATE site SET ";
      $query_fields = array();
      if (isset($_POST["sitename"]) && $_POST["sitename"] != "") array_push($query_fields, "name='".$_POST["sitename"]."'");
      if (isset($_POST["cs"]) && $_POST["cs"] != "") array_push($query_fields, "cs='".$_POST["cs"]."'");
      if (isset($_POST["swarea"]) && $_POST["swarea"] != "") array_push($query_fields, "swarea='".$_POST["swarea"]."'");
      if (isset($_POST["fstype"]) && $_POST["fstype"] != "") array_push($query_fields, "fstype='".$_POST["fstype"]."'");
      if (isset($_POST["mountpoint"]) && $_POST["mountpoint"] != "") array_push($query_fields, "mountpoint='".$_POST["mountpoint"]."'");
      if (isset($_POST["capacity"]) && $_POST["capacity"] != "") array_push($query_fields, "capacity=".$_POST["capacity"]);
      if (isset($_POST["available"]) && $_POST["available"] != "") array_push($query_fields, "available=".$_POST["available"]);
      if (isset($_POST["quota"]) && $_POST["quota"] != "") array_push($query_fields, "quota=".$_POST["quota"]);
      $query .= join(",",$query_fields)." WHERE cename='" . $_POST['cename'] . "'";
      $res   = db_query($query);
      if ($res) {
          echo ("INSTALL SERVER> Site info updated successfully for CE ".$_POST['cename'].".\n");
      } else {
          echo ("INSTALL SERVER> Cannot update site info for CE ".$_POST['cename'].".\n");
      }
    }
    return 0;
  }

  if (isset($_POST["cename"]) && $_POST["cename"] != "") set_site_info();
?>
