<?php
  // The DB server name, server user and password
  $LJSFi_dbname = "atlas_install";
  $LJSFi_dbserv = "localhost";
  $LJSFi_dbuser = "dbwriter";
  $LJSFi_dbpass = "dbwriter";
  $dbconn       = NULL;

  // Connection function
  function db_conn() {
    global $LJSFi_dbname, $LJSFi_dbserv, $LJSFi_dbuser, $LJSFi_dbpass, $dbconn;
    $dbconn = @mysql_connect($LJSFi_dbserv,$LJSFi_dbuser,$LJSFi_dbpass);
    if (!$dbconn) {
      echo ( "<P>Cannot connect to db server $LJSFi_dbserv</P>");
      exit();
    }
    if (!@mysql_select_db($LJSFi_dbname, $dbconn)) {
      echo ( "<P>Unable to select db $LJSFi_dbname</P>" );
      exit();
    }
  }

  // Error function
  function db_err($err) {
    echo ("<P>ERROR: " . $err . "</P>");
    exit();
  }

  // Query handler
  function db_query($query) {
    global $dbconn;
    if (!isset($dbconn)) db_conn();
    $result = mysql_query($query);
    if (!$result) {
      db_err(mysql_error());
    } else {
      return $result;
    }
  }
?>
