<?php
  require("db.php");

  $sslusername = getenv("SSL_CLIENT_S_DN_CN");
  $ssluserdetails = getenv("SSL_CLIENT_S_DN");
  $result = db_query("SELECT user.ref, role.description FROM user,role WHERE name='" . $sslusername . "' AND dn='" . $ssluserdetails . "' AND user.rolefk=role.ref");
  $row = mysql_fetch_row($result);
  if (!$row) {
    $role="";
  } else {
    $adminfk=$row[0];
    $role=$row[1];
  }

  # Query header
  $q_hdr  = "SELECT DISTINCT(rd.tag),rd.name,(SELECT site.cs FROM site WHERE site.cename=s.cename ORDER BY site.ref DESC LIMIT 1)";
  $q_body =  " FROM release_data rd,release_stat r,site s"
           ." WHERE rd.name=r.name AND r.sitefk=s.ref AND rd.tag <> '' AND r.status='installed'";

  # Fetch the records
  $query  = ($q_hdr . $q_body);
  if (isset($_REQUEST['rel'])) $query .= (" AND rd.name like '" . $_REQUEST['rel'] . "'");
  if (isset($_REQUEST['cename']))  $query .= (" AND s.cename='" . $_REQUEST['cename'] . "'");
  # Select obsolete/production releases
  # excluding internal (typefk=1) and nightly (typefk=3) releases
  if (isset($_REQUEST['obsolete'])) $query .= (" AND rd.obsolete=" . $_REQUEST['obsolete']." AND rd.typefk <> 1 AND rd.typefk <> 3");
  $query .= (" ORDER BY rd.tag ASC");
  $result = db_query($query);
  while ( $row = mysql_fetch_row($result) ) {
    if (isset($_REQUEST['showrel'])) echo $row[0].",";
    echo $row[0];
    if (isset($_REQUEST['showcs'])) echo ",".$row[2];
    print "\n";
  }
?>
