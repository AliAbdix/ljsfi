<?php

# Path where to upload the files
$upload_path = "/data/logfiles/";

# Debug flag (0 --> no debug output, > 0 --> debug output)
$debug = 1;

# Log prefix for debug messages
$logprefix = "[LJSFi]";

# VO name
$LJSFi_VO = "ATLAS";

# Agent email
$LJSFi_email = "no-reply@atlas-install.roma1.infn.it";

# Contact persons
$LJSFi_contacts = "atlas-grid-install@cern.ch";

# Software installation protocol
$LJSFi_swinst_proto = "atlassw";

# Default infosys
$LJSFi_default_infosys = "atlas-bdii.cern.ch";

?>
