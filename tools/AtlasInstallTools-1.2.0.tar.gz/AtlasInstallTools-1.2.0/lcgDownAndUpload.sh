version=$1
internal_tar_name=$2
vo_name=$3
host_SE=$4

echo "Listing $MAINPATH"
\ls $MAINPATH

cd $EXP_PATH

source $EXP_PATH/setup-installation.sh

# copy the experiment scripts in the temporary directory to build the tarball..
chmod +x $EXP_PATH/*
# Prepare the local cache
mkdir -p localcache/temp
cd localcache/temp

# Setup pacman for our architecture
pacman -version
pacman -v down tar up
pacman -def

# Get the compiler and do the snapshot
pacman $PACMAN_OPTS \
       -fetch http://classis01.roma1.infn.it/pacman/cache:$version/gcc${arch}
pacman $PACMAN_OPTS -snap
mv gcc${arch}.snap ..
rm -fr *

# Get KV and do the snapshot
pacman $PACMAN_OPTS \
       -fetch http://classis01.roma1.infn.it/pacman/cache:$version/KitValidation
pacman $PACMAN_OPTS -snap
mv KitValidation.snap ..
rm -fr *

# Get the release and do the snapshot
pacman $PACMAN_OPTS -fetch ATLAS:$version/AtlasRelease${arch}-opt
pacman $PACMAN_OPTS -snap
mv AtlasRelease${arch}-opt.snap ..
cd ..
rm -fr temp
cd ..
rm -fr stderror stdout

# Calculate the checksums
rm -f MD5SUM
find . -type f -exec md5sum {} \; | grep -v MD5SUM >> MD5SUM
 
# Build and register the tar file
echo "Listing $EXP_PATH"
\ls $EXP_PATH

tar cvfz $internal_tar_name * > /dev/null
  if [ ! $? -eq "0" ]; then
   echo "Tarball SW-EXP creation: FAILED. " >&2
   exit 
  fi 
lcg-cr --vo=$vo_name file:$PWD/$internal_tar_name -d $host_SE -l $internal_tar_name >okkio
  if [ ! $? -eq "0" ]; then
   echo "Tarball not uploaded in the grid:. " >&2
   exit 
  fi  
rm -fr *
