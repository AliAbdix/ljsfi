#!/usr/bin/perl
$ATLAS=$ARGV[0];
$REL=$ARGV[1];
$PACKAGE=$ARGV[2];
%depFileList = ();

recurse_dep($ATLAS, "pacman", "$REL/$PACKAGE");

exit;

sub recurse_dep() {
	my ($cache,$prefix,$packg) = @_;
	my $i, $pkg="$prefix/$packg.pacman";
	my @depend_list = ();
	my $pkgPath = "$prefix/$packg";
	my $source, $locSource, $download, $URL, $ExternalSource = 0;
	$pkgPath =~ s/(.*)\/(.*)$/$1/;
	if (!-r $pkg) {
		print "Retrieving $cache/$packg.pacman...";
		system ("mkdir -p $pkgPath; cd $pkgPath; wget -q -c -nd -nc $cache/$packg.pacman\n");
		print "done\n";
	}
	if (!exists $depFileList->{"$packg"}) {
		$depFileList->{"$packg"} = 1;
		print "Analyzing dependancies for $packg\n";
		open (PKG, $pkg) || die ("Cannot open $pkg");
		while (<PKG>) {
			if (/depends(.*)=(.*)\[(.*)\]/) {
				$str = $3; $str =~ s/,//g;
				@depend_list = split (/'/,$str);
			}
			if (/source(.*)=(.*)'(.*)'/) {
				$source = $3;
				$locSource = $source;
				$locSource =~ s/^http:\/\///;
				if (/http:\/\//) { $ExternalSource = 1 };
			}
			if (/download(.*):(.*)'(.*)'/) {
				$download = $3;
			}
		}
		close (PKG);
		if ($ExternalSource == 1) {
			$URL="$source/$download";
			fixExtSource($pkg);
		} else {
			$URL="$cache/$locSource/$download";
		}

# Retrieve the package
		if (!-r "$prefix/$locSource/$download") {
			print "$packg: Retrieving $URL...";
			system ("mkdir -p $prefix/$locSource; cd $prefix/$locSource; wget -q -c -nd -nc $URL");
			print "done\n";
		}

# Loop on dependancies
		foreach my $depend (@depend_list) {
			next if ($depend =~ /^ /);
			recurse_dep($cache,$prefix,$depend);
		}
	}
	return;
}

sub fixExtSource () {
	my $fname = shift (@_);

	print "Fixing external source in $fname...";

	system ("mv $fname $fname.bak");
	open (INFNAME, "$fname.bak") || die ("Cannot open $fname.bak for input");
	open (OUTFNAME, ">$fname") || die ("Cannot open $fname for output");

	while (<INFNAME>) {
		$record = $_;
		if (/^source/) {
			$record =~ s/http:\/\///;	
		}
		print OUTFNAME "$record";
	}

	close (OUTFNAME);
	close (INFNAME);

	print "done\n";

	return;
}
