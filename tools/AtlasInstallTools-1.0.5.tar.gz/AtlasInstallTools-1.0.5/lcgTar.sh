input_file=$1
echo "untarring the tarballs......."
cd $EXP_PATH
for tar_file in $input_file*.tar.gz;
do
 if [ -f $tar_file ]; then
echo $tar_file;
tar xvzf $tar_file > /dev/null;
fi
done

