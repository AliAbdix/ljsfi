export ATLASPROJECTSCACHE="http://atlas.web.cern.ch/Atlas/GROUPS/SOFTWARE/OO/pacman/projects/cache"
[ "$PACMAN_VER" == "" ] && export PACMAN_VER=3.15
[ "$LCG_CATALOG_TYPE" == "" ] && export LCG_CATALOG_TYPE="lfc"
if [ "$LCG_CATALOG_TYPE" == "lfc" -a "$CATALOG_PATH" == "" ] ; then
  export CATALOG_PATH="/grid/atlas/install/lcg/"
fi
export PACMAN_DIR=pacman-${PACMAN_VER}
export PACMAN_TAR=${PACMAN_DIR}.tar.gz
export PACMAN_URL=http://physics.bu.edu/~youssef/pacman/sample_cache/tarballs
[ "$PACMAN_OPTS" == "" ] && export PACMAN_OPTS="-trust-all-caches -allow unsupported-platforms -allow bad-tar-filenames"
if [ "$platform" != "" -a "$platform" != "auto" ] ; then
  export PACMAN_OPTS="$PACMAN_OPTS -pretend-platform $platform"
fi

if [ "$VERSION" != "" ] ; then
    VERMAIN="`echo $VERSION | cut -d '.' -f 1`"
    # Rotate the installation areas each 3 releases of the same major number
    [ "$VERAREA" == "" ] && VERAREA=$((`echo $VERSION | cut -d '.' -f 3` % 3))
    [ "$ATLASINSTALL_PATH" == "" ] && \
        ATLASINSTALL_PATH=$MAINPATH/software/$VERSION
    # Use different directories for production and development releases
    VERTYPE=`echo $VERSION | cut -d '.' -f 2`
    [ $VERTYPE -eq 0 ] && VERDIR="prod" || VERDIR="dev"
    [ "$ATLASINSTREL_PATH" == "" ] && \
        ATLASINSTREL_PATH=$MAINPATH/$VERDIR/releases/rel_${VERMAIN}-${VERAREA}
    [ ! -d $ATLASINSTALL_PATH ] && mkdir -p $ATLASINSTALL_PATH
    [ ! -d $ATLASINSTREL_PATH ] && mkdir -p $ATLASINSTREL_PATH
fi

CURDIR=$PWD
cd $MAINPATH
if [ ! -d $PACMAN_DIR ]; then
  echo "Pacman not found: installing it."
  echo "Checking for pacman in the RM:"
  echo "    ---> lcg-lg --vo atlas lfn:${CATALOG_PATH}${PACMAN_TAR}"
  lcg-lg --vo atlas lfn:${CATALOG_PATH}${PACMAN_TAR} > /dev/null
  if [ ! $? -eq "0" ]; then
    echo "Pacman not found in the RM. Downloading it"
    wget $PACMAN_URL/$PACMAN_TAR
    echo "Registering $PACMAN_TAR into the RM:"
    echo "  ---> lcg-cr --vo atlas file:$PWD/$PACMAN_TAR -l ${CATALOG_PATH}${PACMAN_TAR}"
    lcg-cr --vo atlas file:$PWD/$PACMAN_TAR -l ${CATALOG_PATH}${PACMAN_TAR}
  else
    echo "Getting $PACMAN_TAR from the RM:"
    echo "  ---> lcg-cp --vo atlas lfn:${CATALOG_PATH}${PACMAN_TAR} file:$PWD/$PACMAN_TAR"
    lcg-cp --vo atlas lfn:${CATALOG_PATH}${PACMAN_TAR} file:$PWD/$PACMAN_TAR
    if [ $? != 0 ] ; then
      echo "Failed to get pacman from the RM. Getting it from the web"
      wget $PACMAN_URL/$PACMAN_TAR
    fi
  fi
  \ls -l $PACMAN_TAR
  tar xzvf $PACMAN_TAR
  rm -fr $PACMAN_TAR
fi

cd $PACMAN_DIR
source setup.sh
cd $CURDIR
