#!/usr/bin/perl

use Getopt::Long;
GetOptions("vo=s"=> \$experiment, "host=s" => \$host, "version=s" => \$version);
open tarball, "< $ENV{'MAINPATH'}/tarball.list"
or warn "mabageTar:Can't open file: tarball.list, probably it does not exist yet\n";
$i=0;
while (<tarball>){
	chomp;
	$array = $_;
        print "for the tarball $array\n ";
	system "$ENV{'STORAGE_DIR'}/lcgCheck.sh $array $host 1 $experiment $version";	
        system "$ENV{'STORAGE_DIR'}/lcgCopy.sh $array 1 $experiment";
	system "$ENV{'STORAGE_DIR'}/lcgTar.sh $array";
	$i=$i+1;
    }
    close tarball;





