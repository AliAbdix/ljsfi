export PACMAN_VER=2.125
export PACMAN_DIR=pacman-${PACMAN_VER}
export PACMAN_TAR=${PACMAN_DIR}.tar.gz
export PACMAN_URL=http://physics.bu.edu/~youssef/pacman/sample_cache/tarballs
#export PACMAN_URL=http://physics.bu.edu/pacman/atlas
#export PACMAN_URL=https://classis01.roma1.infn.it/pacman/atlas
#export PACMAN_PYTHON=python2

ATLASINSTALL_PATH=$MAINPATH/software/$VERSION
if [ ! -d $ATLASINSTALL_PATH ] ; then
  mkdir -p $ATLASINSTALL_PATH
fi

CURDIR=$PWD
cd $MAINPATH
if [ ! -d $PACMAN_DIR ]; then
  echo "Pacman not found: installing it."
  echo "Checking for pacman in the RM:"
  echo "    ---> lcg-lg --vo atlas lfn:$PACMAN_TAR"
  lcg-lg --vo atlas lfn:$PACMAN_TAR > /dev/null
  if [ ! $? -eq "0" ]; then
    echo "Pacman not found in the RM. Downloading it"
    wget $PACMAN_URL/$PACMAN_TAR
    echo "Registering $PACMAN_TAR into the RM:"
    echo "  ---> lcg-cr --vo atlas file:$PWD/$PACMAN_TAR -l $PACMAN_TAR"
    lcg-cr --vo atlas file:$PWD/$PACMAN_TAR -l $PACMAN_TAR
  else
    echo "Getting $PACMAN_TAR from the RM:"
    echo "  ---> lcg-cp --vo atlas lfn:$PACMAN_TAR file:$PWD/$PACMAN_TAR"
    lcg-cp --vo atlas lfn:$PACMAN_TAR file:$PWD/$PACMAN_TAR
    if [ $? != 0 ] ; then
      echo "Failed to get pacman from the RM. Getting it from the web"
      wget $PACMAN_URL/$PACMAN_TAR
    fi
  fi
  \ls -l $PACMAN_TAR
  tar xzvf $PACMAN_TAR
  rm -fr $PACMAN_TAR
fi

cd $PACMAN_DIR
source setup.sh
cd $CURDIR
