#!/bin/bash
name_tar=$1
number_oftar=$2
vo_name=$3
echo "copying the tarballs from the SE.............."
cd $EXP_PATH
 i=1
 while [ $i -le $number_oftar ]
 do
  if [ "$number_oftar" -eq "1" ]; then
      nametar=${name_tar}.tar.gz
  else
   nametar=${name_tar}_${i}.tar.gz
  fi
   i=`expr $i + 1`
  if [ ! -f $nametar ]; then
   edg-rm --vo=$vo_name copyFile lfn:$nametar file://`pwd`/$nametar
   if [ ! $? -eq "0" ]; then
    echo "lcgCopy:The copyFile command has been unsuccessfully. " >&2
   exit -1
   fi 
  fi
 done
cd ..

