"""A client to handle data on file volumes processed."""

import common.DQPing
import sys

from common.client.DQClient import DQClient
from common.DQConstants import HTTP
from common.DQException import DQInvalidConfigurationException


class MonitorClient (DQClient):
    """
    (since 0.2.0)
    """


    def __init__(self, url=None, urlsec=None, certificate=None, ca_path=None):
        """
        Constructs a MonitorClient instance.
        (since 0.2.0)
        
        url is the non-secure URL of the host to be contacted.
        urlsec is the secure URL of the host to be contacted.
        certificate is the proxy certificate.
        ca_path is the location of the Certification Authority certificates.
        """
        DQClient.__init__(self, url, urlsec, certificate, ca_path)


    def addFilesInfo(self, dsn, size, numfiles, typ='0'):
        """
        POST request to insert info on files transferred.
        (since 0.2.0)
        
        dsn is the dataset name.
        size is TODO.
        numfiles is the number of files.
        typ is TODO.
        """
        
        self.type = HTTP.POST
        self.request = '/filemonitor/addFiles'
        self.is_secure = True
        self.params = {'site': dsn, 'size': size, 'number': numfiles, 'typ': typ}
        
        return self.send()


    def auto_configure():
        """
        Returns this client configuration.
        (since 0.2.0)
        
        (url_insecure_host, url_secure_host)
        """
        import client_conf
        
        return (
            client_conf.monitor['insecure'],
            client_conf.monitor['secure']
        )

    auto_configure = staticmethod(auto_configure)


    def is_ddm_server_alive (self):
        """
        Returns the status of the DDM server.
        (since 0.2.1)
        """
        
        self.type = HTTP.GET
        self.request = '/monitor/isAlive'
        self.params = {}
        
        return self.send()


def usage():
    """
    Usage: python MonitorClient.py <command> <args>

      Commands:

      addFilesInfo <site name> <total file size> <num files>
      """
    print usage.__doc__


def main(argv):
    """
    (since 0.2.0)
    """
    
    if len(argv) < 2:
        usage()
        sys.exit(1)
        
    if argv[0]=='addFilesInfo':
        r = MonitorClient()
        #out = r.addFilesInfo(argv[1], argv[2], argv[3])
        out = r.addFilesInfo(argv[1], argv[2], argv[3], 1)
    else:
        print 'Unknown command:',argv[0]
        sys.exit(1)
    
    print out


if __name__ == '__main__':
    """
    (since 0.2.0)
    """
    monitorClient = MonitorClient()
    monitorClient.is_ddm_server_alive()
    #main(sys.argv[1:])
