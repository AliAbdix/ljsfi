"""Client to the dataset content central catalog."""

import common.DQValidator
import os
import string
import sys

from common.client.DQClient import DQClient
from common.DQConstants import HTTP
from common.DQException import DQException, DQInvalidRequestException
from common.client.x509 import getCAPath
from common.client.x509 import getX509


# MODULE classes


class ContentClient (DQClient):
    """
    Class to make requests to the dataset content central catalog.
    (since 0.2.0)
    """


    def __init__ (self, url=None, urlsec=None, certificate=None, ca_path=None):
        """
        Constructs a ContentClient instance.
        (since 0.2.0)
        
        url is the non-secure URL of the host to be contacted.
        urlsec is the secure URL of the host to be contacted.
        certificate is the proxy certificate.
        ca_path is the location of the Certification Authority certificates.
        """
        DQClient.__init__(self, url, urlsec, certificate, ca_path)


    def addDataset (self, vuid, lfns, guids):
        """
        POST request to insert new dataset and associated files.
        (since 0.2.0)
        """
        
        common.DQValidator.is_uid(vuid)
        common.DQValidator.is_list_of_lfns(lfns)
        common.DQValidator.is_list_of_uids(guids)
        
        if len(lfns) != len(guids):
            raise DQInvalidRequestException('lfns and guids lists must be the same length')
        
        g = ''
        for i in range(len(guids)):
            lfn = lfns[i]
            common.DQValidator.is_lfn(lfn)
            guid = guids[i]
            common.DQValidator.is_uid(guid)
            
            g += '%s@%s@' % (lfn, guid)
        g = g[:-1]
        
        self.type = HTTP.POST
        self.request = '/content/dataset'
        self.params = {'vuid': vuid, 'data': g}
        
        return self.send()


    def auto_configure():
        """
        Returns this client configuration.
        (since 0.2.0)
        
        (url_insecure_host, url_secure_host)
        """
        import client_conf
        
        return (
            client_conf.content['insecure'],
            client_conf.content['secure']
        )

    auto_configure = staticmethod(auto_configure)


    def addFileToDataset (self, vuid, lfn, guid):
        """
        PUT request to add a file to a dataset.
        (since 0.2.0)
        """
        
        common.DQValidator.is_uid(vuid)
        common.DQValidator.is_lfn(lfn)
        common.DQValidator.is_uid(guid)
        
        g = '%s@%s' % (lfn, guid)
        
        self.type = HTTP.PUT
        self.request = '/content/dataset'
        self.params = {'vuid': vuid, 'data': g}
        
        return self.send()


    def addFilesToDataset (self, vuid, lfns, guids):
        """
        PUT request to add multiple files to a dataset.
        (since 0.2.0)
        """
        
        common.DQValidator.is_uid(vuid)
        common.DQValidator.is_list_of_lfns(lfns)
        common.DQValidator.is_list_of_uids(guids)
        
        if len(lfns) != len(guids):
            raise DQInvalidRequestException('lfns and guids lists must be the same length')

        g = ''
        for i in range(len(guids)):
            lfn = lfns[i]
            guid = guids[i]
            common.DQValidator.is_lfn(lfn)
            common.DQValidator.is_uid(guid)
            
            g += '%s@%s@' % (lfn, guid)
        g = g[:-1]
        
        self.type = HTTP.PUT
        self.request = '/content/dataset'
        self.params = {'vuid': vuid, 'data': g}
        
        return self.send()


    def deleteDataset (self, vuid):
        """
        Deletes all the files from a dataset and hence
        the whole dataset entry.
        (since 0.2.0)
        """
        
        common.DQValidator.is_uid(vuid)
        
        #files = self.queryFilesInDataset(vuid)
        
        #if len(files) > 0:
        #    self.deleteFilesFromDataset(vuid, files.keys())            
        
        self.type = HTTP.DELETE
        self.request = '/content/dataset'
        self.params = {'vuid': vuid}
        self.send()
        
        return 'Dataset Deleted'


    def deleteFilesFromDataset (self, vuid, guids, newvuid):
        """
        PUT request to add multiple files to a dataset.
        (since 0.2.0)
        
        vuid is the dataset version unique identifier where the files will be deleted.
        lfns ...
        newvuid is the dataset version unique identifier where the files will be registered.
        """
        
        common.DQValidator.is_uid(vuid)
        common.DQValidator.is_uid(newvuid)
        common.DQValidator.is_list_of_uids(guids)
        
        self.type = HTTP.DELETE
        self.request = '/content/files'
        self.params = {'vuid': vuid, 'files': guids, 'newvuid': newvuid}
        
        return self.send()


    def queryFilesInDataset (self, vuid):
        """
        GET request to find the files in the dataset given by vuid.
        (since 0.2.0)
        
        Returns a dictionary of guids mapped to lfns.
        """
        
        common.DQValidator.is_uid(vuid)
        
        self.type = HTTP.GET
        self.request = '/content/files'
        self.params = {'vuid': vuid}
        
        return self.send()


    def queryDatasetsWithFileByGUID (self, guid):
        """
        GET request to get the vuids of datasets containing
        the given file GUID.
        (since 0.2.0)
        """
        
        common.DQValidator.is_uid(guid)
        
        self.type = HTTP.GET
        self.request = '/content/datasets'
        self.params = {'guid': guid}
        
        return self.send().split()


    def queryDatasetsWithFileByLFN (self, file):
        """
        GET request to get the vuids of datasets containing
        the given file LFN.
        (since 0.2.0)
        """
        
        common.DQValidator.is_lfn(file)
        
        self.type = HTTP.GET
        self.request = '/content/datasets'
        self.params = {'lfn': file}
        
        return self.send().split()


# MODULE methods


def usage():
    """
    Usage: python ContentClient.py <command> <args>
    
      Commands:
    
      addDataset <dataset vuid> <lfn1 guid1 lfn2 guid2 ...>
      addFilesToDataset <dataset vuid> <lfn1 guid1 lfn2 guid2..>
      queryFilesInDataset <dataset vuid>
      queryDatasetsWithFileByGUID <guid>
      queryDatasetsWithFileByLFN <lfn>
      deleteFilesFromDataset <vuid> <lfns []> <newvuid>
      deleteDataset <vuid>
    """
    print usage.__doc__


def main(argv):
    """
    (since 0.2.0)
    """
    if len(argv) < 2:
        usage()
        sys.exit(1)
    
    # retrieving client configuration
    client = ContentClient()
    
    try:
        if argv[0]=='queryFilesInDataset':
            out = client.queryFilesInDataset(argv[1])
        elif argv[0]=='queryDatasetsWithFileByGUID':
            out = client.queryDatasetsWithFileByGUID(argv[1])
        elif argv[0]=='queryDatasetsWithFileByLFN':
            out = client.queryDatasetsWithFileByLFN(argv[1])
        elif argv[0]=='addDataset':
            guids = []
            lfns = []
            for i in range(0, len(argv[2:]), 2):
                lfns.append(argv[2+i])
                guids.append(argv[3+i])
            out = client.addDataset(argv[1], lfns, guids)
        elif argv[0]=='addFilesToDataset':
            guids = []
            lfns = []
            for i in range(0, len(argv[2:]), 2):
                lfns.append(argv[2+i])
                guids.append(argv[3+i])
            out = client.addFilesToDataset(argv[1], lfns, guids)
        elif argv[0]=='deleteFilesFromDataset':
            out = client.deleteFilesFromDataset(argv[1], eval(argv[2]), argv[3])
        elif argv[0]=='deleteDataset':
            out = client.deleteDataset(argv[1])
        else:
            print 'Unknown command:',argv[0]
            sys.exit(1)

        print out

    except DQException, err_msg:
        sys.stderr.write('Error: '+str(err_msg)+'\n')


if __name__ == '__main__':
    """
    (since 0.2.0)
    """
    main(sys.argv[1:])
