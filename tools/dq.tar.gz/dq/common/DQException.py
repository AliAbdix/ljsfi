import string

class DQException(Exception):
    """
    Base exception class.
    (since 0.2.0)
    
    There can only be one class variable
    (self.desc for example) but this can contain an ordered array
    so that the order can be reconstructed on the client side.
    """

    def __init__(self):
        """
        (since 0.2.0)
        """
        pass


    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return "DQ2 base exception"


    def __repr__(self):
        """
        Returns a Python representation of this object.
        (since 0.2.0)
        """
        if type(self.__dict__.values()[0]) is not list:
            # replace ' for "
            argument = self._escape_arguments(self.__dict__.values()[0])
            return "{'c':'" + self.__class__.__name__ + "', 'a': '" + argument + "'}"
        argument = self._escape_arguments(self.__dict__.values()[0])
        return "{'c':'" + self.__class__.__name__ + "', 'a': " + argument + "}"


    def _escape_arguments(self, argument):
        return str(argument).replace("'", '"').replace('\n', '')


class DQUnknownBackendException (DQException):
    """
    (since 0.2.0)
    """
    def __init__(self, desc):
        self.desc = desc
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return "DQ2 unknown backend exception [%s]" % self.desc
        
class DQBackendException (DQException):
    """
    (since 0.2.0)
    """
    def __init__(self, desc):
        self.desc = desc
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return "DQ2 backend exception [%s]" % self.desc


class DQSecurityException (DQException):
    """
    (since 0.2.0)
    """
    def __init__(self, desc):
        self.desc = desc
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return "DQ2 security exception [%s]" % self.desc


class DQInvalidRequestException (DQException):
    """
    (since 0.2.0)
    """
    def __init__(self, desc):
        self.desc = desc
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return "DQ2 invalid request exception [%s]" % self.desc


class DQInternalServerException (DQException):
    """
    (since 0.2.0)
    """
    def __init__(self, desc, url='', urlsec=''):
        self.desc = desc
        self.url = url
        self.urlsec = urlsec
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return "DQ2 internal server exception [\n\n%s\n\n] [\n%s\n%s\n]" % (self.desc, self.url, self.urlsec)


class DQLocationExistsException (DQException):
    """
    (since 0.2.0)
    """
    def __init__(self, dsandlocation):
        """dsandlocation is a 2-element array of [dataset, location]"""
        self.args = dsandlocation
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return "The dataset %s already exists at location %s!" % (self.args[0], self.args[1])


class DQDatasetLocationNotFoundException (DQException):
    """
    (since 0.2.0)
    """
    def __init__(self, args):
        self.args = args
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return "DQ2 No replicas found exception [%s]" % self.args


class DQSubscriptionExistsException (DQException):
    """
    DQException class for the cases when an unexpected subscription was found.
    (since 0.2.0)
    """


    def __init__(self, uid_location):
        """
        Creates an instance of DQSubscriptionExistsException.
        (since 0.2.0)
        
        uid_location is a list in the following format: [uid, location] where:
        - uid is the dataset or dataset version unique identifier
        - location is the subscription site
        """        
        self.args = uid_location
        self.help = """Please check the subscriptions for that uid:
    python SubsClient.py queryDatasetSubscriptions %s""" % (self.args[0])
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return """
A dataset subscription for %s already exists at %s!
""" % (self.args[0], self.args[1])


class DQUnknownSubscriptionException (DQException):
    """
    DQException class for the cases when an expected subscription is not found.
    (since 0.2.0)
    """
    def __init__(self, uid_location):
        """
        Creates an instance of DQUnknownSubscriptionException.
        (since 0.2.0)
        
        uid_location is a list in the following format: [uid, location] where:
        - uid is the dataset or dataset version unique identifier
        - location is the subscription location
        """
        self.args = uid_location
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return """
A dataset subscription for %s at %s doesn't exist!
Please check the subscriptions for that dataset:
    dq2 listSubscriptions %s
""" % (self.args[0], self.args[1], self.args[0])


class DQDatasetExistsException (DQException):
    """
    (since 0.2.0)
    """
    def __init__(self, dataset):
        """
        (since 0.2.0)
        """
        self.dataset = dataset
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return "The dataset %s already exists!" % self.dataset


class DQUnknownDatasetException (DQException):
    """
    (since 0.2.0)
    """
    def __init__(self, datasetargs, query=''):
        """
        datasetargs is a 4-element array [dataset name, vuid, duid, meta].
        (since 0.2.0)
        """
        self.args = datasetargs
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        str = "("
        if self.args[0] is not None: str += "dataset='%s', " % self.args[0]
        if self.args[1] is not None: str += "vuid='%s', " % self.args[1]
        if self.args[2] is not None: str += "duid='%s', " % self.args[2]
        if self.args[3] is not None: str += "meta='%s', " % self.args[3]
        str = str[:-2] + ")"
        return "DQ2 unknown dataset exception! [%s]" % (str)

class DQUnknownDatasetVersionException (DQException):
    """
    (since 0.2.0)
    """
    def __init__(self, dsn, version):
        """
        Construts a DQUnknowDatasetVersionException.
        (since 0.2.0)
        
        dsn is the dataset name.
        version is the dataset version.
        """
        self.version = version
        self.dsn = dsn
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return """Unknown dataset %s version number %s.""" % (self.dsn, self.version)
    


class DQClosedDatasetException (DQException):
    """
    (since 0.2.0)
    """
    def __init__(self, dataset):
        """
        (since 0.2.0)
        """
        self.dataset = dataset
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return "The dataset %s is closed!" % self.dataset


class DQFrozenDatasetException (DQException):
    """
    (since 0.2.0)
    """
    def __init__(self, dataset):
        """
        (since 0.2.0)
        """
        self.dataset = dataset
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return "The dataset %s is frozen!" % self.dataset


class DQOpenedDatasetException (DQException):
    """
    (since 0.2.0)
    """
    def __init__(self, dataset):
        """
        (since 0.2.0)
        """
        self.dataset = dataset
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return "The dataset %s is open!" % self.dataset


class DQFileExistsException (DQException):
    """
    (since 0.2.0)
    """
    def __init__(self, file):
        """
        (since 0.2.0)
        """
        self.file = file
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return "The file %s already exists in dataset!" % self.file


class DQUnknownFileException (DQException):
    """
    (since 0.2.0)
    """
    def __init__(self, file):
        """
        (since 0.2.0)
        """
        self.file = file
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return "DQ2 unknown file exception [%s]" % self.file


class DQAttributeExistsException (DQException):
    """
    (since 0.2.0)
    """
    def __init__(self, attr):
        """
        (since 0.2.0)
        """
        self.attr = attr
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return "The attribute %s exists!" % self.attr


class DQInvalidAttributeException (DQException):
    """
    (since 0.2.0)
    """
    def __init__(self, attrval):
        """
        attrval is a 2-element array [attribute name, value].
        (since 0.2.0)
        """
        self.args = attrval
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return "DQ2 invalid attribute exception [%s:%s]" % (self.args[0], self.args[1])


class DQParseException (DQException):
    """
    (since 0.2.0)
    """
    def __init__(self, desc):
        """
        (since 0.2.0)
        """
        self.desc = desc
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return "DQ2 parse exception [%s]" % self.desc


class DQExternalCatalogException (DQException):
    """
    (since 0.2.0)
    """
    def __init__(self, desc):
        """
        (since 0.2.0)
        """
        self.desc = desc
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return "DQ2 external catalog exception [%s]" % self.desc


class DQContentAlreadyExists (DQException):
    """
    (since 0.2.0)
    """
    def __init__(self, dsn):
        """
        (since 0.2.0)
        """
        self.dsn = dsn
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return 'No new content to be added, all files already exist in dataset %s!' % (self.dsn)


class DQInvalidConfigurationException (DQException):
    """
    DQException class for the cases where configuration errors were detected.
    (since 0.2.1)
    """
    def __init__(self, err_msg, hlp_msg=None):
        """
        Constructs an instance of DQInvalidConfigurationException.
        (since 0.2.1)
        
        err_msg is the error message.
        hlp_msg is the help message.
        """
        self.desc = err_msg
        if not hlp_msg is None:
            self.help = hlp_msg
        else:
            self.help = "Please check your client configuration settings."
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.1)
        """
        return """%s\n%s""" % (self.desc, self.help)


class DQDaoException (DQException):
    """
    DQException class for the cases when a Python or database error occur, on the central catalogs.
    (since 0.2.0)
    """
    def __init__(self, desc):
        """
        (since 0.2.0)
        """
        self.desc = desc
        self.help = 'Please check DDM server status (\'dq2 ping\') and/or contact the atlas-dq2-support@cern.ch.'
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return """
An error occurred on the central catalogs!
[%s]
""" % self.desc


class DQTiersOfATLASException (DQException):
    """
    DQException class for the cases where ToA file is corrupted, missing, or failed to download
    (since 0.2.10)
    """
    def __init__(self, desc):
        """
        (since 0.2.0)
        """
        self.desc = desc
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        (since 0.2.0)
        """
        return "DQ2 Tiers of ATLAS exception [%s]" % self.desc
        

class DQAgentException(Exception):
    """Base exception class for agents.
    """
    pass
    
