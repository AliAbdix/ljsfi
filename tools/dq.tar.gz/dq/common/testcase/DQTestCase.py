import commands
import string
import unittest


class DQTestCase (unittest.TestCase):
    """
    (since 0.2.0)
    """


    def __init__ (self, name):
        unittest.TestCase.__init__(self, name)


# PRIVATE methods


    def _find_error (self, expected, result):
        """
        (since 0.3.0)
        """
        error = ''
        
        if type(expected) is dict and type(result) is dict:
            iterator = None
            if len(expected.keys()) >= len(result.keys()):
                iterator = expected.keys()
            else:
                iterator = result.keys()
            
            for eachKey in iterator:
                if not result.has_key(eachKey) or not expected.has_key(eachKey):
                    """error is missing key on result"""
                    error += " missing key '%s' on the result dictionary\n" % (str(eachKey))
                elif not expected[eachKey] == result[eachKey]:
                    """error is value mismatch"""
                    if type(expected[eachKey]) is dict and type(result[eachKey]) is dict:
                        error += " error in key '%s'\n" % (eachKey)
                        error += self._find_error(expected[eachKey], result[eachKey])
                    else:
                        error += " values for don't match \n\t%s\n\t%s\n" % (
                            str(expected[eachKey]), str(result[eachKey])
                        )
        return error


    def _fmt_message (self, case, expected, result=''):
        """
        Formats the testcase failure message.
        (since 0.2.0)
        
        case is the number of the test.
        expected is the expected test result.
        result is the test result.
        
        Returns the failure message (case, expected output and actual result).
        """
        error = self._find_error(expected, result)
        
        return """
%s
  E : '%s'
  R : '%s'
  
  ERROR:\n%s
""" % (str(case), str(expected), str(result), str(error))


    def _generateUUID (self):
        """
        Generates a fixed 36 character unique identifier.
        (since 0.2.0)
        
        DQUnknownBackendException is raised,
        in case there is an error running uuidgen.
        """
        s,o = commands.getstatusoutput('uuidgen')
        if s != 0:
            raise DQUnknownBackendException('Failed running uuidgen to generate UUID')
        return string.lower(string.strip(o))
