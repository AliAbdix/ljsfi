"""
Testcase for the common.DQValidator module.

$Id: DQValidatorTestCase.py,v 1.16.2.7 2006/08/01 12:00:53 psalgado Exp $
"""

import common.DQValidator

from common.DQConstants import *
from common.DQException import DQInvalidRequestException
from common.testcase.DQTestCase import DQTestCase


class DQValidatorTestCase (DQTestCase):
    """
    Testcase for the common.DQValidator module.
    (since 0.2.1)
    """


    def __init__ (self, name):
        """
        Constructs an instance of DQValidatorTestCase.
        (since 0.2.1)
        
        name is the testcase name.
        """
        DQTestCase.__init__(self, name)
        
        self.param_dict_0 = {}
        
        self.param_int__1 = -1
        self.param_int_0 = 0
        self.param_int_1 = 1
        
        self.param_lst_0 = []
        
        self.param_invalid_site_0 = '<invalid_site>'
        
        self.param_str_0 = ''
        self.param_str_1 = '1'
        self.param_str_10 = 'A' * 10
        self.param_str_11 = 'A' * 11
        self.param_str_36 = 'A' * 36
        self.param_str_37 = 'A' * 37
        self.param_str_50 = 'A' * 50
        self.param_str_51 = 'A' * 51
        self.param_str_255 = 'A' * 255
        self.param_str_256 = 'A' * 256
        
        self.param_invalid_dsn_0 = 'dqtest/invalid/name'
        
        self.param_invalid_lfn_0 = 'dqtest/invalid/name'
        
        self.param_tpl_0 = ()
        
        self.param_uuid = self._generateUUID()
        self.param_url_00 = 'http://www.cern.ch/'
        self.param_url_01 = 'http://www.cern.ch:8/'
        self.param_url_02 = 'http://www.cern.ch:80/'
        self.param_url_03 = 'http://www.cern.ch:800/'
        self.param_url_04 = 'http://www.cern.ch:8000/'
        self.param_url_05 = 'http://www.cern.ch:/'
        self.param_url_10 = 'http://www.cern.ch'
        self.param_url_11 = 'http://www.cern.ch:8'
        self.param_url_12 = 'http://www.cern.ch:80'
        self.param_url_13 = 'http://www.cern.ch:800'
        self.param_url_14 = 'http://www.cern.ch:8000'
        self.param_url_15 = 'http://www.cern.ch:'
        
        self.param_urlsec_00 = 'https://www.cern.ch/'
        self.param_urlsec_01 = 'https://www.cern.ch:8/'
        self.param_urlsec_02 = 'https://www.cern.ch:80/'
        self.param_urlsec_03 = 'https://www.cern.ch:800/'
        self.param_urlsec_04 = 'https://www.cern.ch:8000/'
        self.param_urlsec_05 = 'https://www.cern.ch:'
        self.param_urlsec_10 = 'https://www.cern.ch'
        self.param_urlsec_11 = 'https://www.cern.ch:8'
        self.param_urlsec_12 = 'https://www.cern.ch:80'
        self.param_urlsec_13 = 'https://www.cern.ch:800'
        self.param_urlsec_14 = 'https://www.cern.ch:8000'
        self.param_urlsec_15 = 'https://www.cern.ch:/'
        
        self.param_invalid_url_0 = 'htp://www.cern.ch:/'
        self.param_invalid_url_1 = 'htps://www.cern.ch:/'
        
        self.param_with_blanks_0 = ' A'
        self.param_with_blanks_1 = 'A A'
        self.param_with_blanks_2 = 'AA '


# PUBLIC methods


    def setUp (self):
        """
        (since 0.2.1)
        """
        pass


    def tearDown (self):
        """
        (since 0.2.1)
        """
        pass
        
        
    def test_is_dataset_location (self):
        """
        Tests common.DQValidator.is_dataset_location method.
        (since 0.2.1)
        
        # 1. test entering valid parameters
        # 1.1 test entering empty string
        # 1.2 test entering a 50-character string
        # 2. test entering invalid parameters
        # 2.1 test entering a 51-character string
        # 2.2 test entering an integer
        # 2.3 test entering a list
        # 2.4 test entering a dictionary
        # 2.5 test entering a tuple
        """
        
        # 1. test entering valid parameters
        
        # 1.1 test entering empty string
        expected = None
        result = common.DQValidator.is_dataset_location(self.param_str_0)
        self.assertEqual(result, expected, self._fmt_message('1.1', expected, result))
        
        # 1.2 test entering a 50-character string
        result = common.DQValidator.is_dataset_location(self.param_str_50)
        self.assertEqual(result, expected, self._fmt_message('1.2', expected, result))
        
        
        # 2. test entering invalid parameters
        expected = 'DQInvalidRequestException'
        
        # 2.1 test entering a 51-character string
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_location,
            self.param_str_51
        )
        
        # 2.2 test entering an integer
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_location,
            self.param_int_0
        )
        
        # 2.3 test entering a list
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_location,
            self.param_lst_0
        )
        
        # 2.4 test entering a dictionary
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_location,
            self.param_dict_0
        )
        
        # 2.5 test entering a tuple
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_location,
            self.param_tpl_0
        )


    def test_is_dataset_location_state (self):
        """
        Tests common.DQValidator.is_dataset_location_state method.
        (since 0.2.1)
        
        # 1. test entering valid parameters
        # 1.1 test all valid common.DQConstants.LocationState.STATES
        # 2. test entering invalid parameters
        # 2.1 test entering an invalid state
        # 2.2 test entering a string
        # 2.3 test entering a list
        # 2.4 test entering a dictionary
        # 2.5 test entering a tuple
        """
        
        # 1. test entering valid parameters
        
        # 1.1 test all valid common.DQConstants.LocationState.STATES
        expected = None
        
        for eachState in LocationState.STATES:
            result = common.DQValidator.is_dataset_location_state(eachState)
            self.assertEqual(result, expected, self._fmt_message('1.1', expected, result))
        
        
        # 2. test entering invalid parameters
        
        # 2.1 test entering an invalid state
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_location_state,
            self.param_int__1
        )
        
        # 2.2 test entering a string
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_location_state,
            self.param_str_0
        )
        
        # 2.3 test entering a list
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_location_state,
            self.param_lst_0
        )
        
        # 2.4 test entering a dictionary
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_location_state,
            self.param_dict_0
        )
        
        # 2.5 test entering a tuple
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_location_state,
            self.param_tpl_0
        )


    def test_is_dataset_name (self):
        """
        Tests common.DQValidator.is_dataset_name method.
        (since 0.2.1)
        
        # 1. test entering valid parameters
        # 1.1 test entering a 255-character string
        # 2. test entering invalid parameters
        # 2.1 test entering a 256-character string
        # 2.2 test entering an integer
        # 2.3 test entering a list
        # 2.4 test entering a dictionary
        # 2.5 test entering a tuple
        # 2.6 test entering a string with blank spaces
        # 2.7 test entering empty string
        """
        
        # 1. test entering valid parameters
        expected = None
        
        # 1.1 test entering a 50-character string
        result = common.DQValidator.is_dataset_name(self.param_str_255)
        self.assertEqual(result, expected, self._fmt_message('1.1', expected, result))
        
        
        # 2. test entering invalid parameters
        expected = 'DQInvalidRequestException'
        
        # 2.1 test entering a 256-character string
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_name,
            self.param_str_256
        )
        
        # 2.2 test entering an integer
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_name,
            self.param_int_0
        )
        
        # 2.3 test entering a list
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_name,
            self.param_lst_0
        )
        
        # 2.4 test entering a dictionary
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_name,
            self.param_dict_0
        )
        
        # 2.5 test entering a tuple
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_name,
            self.param_tpl_0
        )
        
        # 2.6 test entering a string with blank spaces
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_name,
            self.param_with_blanks_0
        )
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_name,
            self.param_with_blanks_1
        )
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_name,
            self.param_with_blanks_2
        )
        
        # 2.7 test entering empty string
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_name,
            self.param_str_0
        )
        
        # 2.8 test entering an invalid dataset name
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_name,
            self.param_invalid_dsn_0
        )


    def test_is_dataset_state (self):
        """
        Tests common.DQValidator.is_dataset_state method.
        (since 0.2.1)
        
        # 1. test entering valid parameters
        # 1.1 test all valid common.DQConstants.DatasetState.STATES
        # 2. test entering invalid parameters
        # 2.1 test entering an invalid state
        # 2.2 test entering a string
        # 2.3 test entering a list
        # 2.4 test entering a dictionary
        # 2.5 test entering a tuple
        """
        
        # 1. test entering valid parameters
        
        # 1.1 test all valid common.DQConstants.DatasetState.STATES
        expected = None
        
        for eachState in DatasetState.STATES:
            result = common.DQValidator.is_dataset_state(eachState)
            self.assertEqual(result, expected, self._fmt_message('1.1', expected, result))
        
        
        # 2. test entering invalid parameters
        
        # 2.1 test entering an invalid state
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_state,
            self.param_int__1
        )
        
        # 2.2 test entering a string
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_state,
            self.param_str_0
        )
        
        # 2.3 test entering a list
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_state,
            self.param_lst_0
        )
        
        # 2.4 test entering a dictionary
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_state,
            self.param_dict_0
        )
        
        # 2.5 test entering a tuple
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_dataset_state,
            self.param_tpl_0
        )


    def test_is_destination (self):
        """
        Tests common.DQValidator.is_destination method.
        (since 0.2.9)
        
        # 1. test entering valid parameters
        # 1.1 test entering a valid site
        # 2. test entering invalid parameters
        # 2.1 test entering a 51-character string
        # 2.2 test entering an integer
        # 2.3 test entering a list
        # 2.4 test entering a dictionary
        # 2.5 test entering a tuple
        # 2.6 test entering a string with blank spaces
        # 2.7 test entering an invalid site string
        # 2.8 test entering empty string
        """
        
        # 1. test entering valid parameters
        
        # 1.1 test entering a valid site
        expected = None
        for eachSite in TestCaseData.DESTINATIONS:
            result = common.DQValidator.is_destination(eachSite)
            self.assertEqual(result, expected, self._fmt_message('1.1', expected, result))
        
        
        # 2. test entering invalid parameters
        expected = 'DQInvalidRequestException'
        
        # 2.1 test entering a 256-character string
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_destination,
            self.param_str_51
        )
        
        # 2.2 test entering an integer
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_destination,
            self.param_int_0
        )
        
        # 2.3 test entering a list
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_destination,
            self.param_lst_0
        )
        
        # 2.4 test entering a dictionary
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_destination,
            self.param_dict_0
        )
        
        # 2.5 test entering a tuple
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_destination,
            self.param_tpl_0
        )
        
        # 2.6 test entering a string with blank spaces
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_destination,
            self.param_with_blanks_0
        )
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_destination,
            self.param_with_blanks_1
        )
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_destination,
            self.param_with_blanks_2
        )
        
        # 2.7 test entering an invalid site string
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_destination,
            self.param_invalid_site_0
        )
        
        # 2.8 test entering empty string
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_destination,
            self.param_str_0
        )


    def test_is_http_url (self):
        """
        Tests common.DQValidator.is_http_url method.
        (since 0.2.1)
        
        # 1. test entering valid parameters
        # 1.1 test entering a real URLs
        # 2. test entering invalid parameters
        # 2.1 test entering an integer
        # 2.2 test entering a list
        # 2.3 test entering a dictionary
        # 2.4 test entering a tuple
        # 2.5 test entering empty string
        # 2.6 test entering invalid URLs
        """
        
        # 1. test entering valid parameters
        
        # 1.1 test entering a real UID
        for eachURL in [
            self.param_url_00,
            self.param_url_01,
            self.param_url_02,
            self.param_url_03,
            self.param_url_04,
            self.param_url_05,
            self.param_url_10,
            self.param_url_11,
            self.param_url_12,
            self.param_url_13,
            self.param_url_14,
            self.param_url_15,
            
            self.param_urlsec_00,
            self.param_urlsec_01,
            self.param_urlsec_02,
            self.param_urlsec_03,
            self.param_urlsec_04,
            self.param_urlsec_05,
            self.param_urlsec_10,
            self.param_urlsec_11,
            self.param_urlsec_12,
            self.param_urlsec_13,
            self.param_urlsec_14,
            self.param_urlsec_15
        ]:
            expected = None
            result = common.DQValidator.is_http_url(eachURL)
            self.assertEqual(result, expected, self._fmt_message('1.1', expected, result))
        
        
        # 2. test entering invalid parameters
        expected = 'DQInvalidRequestException'
        
        # 2.1 test entering an integer
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_http_url,
            self.param_int_0
        )
        
        # 2.2 test entering a list
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_http_url,
            self.param_lst_0
        )
        
        # 2.3 test entering a dictionary
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_http_url,
            self.param_dict_0
        )
        
        # 2.4 test entering a tuple
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_http_url,
            self.param_tpl_0
        )
        
        # 2.5 test entering empty string
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_http_url,
            self.param_str_0
        )
        
        # 2.6 test entering invalid URLs
        for eachURL in [
            self.param_invalid_url_0,
            self.param_invalid_url_1
        ]:
            self.assertRaises(
                DQInvalidRequestException,
                common.DQValidator.is_http_url,
                eachURL
            )


    def test_is_metadata_value (self):
        """
        Tests common.DQValidator.is_metadata_value method.
        (since 0.2.1)
        
        # 1. test entering valid parameters
        # 1.1 test entering empty string
        # 1.2 test entering a 10-character string
        # 2. test entering invalid parameters
        # 2.1 test entering a 11-character string
        # 2.2 test entering an integer
        # 2.3 test entering a list
        # 2.4 test entering a dictionary
        # 2.5 test entering a tuple
        """
        
        # 1. test entering valid parameters
        
        # 1.1 test entering empty string
        expected = None
        result = common.DQValidator.is_metadata_value(self.param_str_0)
        self.assertEqual(result, expected, self._fmt_message('1.1', expected, result))
        
        # 1.2 test entering a 10-character string
        result = common.DQValidator.is_metadata_value(self.param_str_10)
        self.assertEqual(result, expected, self._fmt_message('1.2', expected, result))
        
        
        # 2. test entering invalid parameters
        expected = 'DQInvalidRequestException'
        
        # 2.1 test entering a 11-character string
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_metadata_value,
            self.param_str_11
        )
        
        # 2.2 test entering an integer
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_metadata_value,
            self.param_int_0
        )
        
        # 2.3 test entering a list
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_metadata_value,
            self.param_lst_0
        )
        
        # 2.4 test entering a dictionary
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_metadata_value,
            self.param_dict_0
        )
        
        # 2.5 test entering a tuple
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_metadata_value,
            self.param_tpl_0
        )


    def test_is_site (self):
        """
        Tests common.DQValidator.is_site method.
        (since 0.2.9)
        
        # 1. test entering valid parameters
        # 1.1 test entering a valid site
        # 2. test entering invalid parameters
        # 2.1 test entering a 51-character string
        # 2.2 test entering an integer
        # 2.3 test entering a list
        # 2.4 test entering a dictionary
        # 2.5 test entering a tuple
        # 2.6 test entering a string with blank spaces
        # 2.7 test entering an invalid site string
        # 2.8 test entering empty string
        """
        
        # 1. test entering valid parameters
        
        # 1.1 test entering a valid site
        expected = None
        for eachSite in TestCaseData.SOURCES:
            result = common.DQValidator.is_site(eachSite)
            self.assertEqual(result, expected, self._fmt_message('1.1', expected, result))
        
        for eachSite in TestCaseData.DESTINATIONS:
            result = common.DQValidator.is_site(eachSite)
            self.assertEqual(result, expected, self._fmt_message('1.1', expected, result))
        
        
        # 2. test entering invalid parameters
        expected = 'DQInvalidRequestException'
        
        # 2.1 test entering a 256-character string
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_site,
            self.param_str_51
        )
        
        # 2.2 test entering an integer
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_site,
            self.param_int_0
        )
        
        # 2.3 test entering a list
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_site,
            self.param_lst_0
        )
        
        # 2.4 test entering a dictionary
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_site,
            self.param_dict_0
        )
        
        # 2.5 test entering a tuple
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_site,
            self.param_tpl_0
        )
        
        # 2.6 test entering a string with blank spaces
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_site,
            self.param_with_blanks_0
        )
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_site,
            self.param_with_blanks_1
        )
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_site,
            self.param_with_blanks_2
        )
        
        # 2.7 test entering an invalid site string
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_site,
            self.param_invalid_site_0
        )
        
        # 2.8 test entering empty string
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_site,
            self.param_str_0
        )


    def test_is_source (self):
        """
        Tests common.DQValidator.is_source method.
        (since 0.2.9)
        
        # 1. test entering valid parameters
        # 1.1 test entering a valid site
        # 2. test entering invalid parameters
        # 2.1 test entering a 51-character string
        # 2.2 test entering an integer
        # 2.3 test entering a list
        # 2.4 test entering a dictionary
        # 2.5 test entering a tuple
        # 2.6 test entering a string with blank spaces
        # 2.7 test entering an invalid site string
        # 2.8 test entering empty string
        """
        
        # 1. test entering valid parameters
        
        # 1.1 test entering a valid site
        expected = None
        for eachSite in TestCaseData.SOURCES:
            result = common.DQValidator.is_source(eachSite)
            self.assertEqual(result, expected, self._fmt_message('1.1', expected, result))
        
        
        # 2. test entering invalid parameters
        expected = 'DQInvalidRequestException'
        
        # 2.1 test entering a 256-character string
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_source,
            self.param_str_51
        )
        
        # 2.2 test entering an integer
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_source,
            self.param_int_0
        )
        
        # 2.3 test entering a list
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_source,
            self.param_lst_0
        )
        
        # 2.4 test entering a dictionary
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_source,
            self.param_dict_0
        )
        
        # 2.5 test entering a tuple
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_source,
            self.param_tpl_0
        )
        
        # 2.6 test entering a string with blank spaces
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_source,
            self.param_with_blanks_0
        )
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_source,
            self.param_with_blanks_1
        )
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_source,
            self.param_with_blanks_2
        )
        
        # 2.7 test entering an invalid site string
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_source,
            self.param_invalid_site_0
        )
        
        # 2.8 test entering empty string
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_source,
            self.param_str_0
        )


    def test_is_subscription_sources_policy (self):
        """
        Tests common.DQValidator.is_subscription_sources_policy  method.
        (since 0.2.1)
        
        # 1. test entering valid parameters
        # 1.1 test all valid common.DQConstants.SourcesPolicy.VALUES
        # 2. test entering invalid parameters
        # 2.1 test entering an invalid state
        # 2.2 test entering a string
        # 2.3 test entering a list
        # 2.4 test entering a dictionary
        # 2.5 test entering a tuple
        """
        
        # 1. test entering valid parameters
        
        # 1.1 test all valid common.DQConstants.SourcesPolicy.VALUES
        expected = None
        
        for eachValue in SourcesPolicy.VALUES:
            result = common.DQValidator.is_subscription_sources_policy(eachValue)
            self.assertEqual(result, expected, self._fmt_message('1.1', expected, result))
        
        
        # 2. test entering invalid parameters
        
        # 2.1 test entering an invalid state
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_subscription_sources_policy,
            self.param_int__1
        )
        
        # 2.2 test entering a string
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_subscription_sources_policy,
            self.param_str_0
        )
        
        # 2.3 test entering a list
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_subscription_sources_policy,
            self.param_lst_0
        )
        
        # 2.4 test entering a dictionary
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_subscription_sources_policy,
            self.param_dict_0
        )
        
        # 2.5 test entering a tuple
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_subscription_sources_policy,
            self.param_tpl_0
        )


    def test_is_subscription_state (self):
        """
        Tests common.DQValidator.is_subscription_state  method.
        (since 0.2.1)
        
        # 1. test entering valid parameters
        # 1.1 test all valid common.DQConstants.SubscriptionArchivedState.STATES
        # 2. test entering invalid parameters
        # 2.1 test entering an invalid state
        # 2.2 test entering a string
        # 2.3 test entering a list
        # 2.4 test entering a dictionary
        # 2.5 test entering a tuple
        """
        
        # 1. test entering valid parameters
        
        # 1.1 test all valid common.DQConstants.SourcesPolicy.VALUES
        expected = None
        
        for eachState in SubscriptionArchivedState.STATES:
            result = common.DQValidator.is_subscription_state(eachState)
            self.assertEqual(result, expected, self._fmt_message('1.1', expected, result))
        
        
        # 2. test entering invalid parameters
        
        # 2.1 test entering an invalid state
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_subscription_state,
            self.param_int__1
        )
        
        # 2.2 test entering a string
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_subscription_state,
            self.param_str_0
        )
        
        # 2.3 test entering a list
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_subscription_state,
            self.param_lst_0
        )
        
        # 2.4 test entering a dictionary
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_subscription_state,
            self.param_dict_0
        )
        
        # 2.5 test entering a tuple
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_subscription_state,
            self.param_tpl_0
        )


    def test_is_uid (self):
        """
        Tests common.DQValidator.is_uid method.
        (since 0.2.1)
        
        # 1. test entering valid parameters
        # 1.1 test entering a real UID
        # 2. test entering invalid parameters
        # 2.1 test entering a 37-character string
        # 2.2 test entering an integer
        # 2.3 test entering a list
        # 2.4 test entering a dictionary
        # 2.5 test entering a tuple
        # 2.6 test entering a string with blank spaces
        # 2.7 test entering an invalid UID 36-character string
        # 2.8 test entering empty string
        """
        
        # 1. test entering valid parameters
        
        # 1.1 test entering a real UID
        expected = None
        result = common.DQValidator.is_uid(self.param_uuid)
        self.assertEqual(result, expected, self._fmt_message('1.1', expected, result))
        
        
        # 2. test entering invalid parameters
        expected = 'DQInvalidRequestException'
        
        # 2.1 test entering a 256-character string
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_uid,
            self.param_str_37
        )
        
        # 2.2 test entering an integer
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_uid,
            self.param_int_0
        )
        
        # 2.3 test entering a list
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_uid,
            self.param_lst_0
        )
        
        # 2.4 test entering a dictionary
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_uid,
            self.param_dict_0
        )
        
        # 2.5 test entering a tuple
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_uid,
            self.param_tpl_0
        )
        
        # 2.6 test entering a string with blank spaces
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_uid,
            self.param_with_blanks_0
        )
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_uid,
            self.param_with_blanks_1
        )
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_uid,
            self.param_with_blanks_2
        )
        
        # 2.7 test entering an invalid UID 36-character string
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_uid,
            self.param_str_36
        )
        
        # 2.8 test entering empty string
        self.assertRaises(
            DQInvalidRequestException,
            common.DQValidator.is_uid,
            self.param_str_0
        )


if __name__ == '__main__':
    """
    Runs all tests in DQValidatorTestCase.
    (since 0.2.1)
    """
    import unittest
    suite = unittest.makeSuite(DQValidatorTestCase)
    unittest.TextTestRunner(verbosity=2).run(suite)
