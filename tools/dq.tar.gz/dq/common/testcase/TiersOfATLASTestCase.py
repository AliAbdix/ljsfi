import unittest
import inspect
import os


class TiersOfATLASTestCase(unittest.TestCase):


    def __init__ (self, name):
        unittest.TestCase.__init__(self, name)


    def setUp(self):
        pass


    def tearDown(self):
        pass
        
        
    def testDownloadToA(self):
        from common.TiersOfATLAS import getAllDestinationSites
        
        import os
        try:
            os.remove('TiersOfATLASCache.py')
        except:
            pass
        getAllDestinationSites()
        
    
    def testDownloadInvalidToA(self):
        """
        Override default URL to point to bad place
        (then put it back right or rest of tests will fail :-)
        """
        import common.TiersOfATLAS
        from common.DQException import DQTiersOfATLASException
        
        import common
        dir = os.path.abspath(common.__path__[0])
        script = '%s/TiersOfATLASCache.py' % dir
        
        try:
            os.remove(script)
            os.remove('%sc' % script)
        except:
            pass
        
        good = common.TiersOfATLAS.TIERS_OF_ATLAS_URL
        common.TiersOfATLAS.TIERS_OF_ATLAS_URL = 'http://something.bad'
        try:
            print 'invalid',common.TiersOfATLAS.getAllDestinationSites()
        except DQTiersOfATLASException, e:
            common.TiersOfATLAS.TIERS_OF_ATLAS_URL = good
            return
        assert(False)
        
        
    def testGetAllDestinationSites(self):
        from common.TiersOfATLAS import getAllDestinationSites
        
        s = getAllDestinationSites()
        print s
        assert(s.count('CERNCAF') == 1)
        assert(s.count('TIER1S') == 0)
    
    
    def testGetAllSources(self):
        from common.TiersOfATLAS import getAllSources
        
        s = getAllSources()
        print s
        assert(s.count('CERNCAF') == 1)
        assert(s.count('TIER1S') == 1)


    def testGetLocalCatalog(self):
        from common.TiersOfATLAS import getLocalCatalog
        
        lrc = getLocalCatalog('CERNCAF')
        assert(len(lrc) > 0)
        
        lrc = getLocalCatalog('TIER1S')
        assert(lrc is None)
        
        lrc = getLocalCatalog('GARBAGE')
        assert(lrc is None)
        
        
        
    def testGetRemoteCatalogs(self):
        from common.TiersOfATLAS import getRemoteCatalogs
        
        lrcs = getRemoteCatalogs('CERNCAF')
        assert(len(lrcs) == 1)
        assert(len(lrcs[0]) > 0)
        
        lrcs = getRemoteCatalogs('TIER1S')
        print 'TIER1S remote catalogs:',lrcs
        assert(len(lrcs) > 0)
        
        lrcs = getRemoteCatalogs('GARBAGE')
        assert(len(lrcs) == 0)
        

    def testGetCloseSites(self):
        from common.TiersOfATLAS import getCloseSites
        
        sites = getCloseSites('CERNCAF')
        print sites
        assert(sites.count('PICDISK') == 1)
        
        sites = getCloseSites('GARBAGE')
        assert(sites == [])


    def testGetSiteProperty(self):
        from common.TiersOfATLAS import getSiteProperty
        
        p = getSiteProperty('CERNCAF', 'srm')
        print p
        assert(p is not None)
        
        p = getSiteProperty('CERNCAF', 'nothing')
        assert(p is None)
        
        p = getSiteProperty('GARBAGE', 'srm')
        assert(p is None)
        
        
    def testIsSURLFromSiteOrCloud(self):
        from common.TiersOfATLAS import isSURLFromSiteOrCloud
        
        file = 'srm://srm-durable-atlas.cern.ch/castor/cern.ch/grid/atlas/test/file1'
        assert(isSURLFromSiteOrCloud(file, 'CERNCAF') == True)
        assert(isSURLFromSiteOrCloud(file, 'PICDISK') == False)

        file = 'srm://castorsrm.pic.es/castor/pic.es/grid/atlas/test/file1'
        assert(isSURLFromSiteOrCloud(file, 'PICDISK') == True)
        assert(isSURLFromSiteOrCloud(file, 'TIER1S') == True)
        assert(isSURLFromSiteOrCloud(file, 'CERNCAF') == False)
        
        
    def testGetFTS(self):
        from common.TiersOfATLAS import getFTS
        
        src_surl = 'srm://srm.cern.ch/castor/cern.ch/grid/atlas/test/file1'
        dest_surl = 'srm://castorsrm.pic.es/castor/pic.es/grid/atlas/test/file1'
        
        r = getFTS(src_surl, dest_surl)
        print r
        assert(r is not None)

        src_surl = 'srm://foo'
        dest_surl = 'srm://dest'
        
        r = getFTS(src_surl, dest_surl)
        print r
        assert(r is None)
        
        src_surl = 'srm://foo'
        dest_surl = 'srm://castorsrm.pic.es/castor/pic.es/grid/atlas/test/file1'
        
        r = getFTS(src_surl, dest_surl)
        print r
        assert(r is None)


if __name__ == '__main__':
    suite = unittest.makeSuite(TiersOfATLASTestCase)
    unittest.TextTestRunner(verbosity=2).run(suite)
