"""
"8.2 State Guidelines
(...)
168. State Names Should Be Simple but Descriptive
(...)
Ideally, state names should also be written in present tense,
although names such as Proposed (past tense) are better than
Is Proposed (present tense).
", The Elements of UML Style - Scott W. Ambler
"""

import common.TiersOfATLAS


class CallbackType:
    """
    (since 0.2.11)
    """
    FETCHER_VUID_COMPLETE   = 'FETCHER_VUID_COMPLETE'
    FILE_DONE               = 'FILE_DONE'
    MONITOR_SUBSCRIPTION    = 'MONITOR_SUBSCRIPTION'
    ERROR                   = 'ERROR'


class DatasetState:
    """
    (since 0.2.0)
    """
    CLOSED = 1
    FROZEN = 2
    OPEN = 0
    
    STATES = [OPEN, CLOSED, FROZEN]
    DESCRIPTION = ["open", "closed", "frozen"]


class HTTP:
    """
    (since 0.2.0)
    """
    GET = 'GET'
    POST = 'POST'
    DELETE = 'DELETE'
    PUT = 'PUT'


class LocationState:
    """
    (since 0.2.0)
    """
    __ANY__ = None
    INCOMPLETE = 0
    COMPLETE = 1

    STATES = [INCOMPLETE, COMPLETE]


class Metadata:
    """
    (since 0.2.0)
    """
    DATASET = ['duid', 'numberfiles', 'state', 'owner', 'creationdate', 'latestvuid', 'latestversion']
    DATASET_VERSION = ['vuid', 'version', 'versioncreationdate', 'versionnumberfiles']
    TIER0 = ['tier0state', 'tier0nrpartitions', 'tier0type']


class SourcesPolicy:
    """
    (since 0.2.0)
    """
    ALL_SOURCES        = 000001
    KNOWN_SOURCES      = 000010
    CLOSE_SOURCES      = 000100
    COMPLETE_SOURCES   = 001000
    INCOMPLETE_SOURCES = 010000
    
    VALUES = [ALL_SOURCES, KNOWN_SOURCES, CLOSE_SOURCES, COMPLETE_SOURCES, INCOMPLETE_SOURCES]


class SourceResolverPolicy:
    """
    (since 0.2.2)
    """
    LRC_LOOKUP = 0
    RELATIVE_SURL = 1


class SubscriptionState:
    """
    (since 0.2.0)
    
    DEPRECATED: please start using SubscriptionArchivedState
    """
    __ANY__ = -1
    ARCHIVE = 1
    UNARCHIVE = 0
    
    STATES = [UNARCHIVE, ARCHIVE]


class SubscriptionArchivedState:
    """
    (since 0.2.0)
    """
    __ANY__ = -1
    ARCHIVE = 1
    UNARCHIVE = 0
    
    STATES = [UNARCHIVE, ARCHIVE]


class SubscriptionModifiedState:
    """
    (since 0.3.0)
    """
    __ANY__ = None
    MODIFIED = 1
    UNMODIFIED = 0
    
    STATES = [UNMODIFIED, MODIFIED]


class TestCaseData:
    """
    (since 0.2.0)
    """
    DSNS = ['dq2_testCASE_dsn_' + 'a' * (255-17), 'mcatnlo0310.005921.W+W-enuenu', 'csc11.005025.J2_pythia_jetjet_NoISR-FSR-MI.evgen.EVNT.v11004205', 'csc11.005025.J2_pythia_jetjet_NoISR_FSR_MI.evgen.EVNT.v11004205']
    LFNS = ['mcatnlo0310.005921.W+W-enuenu._00001.tar.gz', 'mcatnlo0310.005921.W+W-enuenu._00002.tar.gz']
    GUIDS = ['c9efb1cb-61da-4a38-9ede-fda81fda4c12', '0d6dde49-6d2c-44ac-b2ff-a97409ed543b']
    SOURCES = common.TiersOfATLAS.getAllSources()
    DESTINATIONS = common.TiersOfATLAS.getAllDestinationSites()
    VUIDS = ['7a79d416-cc68-4bb3-b52c-b94414f60e0b', '1359f738-3dc3-473d-b516-dea45259f57d', '1359f738-3dc3-473d-b516-dea45259f5aa', '1359f738-3dc3-473d-b516-dea45259f5bb']
