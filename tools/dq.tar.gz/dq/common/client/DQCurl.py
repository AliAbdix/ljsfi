import sys
import urllib
try:
    import pycurl
except:
    print "Error importing pycurl"
    sys.exit(1)


import common.DQException
import re
import os

from common.DQException import *
from StringIO import StringIO

tag = "$Name: DQ2_0_2_BRANCH $"

# assumes tag is of the form DQ2_x_y_z
USER_AGENT = 'User-Agent: dqcurl %s' % (tag[11:-2].replace('_', '.'))


class DQCurl:

    REG_CURL_ERROR = re.compile('^curl: \([0-9]+\) (.)*$')


    def __init__(self, url, urlsec, proxy_cert, ca_path):
        """
        Constructs an instance of DQCurl.
        
        url is the non-secure URL of the host to be contacted.
        urlsec is the secure URL of the host to be contacted.
        proxy_cert is the proxy certificate
        ca_path is the directory where the Certification Authority certificates are located (by default it is /etc/grid-security/certificates but can be overriden by the X509_CERT_DIR environment variable.
        """
        
        self.url = url + '/dq2'
        self.urlsec = urlsec + '/dq2'
        
        c = pycurl.Curl()
        c.setopt(pycurl.FOLLOWLOCATION, 1)
        c.setopt(pycurl.MAXREDIRS, 5)
        
        if os.environ.has_key('DQCURL_VERBOSE') and \
           os.environ['DQCURL_VERBOSE'] != '0':
            c.setopt(pycurl.VERBOSE, 1)
        
        self.c = c
        
        if proxy_cert is not None:
            if proxy_cert == -1:
                print "Invalid certificate. Giving up."
                sys.exit(2)
            csec = pycurl.Curl()
            csec.setopt(pycurl.SSL_VERIFYHOST, 0)
            csec.setopt(pycurl.FOLLOWLOCATION, 1)
            csec.setopt(pycurl.MAXREDIRS, 5)
            csec.setopt(pycurl.CAPATH, ca_path)
            csec.setopt(pycurl.SSLCERT, proxy_cert)
            csec.setopt(pycurl.SSLKEY, proxy_cert)
            csec.setopt(pycurl.SSLVERSION, 3)
            
            if self.get_pycurl_version() < '7.10.6':
                """
                for pycurl.version < 7.10.6 (at least) need to set SSL_VERIFYPEER to 0
                possible insecure option : exposure to "man-in-the-middle" attack
                http://mail.python.org/pipermail/python-list/2003-February/147296.html
                """
                csec.setopt(pycurl.SSL_VERIFYPEER, 0)
            
            if os.environ.has_key('DQCURL_VERBOSE') and \
                   os.environ['DQCURL_VERBOSE'] != '0':
                csec.setopt(pycurl.VERBOSE, 1)
            
            self.csec = csec


    def __del__(self):
        if 'csec' in vars(self):
            self.csec.close()
        self.c.close()


# PRIVATE methods


    def _process(self, c):
        """
        Process the response of the web service.
        
        c is the pycurl instance (pycurl.Curl).
        """

        try:
            c.perform()
        except pycurl.error, e:
            """http://curl.haxx.se/libcurl/c/libcurl-errors.html"""
            errno, text = e

            if errno == 6:
                err_msg = 'Unknown DDM server! Please check your configuration file.\n[(%s) %s]' % (errno, text)
                raise DQInternalServerException(err_msg, self.url, self.urlsec)
            if errno == 7:
                err_msg = 'The central catalog is not responding! The service is down or bad configuration (host port number)!\n [(%s) %s]' % (errno, text)
                raise DQInternalServerException(err_msg, self.url, self.urlsec)
            elif errno == 23:
                err_msg = 'The central catalog database is down!\n [(%s) %s]' % (errno, text)
                raise DQInternalServerException(err_msg, self.url, self.urlsec)
            elif errno == 35:
                err_msg = 'Proxy certificate expired!\n[(%s) %s]' % (errno, text)
                raise DQInternalServerException(e)
            elif errno == 52:
                """empty reply from the server : OK """
                return ''
            else:
                raise DQInternalServerException(e, self.url, self.urlsec)


        st = c.getinfo(pycurl.HTTP_CODE)
        
        if st >= 400:
            response = urllib.unquote_plus(c.body.getvalue())
            
            try:
                e = eval(response)
            except Exception, e:
                err_msg = 'Error treating DDM server exception response [%s].' % (response)
                raise DQInternalServerException(err_msg, self.url, self.urlsec)
            
            # verify if the exception requires an import
            if e.has_key('m') and e['m'] is not None and len(e['m']) > 0:
                exec('import %s' % (e['m']))
                clazz = e['m'] + "." + e['c']
            else:    
                clazz = 'common.DQException.' + e['c']
            
            if type(e['a']) is not tuple and type(e['a']) is not list:
                e['a'] = "'"+str(e['a'])+"'"
            
            cmd = 'raise %s, %s' % (clazz, e['a'])
            exec(cmd)
        elif st == 204:
            return ''
        else:
            response = c.body.getvalue()
            
            ret = urllib.unquote_plus(response)
            
            if ret == '\0': return ''
            
            if re.findall(DQCurl.REG_CURL_ERROR, ret):
                raise DQInternalServerException(ret, self.url, self.urlsec)
            
            # ugly but only way is to grep for error string
            if ret.find('Mod_python error') != -1:
                raise DQInternalServerException(ret, self.url, self.urlsec)
            
            # convert non strings to list, dict etc
            try: ret = eval(ret)
            except: pass
            
            return ret


# PUBLIC methods


    def get_pycurl_version (self):
        """
        """
        separator = pycurl.version.find(' ')
        installed_version = pycurl.version[8:separator]
        return installed_version


    def get(self, request, secure=False):
        """Does HTTP GET"""
        if secure: c = self.csec
        else: c = self.c
        c.body = StringIO()
        if secure: c.setopt(pycurl.URL, str('%s%s' % (self.urlsec, request)))
        else: c.setopt(pycurl.URL, str('%s%s' % (self.url, request)))
        c.setopt(pycurl.WRITEFUNCTION, c.body.write)
        c.setopt(pycurl.HTTPHEADER, [USER_AGENT])
        return self._process(c)


    def post(self, request, pf, secure=True):
        """Does HTTP POST. Expects list with fields (format per field is 'field1=value1'"""
        assert pf != []

        if secure: c = self.csec
        else: c = self.c
        c.body = StringIO()
        if secure: c.setopt(pycurl.URL, str('%s%s' % (self.urlsec, request)))
        else: c.setopt(pycurl.URL, str('%s%s' % (self.url, request)))
        c.setopt(pycurl.WRITEFUNCTION, c.body.write)
        c.setopt(pycurl.HTTPPOST, pf)
        c.setopt(pycurl.HTTPHEADER, [USER_AGENT])
        return self._process(c)


    def delete(self, request):
        """
        Does as a HTTP GET with 'delete=yes' field.
        """
        
        self.csec.body = StringIO()
        if request.find('?') != -1: request += '&delete=yes'
        else: request += '?delete=yes'
        
        self.csec.setopt(pycurl.URL, str('%s%s' % (self.urlsec, request)))
        self.csec.setopt(pycurl.WRITEFUNCTION, self.csec.body.write)
        self.csec.setopt(pycurl.HTTPHEADER, [USER_AGENT])      
        return self._process(self.csec)


    def put(self, request, pf):
        """
        Does HTTP POST with 'update=yes' field.
        """
        
        assert pf != []
        
        self.csec.body = StringIO()
        if request.find('?') != -1: request += '&update=yes'
        else: request += '?update=yes'
        self.csec.setopt(pycurl.URL, str('%s%s' % (self.urlsec, request)))
        self.csec.setopt(pycurl.WRITEFUNCTION, self.csec.body.write)
        self.csec.setopt(pycurl.HTTPPOST, pf)
        self.csec.setopt(pycurl.HTTPHEADER, [USER_AGENT])
        return self._process(self.csec)
