import os
import sys
import commands

from common.DQException import DQSecurityException


def getCAPath():
    """
    Returns the Certificate Authority certificates location.
    
    The location is, by default, /etc/grid-security/certificates but can overriden
    by setting up the X509_CERT_DIR environment variable.
    """
    # first see if X509_CERT_DIR is set
    try:
        cert_dir = os.environ['X509_CERT_DIR']
    except KeyError:
        # if not look in the default place
        try:
            cert_dir = '/etc/grid-security/certificates'
            f = open(cert_dir, 'r')
            f.close()
        except IOError:
            err_msg = """
            Error: The Certificate Authority certificates location could not be found.
            Please set the X509_CERT_DIR environment variable to the location of the
            certificates.
            """
            raise DQSecurityException, err_msg
    
    return cert_dir
        

    
    

def getX509():
    """
    Look for a grid proxy certificate, either in the X509_USER_PROXY
    envionment variable or in the standard place in /tmp.
    """

    # first see if X509_USER_PROXY is set
    if 'X509_USER_PROXY' in os.environ:
        x509 = os.environ['X509_USER_PROXY']
        # check the file is there
        try:
            f = open(x509, 'r')
            f.close()
        except IOError:
            err_msg = """
    Error with file X509_USER_PROXY env variable points to
    (%s)
    doesn't exist or permission denied.
    """ % x509
            raise DQSecurityException, err_msg
            
    # if not look in the default place
    else:
        try:
            x509 = '/tmp/x509up_u%s' % os.getuid()
            f = open(x509, 'r')
            f.close()
        except IOError:
            err_msg = """
    Error: No valid grid proxy certificate found. Either run grid-proxy-init
    or set the X509_USER_PROXY environment variable to the location of the
    proxy if it is in a non-standard place (ie not /tmp/x509up_u%s)
            """ % os.getuid()
            raise DQSecurityException, err_msg

    # check to see if it's still valid
    s, o = commands.getstatusoutput('grid-proxy-info -timeleft')
    if s != 0:
        """handling error status code"""
        err_msg = """
    Error: Problem running grid-proxy-info. Make sure GLOBUS environment
    is properly set
        """
        raise DQSecurityException, err_msg
    
    elif o.strip() == '-1':
        """handling bad output"""
        err_msg = 'Error: Proxy certificate expired'
        raise DQSecurityException, err_msg
    
    else:
        """status code and output are ok"""
	
        return x509
    
    raise DQSecurityException, 'Error: Could not retrieve a proxy certificate'
