"""Runs lots of client requests to DQ2 catalogs
and measures the time to execute them. Inserts entries
using the given no of concurrent threads, then every QUERY_FREQ
inserts launches NO_QUERIES queries and reports the average times"""

import threading
import sys
import time
import commands
import random
import DQ2
import client_conf
from common.DQException import DQException, DQUnknownDatasetException, DQBackendException

QUERY_FREQ = 1000 # test queries after this many inserts
NO_QUERIES = 20 # no of queries to test each time

class TestThread(threading.Thread):

    id = 0
    
    def __init__(self, client_conf, queries, filesperds):
        """
        Constructs a TestThread instance. 
        (since 0.2.1)

        client_conf ...
        queries ...
        filesperds ...

        DQBackendException is raised,
        in case the DDM Server is down.
        """
        
        threading.Thread.__init__(self)
        self.myid = TestThread.id
        TestThread.id += 1
        self.dq2 = DQ2.DQ2(con_url=client_conf.content['insecure'],
                           con_urlsec=client_conf.content['secure'],
                           loc_url=client_conf.location['insecure'],
                           loc_urlsec=client_conf.location['secure'],
                           rep_url=client_conf.repository['insecure'],
                           rep_urlsec=client_conf.repository['secure'],
                           sub_url=client_conf.subscription['insecure'],
                           sub_urlsec=client_conf.subscription['secure'])

        # check if DDM server is running
        if not self.dq2.is_ddm_server_alive():
            raise DQBackendException('DDM Server is down!')
        
        self.queries = queries
        self.datasetname = 'stresstest.thread-'+str(self.myid)+'.'+self.uuid()
        self.filesperds = filesperds


    def runQueries(self, dsno):
        """Run NO_QUERIES querying files in dataset for random dataset
        numbers less than dsno"""

        start = time.time()
        
        for i in range(NO_QUERIES):
            randno = random.randint(0, dsno)
            self.dq2.listFilesInDataset(self.datasetname+'.'+str(randno))

        end = time.time()
        ave = (end-start)/NO_QUERIES
        print '%i datasets in catalog: ave query time %.3fs' % (dsno, ave)
            
        
    def run(self):
        """Add a dataset, query for it then delete it"""

        stime = time.time()
        print 'starting at %s'% time.ctime()

        try:
            for i in range(self.queries):

                dsname = self.datasetname+'.'+str(i)
                
                # do this in two steps or one?
                # two steps is about 50% slower..
                
                #self.dq2.registerNewDataset(dsname)

                lfns = []
                guids = []
                for j in range(self.filesperds):
                    lfns.append(dsname+'.file'+str(j))
                    # don't want uuidgen time measured
                    guids.append(dsname+'.guid'+str(j))
                
                self.dq2.registerNewDataset(dsname,
                                            lfns=lfns,
                                            guids=guids)
                
                if i % QUERY_FREQ == 0 and i != 0: # run queries
                    etime = time.time()
                    ave = (etime-stime)/QUERY_FREQ
                    print '%i datasets in catalog: ave insert time %.3fs' % (i, ave)
                    self.runQueries(i)
                    stime = time.time()

        except DQException, e:
            print str(e)


    def uuid(self):
        return commands.getoutput('uuidgen').strip()



def runTest(conf, datasets, filesperds, nthreads):
    """Launch a bunch of threads to issue requests"""

    start = time.time()

    for i in range(nthreads):
        t = TestThread(conf, datasets/nthreads, filesperds)
        t.start()

    for th in threading.enumerate()[1:]:
        th.join()

    end = time.time()

    print 'test took in total %f secs' % (end-start)

if __name__ == '__main__':
    main(sys.argv[1:])

