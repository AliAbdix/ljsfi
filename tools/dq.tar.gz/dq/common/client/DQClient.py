"""
$Id: DQClient.py,v 1.14.2.12 2006/08/01 11:39:54 psalgado Exp $
"""
import common.DQPing
import common.DQValidator
import urllib
import x509

from common.client.DQCurl import DQCurl
from common.DQConstants import HTTP
from common.DQException import DQInvalidRequestException

tag = "$Name: DQ2_0_2_BRANCH $"

# assumes tag is of the form DQ2_x_y_z
version = tag[11:-2].replace('_', '.')

class DQClient (object):
    """
    Class to wrap HTTP request configurations.
    (since 0.2.0)
    
    ca_path is the location of the Certification Authority certificates.
    certificate is the proxy certificate.
    params are the parameters to be sent with the request
    (USE dictionary for GET and DELETE and USE lists for POST and PUT).
    request is the HTTP URL.
    is_secure send the HTTP request as secure (only applicable for GET and POST),
    by default GET is insecure and POST is secure.
    type is the type of HTTP request to send.
    url is the non-secure URL of the host to be contacted.
    urlsec is the secure URL of the host to be contacted.
    """

    WEBSERVICE_SUFFIX = 'ws_' 


    def __init__ (self, url=None, urlsec=None, certificate=None, ca_path=None):
        """
        Constructs a DQClient instance.
        (since 0.2.0)
        
        url is the non-secure URL of the host to be contacted.
        urlsec is the secure URL of the host to be contacted.
        certificate is the proxy certificate.
        ca_path is the location of the Certification Authority certificates.
        
        If the client is created without passing urls,
        the auto configuration will be used instead.
        """
        
        if url is None or urlsec is None:
            conf_url, conf_urlsec = self.auto_configure()
        if url is None: url = conf_url
        if urlsec is None: urlsec = conf_urlsec
        
        common.DQValidator.is_http_url(url)
        common.DQValidator.is_http_url(urlsec)
        
        self.url = url
        self.url_secure = urlsec
        self.certificate = certificate
        self.ca_path = ca_path
        
        self._reset()


    def __str__ (self):
        """
        Returns a string representation of this object.
        (0.2.1)
        """
        return """DQClient (%s, %s)""" % (self.url, self.url_secure)


# PRIVATE methods


    def _get_hosts(self):
        """
        Returns a tuple containing the insecure and secure hosts.
        (since 0.2.1)
        
        (insecure_host, secure_host)
        """
        insecure_host = common.DQPing.getHostname(self.url)
        
        secure_host = common.DQPing.getHostname(self.url_secure)
        
        return (insecure_host, secure_host)


    def _get_url(self):
        """
        Builds the HTTP request endpoint and the URL rewriting.
        (since 0.2.0)
        """

        first_slash = self.request.find('/')
        self.request = self.request[:first_slash+1] +'ws_'+ self.request[first_slash+1:]

        if self.type == HTTP.PUT or self.type == HTTP.POST:
            """for PUT and POST requests"""
            for eachKey in self.params.keys():
                if self.params[eachKey] is None:
                    del self.params[eachKey]
            #    if self.params[eachParam] is not None:
            #        self.params[eachParam] = urllib.quote_plus(str(self.params[eachParam]))
            return urllib.quote(self.request)
        elif self.type == HTTP.GET or self.type == HTTP.DELETE:
            """for GET and DELETE and requests."""
            for eachKey in self.params.keys():
                if self.params[eachKey] is None:
                    """remove parameters whose value is None"""
                    del self.params[eachKey]
                #else:
                #    params += str(eachKey) +'='+ urllib.quote_plus(str(self.params[eachKey])) +'&amp;'
            params = urllib.urlencode(self.params)
            
            return urllib.quote(self.request) +'?'+ params
        raise DQInvalidRequestType('HTTP request %s is not a GET, POST, PUT or DELETE request!', self.type)


    def _reset(self):
        """
        Resets the destination request data.
        (since 0.2.0)
        """
        self.is_secure = None
        self.params = {}
        self.request = None
        self.type = None


    def _set_security(self, default=None):
        """
        (since 0.2.0)
        """
        
        if self.ca_path is None:
            self.ca_path = x509.getCAPath()
        
        # set default security
        if self.is_secure is None:
            self.is_secure = default
        
        if not self.is_secure:
            """not a secure request"""
            return
        
        # setup GRID certificate and CA path - if necessary
        if self.certificate is None:
            self.certificate = x509.getX509()


# PUBLIC methods


    def auto_configure():
        """
        Returns this client configuration.
        (since 0.2.0)
        
        Note: This method is meant to be overriden by its subclasses.
        
        (url_insecure_host, url_secure_host)
        """
        pass

    auto_configure = staticmethod(auto_configure)


    def send (self):
        """
        Sends the HTTP request to the destination.
        (since 0.2.0)
        
        DQSecurityException is raised,
        in case of an invalid proxy certificate.
        """
        
        try:
            
            request = self._get_url()
            
            if self.type == HTTP.GET:
                """GET are by default insecure."""
                
                self._set_security(False)
                c = DQCurl(self.url, self.url_secure, self.certificate, self.ca_path)
                
                output = c.get(request, self.is_secure)
            
            elif self.type == HTTP.POST:
                """POST are by default secure."""
                
                self._set_security(True)
                c = DQCurl(self.url, self.url_secure, self.certificate, self.ca_path)
                
                params = []
                for eachKey in self.params.keys():
                    params.append(str(eachKey) +'='+ str(self.params[eachKey]))
                output = c.post(request, params, self.is_secure)
            
            elif self.type == HTTP.PUT:
                """PUT are always secure."""
                
                self._set_security(True)
                c = DQCurl(self.url, self.url_secure, self.certificate, self.ca_path)
                
                params = []
                for eachKey in self.params.keys():
                    params.append(str(eachKey) +'='+ str(self.params[eachKey]))
                output = c.put(request, params)
            
            elif self.type == HTTP.DELETE:
                """DELETE are always secure."""
                
                self._set_security(True)
                c = DQCurl(self.url, self.url_secure, self.certificate, self.ca_path)
                output = c.delete(request)
            
        finally:
            self._reset()
        
        return output
