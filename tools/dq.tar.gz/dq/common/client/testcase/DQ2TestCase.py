"""
A series of tests to make sure DQ2 and the catalogs are working ok.

TODO list:
- test add a dataset subscription to a non-existing dataset version => DQUnknownDatasetVersionException. 

+ add this test
python LocationClient.py addDatasetReplica -i vuid_1 site_1 psalgado_1
None
python LocationClient.py queryDatasetsInSite -c site_1
{}
python LocationClient.py queryDatasetsInSite -i site_1
{'psalgado_1': ['vuid_1']}
python LocationClient.py addDatasetReplica vuid_1 site_1 psalgado_1
Error: The dataset vuid_1 already exists at location site_1!
python LocationClient.py addDatasetReplica -i vuid_1 site_1 psalgado_1
Error: The dataset vuid_1 already exists at location site_1!
python LocationClient.py addDatasetReplica -c vuid_1 site_1 psalgado_1
None
python LocationClient.py queryDatasetsInSite -c site_1
{'psalgado_1': ['vuid_1']}
python LocationClient.py queryDatasetsInSite -i site_1
{}

"""

import commands
import sys
import os

from common.DQConstants import DatasetState, LocationState, SubscriptionArchivedState, TestCaseData
from common.DQException import *

from common.client.DQ2 import DQ2

from common.testcase.DQTestCase import DQTestCase

TestCaseData.LFNS.sort()
TestCaseData.GUIDS.sort()
TestCaseData.SOURCES.sort()


class DQ2TestCase (DQTestCase):
    """
    Testcase for the common.client.DQ2 module.
    (since 0.2.0)
    """


    def __init__ (self, name):
        """
        Constructs an instance of DQ2TestCase.
        (since 0.2.1)
        
        name is the testcase name.
        """
        DQTestCase.__init__(self, name)

        self.dq2 = DQ2()
        self._cleanup_database()
    

    def _cleanup_database (self):
        """
        (since 0.2.7)
        """
        #for dataset in datasets:
        #    try: self.dq2.eraseDataset(dataset)
        #    except DQUnknownDatasetException: pass
        for dsn in TestCaseData.DSNS:
            try:
                self.dq2.eraseDataset(dsn)
            except DQUnknownDatasetException:
                pass


    def setUp (self):
        """
        (since 0.2.0)
        """
        pass


    def tearDown (self):
        """
        (since 0.2.0)
        """
        self._cleanup_database()


    def testClientConfigurations (self):
        """
        Tests the common.client.DQ2.test_client_configurations method.
        
        # 1. valid client configurations and DDM server working.
        # 2. valid client configurations and DDM server down.
        # 3. invalid client configurations.
        """
        
        # 1. valid client configurations and DDM server working.
        configurations = self.dq2.test_client_configurations()
        #print str(configurations)
        #print '\n'
        
        # 2. valid client configurations and DDM server down.
        always_good_host = 'http://127.0.0.1/'
        dq2 = DQ2(always_good_host, always_good_host, always_good_host, always_good_host, always_good_host, always_good_host, always_good_host, always_good_host, always_good_host, always_good_host)
        configurations = dq2.test_client_configurations()
        #print str(configurations)
        #print '\n'
        
        # 3. invalid client configurations.
        bad_url = 'http://127.0.0.2/'
        dq2 = DQ2(bad_url, bad_url, bad_url, bad_url, bad_url, bad_url, bad_url, bad_url, bad_url, bad_url)
        configurations = dq2.test_client_configurations()
        #print str(configurations)
        #print '\n'


    def testCompleteness (self):
        """
        (since 0.2.0)
        """
        self.dq2.registerNewDataset(TestCaseData.DSNS[0],TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1])
        self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], TestCaseData.SOURCES[0], complete=LocationState.INCOMPLETE)
        self.dq2.freezeDataset(TestCaseData.DSNS[0])
        self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], TestCaseData.SOURCES[1], complete=LocationState.COMPLETE)
        
        expected = {0: [TestCaseData.SOURCES[0]], 1: []}
        result = self.dq2.listDatasetReplicas(TestCaseData.DSNS[0], complete=LocationState.INCOMPLETE)[TestCaseData.DSNS[0]]
        self.assertEqual(expected, result)
        
        expected = {0: [], 1: [TestCaseData.SOURCES[1]]}
        result = self.dq2.listDatasetReplicas(TestCaseData.DSNS[0], complete=LocationState.COMPLETE)[TestCaseData.DSNS[0]]
        self.assertEqual(expected, result)


    def testDatasetState (self):
        """
        Tests common.client.DQ2.closeDataset, common.client.DQ2.freezeDataset methods.
        
        Tests also if there is any case sensitive problem.
        # 1.1 closeDataset prevents user to register more files in dataset
        # 1.2 closeDataset on a closed dataset raises an exception
        # 1.3 closeDataset is safe from case-sensitiveness issues
        # 2.1 freezeDataset prevents user to register more files in dataset
        # 2.2 freezeDataset prevents user to close dataset
        # 2.3 freezeDataset on a frozen dataset raises an exception
        """
        # test for case sensitive problem
        for eachDSN in [TestCaseData.DSNS[0], TestCaseData.DSNS[0].lower(), TestCaseData.DSNS[0].upper()]:
            self._testDatasetState(eachDSN)
            self._cleanup_database()


    def _testDatasetState (self, dsn):
        """
        Tests common.client.DQ2.closeDataset, common.client.DQ2.freezeDataset methods.
        
        # 1.1 closeDataset prevents user to register more files in dataset
        # 1.2 closeDataset on a closed dataset raises an exception
        # 1.3 closeDataset is safe from case-sensitiveness issues
        # 2.1 freezeDataset prevents user to register more files in dataset
        # 2.2 freezeDataset prevents user to close dataset
        # 2.3 freezeDataset on a frozen dataset raises an exception
        """
        
        #  1.1 closeDataset prevents user to register more files in dataset
        self.dq2.registerNewDataset(TestCaseData.DSNS[0])
        self.dq2.closeDataset(dsn)
        
        self.assertRaises(DQClosedDatasetException,
                          self.dq2.registerFilesInDataset,
                          dsn, TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1])
        # 1.2 closeDataset on a closed dataset raises an exception
        self.assertRaises(DQClosedDatasetException,
                          self.dq2.closeDataset,
                          dsn)
        
        # 2.1 freezeDataset prevents user to register more files in dataset
        self.dq2.freezeDataset(TestCaseData.DSNS[0])
        
        self.assertRaises(DQFrozenDatasetException,
                          self.dq2.registerFilesInDataset,
                          TestCaseData.DSNS[0], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1])
        
        # 2.2 freezeDataset prevents user to close dataset
        self.assertRaises(DQFrozenDatasetException,
                          self.dq2.closeDataset,
                          dsn)
        
        # 2.3 freezeDataset on a frozen dataset raises an exception
        # 2.3.1 dsn is equal to what was registered in the catalog
        self.assertRaises(DQFrozenDatasetException,
                          self.dq2.freezeDataset,
                          dsn)


    def testDeleteDatasetReplica (self):
        """
        (since 0.2.0)
        
        # 1. deleteDatasetReplicas
        # 1.1 dsn is equal to what was registered in the catalog
        # 1.2 dsn is in lowercase
        # 1.3 dsn is in uppercase
        """
        self.dq2.registerNewDataset(TestCaseData.DSNS[0],TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1])
        
        # test for case sensitive problem
        dsns = [TestCaseData.DSNS[0], TestCaseData.DSNS[0].lower(), TestCaseData.DSNS[0].upper()]
        for eachDSN in dsns:
            # registers an incomplete dataset replica
            self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], TestCaseData.SOURCES[0])
            # registers another incomplete dataset replica
            self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], TestCaseData.SOURCES[1])
            self.dq2.deleteDatasetReplicas(eachDSN, [TestCaseData.SOURCES[0]])
            
            expected = {0: [TestCaseData.SOURCES[1]], 1: []}
            result = self.dq2.listDatasetReplicas(TestCaseData.DSNS[0])[TestCaseData.DSNS[0]]
            self.assertEqual(expected, result)
            self.dq2.deleteDatasetReplicas(eachDSN, [TestCaseData.SOURCES[1]])
            
            # 1. deleteDatasetReplicas
            expected = {}
            result = self.dq2.listDatasetReplicas(TestCaseData.DSNS[0])
            self.assertEqual(expected, result)


    def testEraseDataset (self):
        """
        (since 0.2.0)
        
        # 1. delete dataset
        # 1.1 dsn is equal to what was registered in the catalog
        # 1.2 dsn is in lowercase
        # 1.3 dsn is in uppercase
        """
        # use catalog registered case, lowercase and uppercase dataset name
        dsns = [TestCaseData.DSNS[0], TestCaseData.DSNS[0].lower(), TestCaseData.DSNS[0].upper()]
        
        # test for case sensitive problem
        for eachDSN in dsns:
            self.dq2.registerNewDataset(TestCaseData.DSNS[0],TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1])
            self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], TestCaseData.SOURCES[0])
            self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], TestCaseData.SOURCES[1])
            self.dq2.eraseDataset(eachDSN)
            
            # 1. delete dataset
            result = self.dq2.listDatasets(TestCaseData.DSNS[0])
            expected = {}
            
            self.assertEqual(expected, result, self._fmt_message('1. delete dataset', expected, result))


    def testFileOperationsInDataset (self):
        """
        Tests addind and removing files from a dataset.
        (since 0.2.1)
        """
        # test for case sensitive problem
        for eachDSN in [TestCaseData.DSNS[0], TestCaseData.DSNS[0].lower(), TestCaseData.DSNS[0].upper()]:
            self._testFileOperationsInDataset(eachDSN)
            self._cleanup_database()


    def _testFileOperationsInDataset (self, dsn):
        """"""
        self.dq2.registerNewDataset(TestCaseData.DSNS[0], [TestCaseData.LFNS[0]], [TestCaseData.GUIDS[0]])
        self.dq2.registerFilesInDataset(dsn, [TestCaseData.LFNS[1]], [TestCaseData.GUIDS[1]])
        dsfiles = self.dq2.listFilesInDataset(dsn)
        
        result_guids = dsfiles.keys()
        result_guids.sort()
        
        result_lfns = dsfiles.values()
        result_lfns.sort()
        
        self.assertEqual(result_guids, TestCaseData.GUIDS)
        self.assertEqual(result_lfns, TestCaseData.LFNS)
        
        # 1. deleteFilesFromDataset
        
        self.dq2.deleteFilesFromDataset(dsn, [TestCaseData.GUIDS[0]])
        dsfiles = self.dq2.listFilesInDataset(dsn)
        
        result_guids = dsfiles.keys()
        result_guids.sort()
        
        result_lfns = dsfiles.values()
        result_lfns.sort()
        
        self.assertEqual(result_guids, [TestCaseData.GUIDS[1]])
        self.assertEqual(result_lfns, [TestCaseData.LFNS[1]])


    def testGetNumberOfFiles (self):
        self.dq2.registerNewDataset(TestCaseData.DSNS[0],TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1])
        self.assertEqual(self.dq2.getNumberOfFiles(TestCaseData.DSNS[0]), 1)
        self.dq2.registerFilesInDataset(TestCaseData.DSNS[0], TestCaseData.LFNS[1:2], TestCaseData.GUIDS[1:2])
        self.assertEqual(self.dq2.getNumberOfFiles(TestCaseData.DSNS[0]), 2)


    def testListDatasetReplicas (self):
        """
        (since 0.2.0)
        """
        # test for case sensitive problem
        for eachDSN in [TestCaseData.DSNS[0], TestCaseData.DSNS[0].lower(), TestCaseData.DSNS[0].upper()]:
            self._testListDatasetReplicas(eachDSN)
            self._cleanup_database()


    def _testListDatasetReplicas (self, dsn):
        """"""
        self.dq2.registerNewDataset(TestCaseData.DSNS[0],TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1])
        self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], TestCaseData.SOURCES[0])
        self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], TestCaseData.SOURCES[1])
        
        expected = {LocationState.INCOMPLETE: TestCaseData.SOURCES[0:2], LocationState.COMPLETE: []}
        result = self.dq2.listDatasetReplicas(dsn)[TestCaseData.DSNS[0]]
        
        self.assertEqual(result, expected)


    def testListDatasets (self):
        """
        Tests common.client.DQ2.listDatasets method.
        
        (since 0.2.0)
        
        # 1. queryDatasetByName with the registered name
        # 2. queryDatasetByName with the registered name in lowercase and answer in registered case
        # 3. queryDatasetByName with the registered name in uppercase and answer in registered case
        """
        
        # 1. queryDatasetByName with the registered name
        
        regular = TestCaseData.DSNS[0]
        self.dq2.registerNewDataset(regular, TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1])
        
        result = self.dq2.listDatasets(regular).keys()
        expected = [TestCaseData.DSNS[0]]
        
        self.assertEqual(expected, result, self._fmt_message(expected, result, '1. queryDatasetByName with the registered name'))
        
        
        # 2. queryDatasetByName with the registered name in lowercase and answer in registered case
        
        lowercase = TestCaseData.DSNS[0].lower()
        
        result = self.dq2.listDatasets(lowercase).keys()
        expected = [TestCaseData.DSNS[0]]
        
        self.assertEqual(expected, result, self._fmt_message(expected, result, '2. queryDatasetByName with the registered name in lowercase'))
        
        # 3. queryDatasetByName with the registered name in uppercase and answer in registered case
        
        uppercase = TestCaseData.DSNS[0].upper()
        
        result = self.dq2.listDatasets(uppercase).keys()
        expected = [TestCaseData.DSNS[0]]
        
        self.assertEqual(expected, result, self._fmt_message(expected, result, '2. queryDatasetByName with the registered name in lowercase'))


    def testListDatasetsInSite (self):
        """
        (since 0.2.0)
        """
        
        self.dq2.registerNewDataset(TestCaseData.DSNS[0], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1])
        self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], TestCaseData.SOURCES[0])
        self.dq2.registerNewDataset(TestCaseData.DSNS[1], TestCaseData.LFNS[1:2], TestCaseData.GUIDS[1:2])
        self.dq2.registerDatasetLocation(TestCaseData.DSNS[1], TestCaseData.SOURCES[0])
        
        dsets = self.dq2.listDatasetsInSite(TestCaseData.SOURCES[0])
        result = dsets.keys()
        result.sort()
        expected =  TestCaseData.DSNS[0:2]
        
        self.assertEqual(expected, result, self._fmt_message('', expected, result))


    def testListFileReplicas (self):
        """
        (since 0.2.0)
        """
        self.dq2.registerNewDataset(TestCaseData.DSNS[0], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1])
        
        # trying to register a complete replica on a open dataset
        self.assertRaises(
            DQOpenedDatasetException,
            self.dq2.registerDatasetLocation,
            TestCaseData.DSNS[0], TestCaseData.SOURCES[0], complete=LocationState.COMPLETE
        )
        self.dq2.closeDataset(TestCaseData.DSNS[0])
        
        # listFileReplicas only checks for complete dataset locations
        self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], TestCaseData.SOURCES[0], complete=LocationState.COMPLETE)
        self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], TestCaseData.SOURCES[1], complete=LocationState.COMPLETE)

        expected = {LocationState.INCOMPLETE: [], LocationState.COMPLETE: TestCaseData.SOURCES[0:2]}
        result = self.dq2.listFileReplicas(TestCaseData.LFNS[0])[TestCaseData.DSNS[0]]
        
        self.assertEqual(expected, result)


    def testListFilesInDataset (self):
        """
        (since 0.2.0)
        """
        # test for case sensitive problem
        for eachDSN in [TestCaseData.DSNS[0], TestCaseData.DSNS[0].lower(), TestCaseData.DSNS[0].upper()]:
            self._testListFilesInDataset(eachDSN)
            self._cleanup_database()


    def _testListFilesInDataset (self, dsn):
        """
        (since 0.2.0)
        """
        self.dq2.registerNewDataset(TestCaseData.DSNS[0],TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1])
        dsfiles = self.dq2.listFilesInDataset(dsn)
        
        self.assertEqual(dsfiles.keys(), TestCaseData.GUIDS[0:1])
        self.assertEqual(dsfiles.values(), TestCaseData.LFNS[0:1])
        
        self.dq2.registerNewVersion(dsn,TestCaseData.LFNS[1:2], TestCaseData.GUIDS[1:2])
        dsfiles = self.dq2.listFilesInDataset(dsn)
        
        result_guids = dsfiles.keys()
        result_guids.sort()
        
        result_lfns = dsfiles.values()
        result_lfns.sort()
        
        self.assertEqual(result_guids, TestCaseData.GUIDS)
        self.assertEqual(result_lfns, TestCaseData.LFNS)


    def testListSubscriptions (self):
        """
        Tests common.client.DQ2.listSubscriptionsInSite method.
        
        (since 0.2.0)
        
        # 1. listSubscriptions with no datasets
        # 2. listSubscriptions
        # 2.1 listSubscriptions only unarchived
        # 2.2 listSubscriptions only archived
        # 2.3 listSubscriptions on any state
        """
        
        # 1. listSubscriptionsInSite with no datasets
        
        self.assertRaises(
            DQUnknownDatasetException,
            self.dq2.listSubscriptions,
            TestCaseData.DSNS[0]
        )
        
        
        # 2. listSubscriptionsInSite
        
        # registering datasets
        duid_0 = self.dq2.registerNewDataset(TestCaseData.DSNS[0])['duid']
        duid_1 = self.dq2.registerNewDataset(TestCaseData.DSNS[1])['duid']
        
        # registering subscriptions
        self.dq2.registerDatasetSubscription(TestCaseData.DSNS[1], TestCaseData.DESTINATIONS[0], archived=SubscriptionArchivedState.UNARCHIVE)
        self.dq2.registerDatasetSubscription(TestCaseData.DSNS[1], TestCaseData.DESTINATIONS[1], archived=SubscriptionArchivedState.ARCHIVE)
        
        # 2.1 listSubscriptions with no dataset
        result = self.dq2.listSubscriptions(TestCaseData.DSNS[0])
        expected = []
        
        self.assertEqual(result, expected, self._fmt_message('2.1. listSubscriptions with no dataset', expected, result))
        
        # 2.2 listSubscriptionsInSite only unarchived
        result = self.dq2.listSubscriptions(TestCaseData.DSNS[1], archived=SubscriptionArchivedState.UNARCHIVE)
        expected = [TestCaseData.DESTINATIONS[0]]
        
        self.assertEqual(result, expected, self._fmt_message('2.2 listSubscriptions only unarchived', expected, result))
        
        # 2.3 listSubscriptionsInSite only archived
        result = self.dq2.listSubscriptions(TestCaseData.DSNS[1], archived=SubscriptionArchivedState.ARCHIVE)
        expected = [TestCaseData.DESTINATIONS[1]]
        
        self.assertEqual(result, expected, self._fmt_message('2.3 listSubscriptions only archived', expected, result))
        
        # 2.4 listSubscriptionsInSite on any state
        result = self.dq2.listSubscriptions(TestCaseData.DSNS[1])
        result.sort()
        expected = [TestCaseData.DESTINATIONS[0], TestCaseData.DESTINATIONS[1]]
        expected.sort()
        
        self.assertEqual(result, expected, self._fmt_message('2.4 listSubscriptions on any state', expected, result))


    def testListSubscriptionsInSite (self):
        """
        Tests common.client.DQ2.listSubscriptionsInSite method.
        
        (since 0.2.0)
        
        # 1. listSubscriptionsInSite with no datasets
        # 2. listSubscriptionsInSite
        # 2.1 listSubscriptionsInSite with no dataset
        # 2.2 listSubscriptionsInSite only unarchived
        # 2.3 listSubscriptionsInSite only archived
        # 2.4 listSubscriptionsInSite on any state
        """
        # 1. listSubscriptionsInSite with no datasets
        result = self.dq2.listSubscriptionsInSite(TestCaseData.DESTINATIONS[0])
        expected = {}
        
        self.assertEqual(result, expected, self._fmt_message('1. listSubscriptionsInSite with no datasets', expected, result))
        
        # 2. listSubscriptionsInSite
        
        # registering datasets
        duid_0 = self.dq2.registerNewDataset(TestCaseData.DSNS[0])['duid']
        duid_1 = self.dq2.registerNewDataset(TestCaseData.DSNS[1])['duid']
        
        # registering subscriptions
        self.dq2.registerDatasetSubscription(TestCaseData.DSNS[0], TestCaseData.DESTINATIONS[0], archived=SubscriptionArchivedState.UNARCHIVE)
        self.dq2.registerDatasetSubscription(TestCaseData.DSNS[1], TestCaseData.DESTINATIONS[0], archived=SubscriptionArchivedState.ARCHIVE)
        
        # 2.1 listSubscriptionsInSite with no dataset
        result = self.dq2.listSubscriptionsInSite(TestCaseData.DESTINATIONS[1])
        expected = {}
        
        self.assertEqual(result, expected, self._fmt_message('1. listSubscriptionsInSite with no datasets', expected, result))
        
        # 2.2 listSubscriptionsInSite only unarchived
        result = self.dq2.listSubscriptionsInSite(TestCaseData.DESTINATIONS[0], archived=SubscriptionArchivedState.UNARCHIVE).keys()
        expected = [duid_0]
        
        self.assertEqual(result, expected, self._fmt_message('2.2 listSubscriptionsInSite only archived', expected, result))
        
        # 2.3 listSubscriptionsInSite only archived
        result = self.dq2.listSubscriptionsInSite(TestCaseData.DESTINATIONS[0], archived=SubscriptionArchivedState.ARCHIVE).keys()
        expected = [duid_1]
        
        self.assertEqual(result, expected, self._fmt_message('2.3 listSubscriptionsInSite only archived', expected, result))
        
        # 2.4 listSubscriptionsInSite on any state
        result = self.dq2.listSubscriptionsInSite(TestCaseData.DESTINATIONS[0]).keys()
        result.sort()
        expected = [duid_0, duid_1]
        expected.sort()
        
        self.assertEqual(result, expected, self._fmt_message('2.4 listSubscriptionsInSite on any state', expected, result))


    def testRegisterDatasetLocations (self):
        """
        (since 0.2.0)
        """
        # test for case sensitive problem
        for eachDSN in [TestCaseData.DSNS[0], TestCaseData.DSNS[0].lower(), TestCaseData.DSNS[0].upper()]:
            self._testRegisterDatasetLocations(eachDSN)
            self._cleanup_database()


    def _testRegisterDatasetLocations (self, dsn):
        """
        (since 0.2.0)
        """
        self.dq2.registerNewDataset(TestCaseData.DSNS[0], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1])
        self.dq2.registerDatasetLocation(dsn, TestCaseData.SOURCES[0])
        
        expected = {TestCaseData.DSNS[0]: {LocationState.INCOMPLETE: [TestCaseData.SOURCES[0]], LocationState.COMPLETE: []}}
        
        result = self.dq2.listDatasetReplicas(TestCaseData.DSNS[0])
        self.assertEqual(expected, result)


    def testRegisterNewDataset (self):
        """
        (deprecated)
        """
        pass


    def testRegisterNewDatasetExceptions (self):
        """
        (since 0.2.0)
        """
        self.assertRaises(DQInvalidRequestException,
                          self.dq2.registerNewDataset,
                          TestCaseData.DSNS[0], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:2])
        
        self.dq2.registerNewDataset(TestCaseData.DSNS[0])
        self.assertRaises(DQDatasetExistsException,
                          self.dq2.registerNewDataset,
                          TestCaseData.DSNS[0])


    def testRegisterNewVersion (self):
        """
        (since 0.2.0)
        """
        # test for case sensitive problem
        for eachDSN in [TestCaseData.DSNS[0], TestCaseData.DSNS[0].lower(), TestCaseData.DSNS[0].upper()]:
            self._testRegisterNewVersion(eachDSN)
            self._cleanup_database()


    def _testRegisterNewVersion (self, dsn):
        """
        (since 0.2.0)
        """
        self.dq2.registerNewDataset(TestCaseData.DSNS[0], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1])
        self.assertRaises(
            DQContentAlreadyExists,
            self.dq2.registerNewVersion,
            TestCaseData.DSNS[0], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1]
        )
        
        self.dq2.registerNewVersion(dsn, TestCaseData.LFNS[1:2], TestCaseData.GUIDS[1:2])        
        self.assertEqual(self.dq2.listDatasets(TestCaseData.DSNS[0], version=2).keys(), [TestCaseData.DSNS[0]])
        
        dsfiles = self.dq2.listFilesInDataset(TestCaseData.DSNS[0])
        result_guids = dsfiles.keys()
        result_guids.sort()
        
        result_lfns = dsfiles.values()
        result_lfns.sort()
        
        self.assertEqual(result_guids, TestCaseData.GUIDS)
        self.assertEqual(result_lfns, TestCaseData.LFNS)
        
        self.assertEqual(self.dq2.getNumberOfFiles(TestCaseData.DSNS[0]), 2)


    def testRegisterNewVersionExceptions (self):
        """
        (since 0.2.0)
        """
        self.assertRaises(DQInvalidRequestException,
                          self.dq2.registerNewVersion,
                          TestCaseData.DSNS[0], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:2])
        
        self.assertRaises(DQUnknownDatasetException,
                          self.dq2.registerNewVersion,
                          TestCaseData.DSNS[0], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1])
        self.dq2.registerNewDataset(TestCaseData.DSNS[0],TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1])
        # trying to register a new dataset version with already existing files 
        self.assertRaises(DQContentAlreadyExists,
                          self.dq2.registerNewVersion,
                          TestCaseData.DSNS[0], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1])


    def testCaseSensitiveness (self):
        """
        Tests for case sensitiveness issues on common.client.DQ2 methods.
        
        # 1. closeDataset is safe from case-sensitiveness issues
        """
        dsn_lower = TestCaseData.DSNS[0].lower()
        dsn_upper = TestCaseData.DSNS[0].upper()
        
        self.dq2.registerNewDataset(dsn_lower)
        
        # 1. closeDataset is safe from case-sensitiveness issues
        self.dq2.closeDataset(dsn_upper)


if __name__ == '__main__':
    dq2 = DQ2()
    print str(dq2)
    import sys
    argv = sys.argv[1:]
    
    import unittest
    if len(argv) >= 1:
        suite = unittest.TestSuite()
        
        for eachTest in argv:
            suite.addTest(DQ2TestCase(eachTest))
    
    else:
        suite = unittest.makeSuite(DQ2TestCase)
    
    unittest.TextTestRunner(verbosity=2).run(suite)
