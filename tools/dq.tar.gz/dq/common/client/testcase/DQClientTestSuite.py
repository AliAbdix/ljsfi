"""
Run the DQ2 client testcases.

$Id: DQClientTestSuite.py,v 1.4.2.2 2006/06/06 10:09:27 mbranco Exp $
"""

from common.client.testcase.DQ2TestCase import DQ2TestCase
from common.client.testcase.x509TestCase import X509TestCase


def main ():
    """
    Runs all DQ2 client tests.
    (since 0.2.0)
    """
    import unittest
    suite = unittest.TestSuite((
        unittest.makeSuite(X509TestCase,'test'),
        unittest.makeSuite(DQ2TestCase,'test'))
    )

    unittest.TextTestRunner(verbosity=2).run(suite)


if __name__ == '__main__':
    main()
