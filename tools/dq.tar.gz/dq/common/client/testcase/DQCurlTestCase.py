"""
Testcase to check DQCurl<->DQ2 communications.
"""

import mock

from common.client.mock.DQMockCurl import DQMockCurl
from common.testcase.DQTestCase import DQTestCase


class DQCurlTestCase (DQTestCase):
    """
    Testcase to check DQCurl<->DQ2 communications.
    (since 0.2.0)
    """


    def setUp (self, proxy_cert=None):
        """
        (since 0.2.0)
        """

        url ='http://%s:%s' % ('pcatlas264', '8000')
        urlsec = 'https://%s:%s' % ('127.0.0.1', '8443')

        self.c = DQMockCurl(url, urlsec, proxy_cert)


    def tearDown (self):
        """
        (since 0.2.0)
        """
        pass


    def testRaise (self):
        """
        (since 0.2.0)
        """

        request = '/mock/server/base/raise_stub'
        try:
            self.c.get(request)
            self.fail('Exception was not raised.')
        except mock.exceptions.StubException, e:
            pass
            #print '[OK] StubException was raised!'


        request = '/mock/server/base/raise_stub2'
        try:
            self.c.get(request)
            self.fail('Exception was not raised.')
        except mock.exceptions.Stub2Exception, e:
            pass
            #print '[OK] Stub2Exception was raised!'
        
        
        request = '/mock/server/base/raise_stub3'
        try:
            self.c.get(request)
            self.fail('Exception was not raised.')
        except mock.exceptions.Stub3Exception, e:
            pass
            #print '[OK] Stub3Exception was raised!'


if __name__ == '__main__':
    """
    (since 0.2.0)
    """
    import unittest
    suite = unittest.makeSuite(DQCurlTestCase)
    unittest.TextTestRunner(verbosity=2).run(suite)
