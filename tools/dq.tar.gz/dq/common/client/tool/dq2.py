#!/usr/bin/env python

import xml.dom
import xml.dom.minidom
import getopt
import os
import sys

try:
    from common.client.DQ2 import DQ2
    from common.client.x509 import getX509
    from common.DQConstants import *
    from common.DQException import *
    from common import DQPing
except ImportError:
    print "Environment not set [error importing DQ2 dependencies]!"
    sys.exit(1)


# Map of valid actions and number of arguments [nr mandatory args, unlimited args, if so whether they have to be even]
actions = {
    'closeDataset'                : [1, True, False],
    'deleteFilesFromDataset'      : [2, True, False],
    'deleteDatasetReplicas'       : [2, True, False],
    'deleteDatasetSubscription'   : [2, False],
    'deleteDatasetSubscriptions'  : [2, False],    
    'eraseDataset'                : [1, False],
    'freezeDataset'               : [1, False],
    'getMetaDataAttribute'        : [2, True, False],
    'getMetaData'                 : [1, True, False],
    'getNumberOfFiles'            : [1, False],
    'listDatasetReplicas'         : [1, False],
    'listFilesInDataset'          : [1, False],
    'listDatasetsInSite'          : [1, False],
    'listSubscriptions'           : [1, False],
    'listSubscriptionInfo'        : [2, False],
    'listSubscriptionsInSite'     : [1, False],
    'listDatasets'                : [1, False],
    'listDatasetsByCreationDate'  : [1, False],
    'listDatasetsByMetaData'      : [2, True, True],
    'listFileReplicas'            : [1, False],
    'listMetaDataAttributes'      : [0, False],
    'listDestinations'            : [0, False],
    'listSources'                 : [0, False],
    'ping'                        : [0, False],
    'registerDatasetLocation'     : [2, False],
    'registerDatasetSubscription' : [2, True, False],
    'registerFilesInDataset'      : [1, True, True],
    'registerNewDataset'          : [1, True, True],
    'registerNewVersion'          : [1, True, True],
    'setMetaDataAttribute'        : [3, False],
    'stresstest'                  : [3, False],
    'unittest'                    : [0, False]

}
def chkargs(command, args):
    """Check action and number of arguments
    """
    try:
        # arguments are args minus action
        nargs = len(args)
        # get number of mandatory args and whether there is a limit
        nm = actions[command][0]
        nolimit = actions[command][1]
        # check if number of args is correct
        if nargs < nm or (nargs > nm and not nolimit):
            return False
        if nolimit and actions[command][2] and (len(args)-nm)%2 == 1:
            print 'Error: you must give matching pairs of arguments'
            return False
    except:
        return False

    return True


def getFilesFromCatalog(catalog):
    """Read in a xml POOL file catalog and return a list
    of guids and lfns in it"""

    catalog = os.path.expanduser(catalog)
    if not os.path.exists(catalog):
        raise DQUnknownFileException(catalog)
    
    try:
        doc = xml.dom.minidom.parse(catalog)
    except Exception, e:
        raise DQParseException(str(e))
    
    files = doc.getElementsByTagName("File")
    lfns = []
    guids = []

    for g in files:
        guid = g.getAttribute("ID")
        l = g.getElementsByTagName("lfn")
        lfn = ''
        if len(l) > 0:
            lfn = l[0].getAttribute("name")
        lfns.append(str(lfn))
        guids.append(str(guid))

    return lfns, guids
        
def usage():
    """
    Usage: dq2 <command> [-s configfile] <args>

    Commands:

    unittest (run the unit test suite)
    stresstest <no datasets> <no files per dataset>
                    <no threads> (run a stress test)
    ping (check client configurations and DDM server status)

    registerNewDataset [-f XML POOL file catalog] <dataset name>
                              (lfn1 guid1 lfn2 guid2..)
    registerNewVersion [-f XML POOL file catalog] <dataset name>
                              (lfn1 guid1 lfn2 guid2...)
    registerDatasetLocation <-i|-c> [-v dataset version ]
                              <dataset name> <location>
    registerFilesInDataset [-f XML POOL file catalog] <dataset name>
                              (lfn1 guid1 lfn2 guid2..)

    registerDatasetSubscription [-v dataset version]
                                [subscription options]
                                <dataset name> <location>
      Subscription options may be:
        --archived
            (dataset is to be archived on destination site)
        --complete-sources
            (include sites with complete replicas as possible sources)
        --incomplete-sources
            (include sites with incomplete replicas as possible sources)
        --close-sources
            (include sites close to destination as possible sources)
        --all-sources
            (include all available sites as possible sources - SLOW!)
        --sources=SITE1,SITE2,...
            (specify a comma-separated list set of known source sites as possible sources)
        --monitor=mail:miguel.branco@cern.ch
            (send regular notifications on progress)
        --callbacks-file-done=http://some.server
        --callbacks-vuid-complete=http://some.server
        --callbacks-error=http://some.server
        --destination="/new/base/directory"
            (set new destination base path)
        --wait-for-sources
            (should keep waiting for sources to appear if not found)

    closeDataset <dataset name>
    freezeDataset <dataset name>

    listDatasetReplicas [-i|-c] [-v dataset version] <dataset name>
    listFilesInDataset [-v dataset version] <dataset name>
    listDatasetsInSite [-i|-c] <site name>
    listSubscriptions [-a|-u] [-v dataset version] <dataset name>
    listSubscriptionInfo [-v dataset version] <dataset name> <site name>
    listSubscriptionsInSite [-a|-u] <site name>
    listFileReplicas <logical file name>
    listDatasets [-v dataset version] <dataset name>
    listDestinations
    listSources

    getMetaData --all <dataset name>
    setMetaDataAttribute <dataset name> <attr name> <attr value>
    getMetaDataAttribute <dataset name> <attr name>
    getNumberOfFiles <dataset name>
    listDatasetsByMetaData <attr1 name> <attr1 value>
                             <attr2 name> <attr2 value>...
    listDatasetsByCreationDate <days>
    listMetaDataAttributes

    deleteDatasetSubscription <dataset name> <site name> 
    deleteFilesFromDataset <dataset name> (guid1 guid2... guidN)
    deleteDatasetReplicas [-v dataset version] <dataset name> <site name(s)>
    eraseDataset <dataset name>

    -i and -c signify incomplete and complete datasets respectively
    (default is complete for adds, both for queries)
    If no -v option is supplied the latest version is used.
    -a and -u signify archive and unarchive respectively.
    """
    print usage.__doc__


def main(argv):

    if len(argv) < 1:
        usage()
        sys.exit(1)

    # check here that options are at the start
    # look for -something after something with no -
    if len(argv) > 1:
        nonminus = False
        for arg in argv[1:]:
            if arg[0] != '-':
                nonminus = True
            elif nonminus:
                print '\nOptions must go before arguments!\n'
                sys.exit(1)

    try:
        opts, args = getopt.getopt(argv[1:], "aciuv:f:p:r:s",
        # these are subscription options
            [
            "archived",
            "no-complete-sources", "no-incomplete-sources",
            "complete-sources", "incomplete-sources",
            "close-sources", "all-sources",
            "sources=",
            "monitor=",
            "callbacks-file-done=",
            "callbacks-vuid-complete=",
            "callbacks-error=",
            "destination=",
            "wait-for-sources",
            "dataset",
            "datasetversion",
            "tier0",
            "all",
            "version"
            ]
        )
    except getopt.GetoptError, e:
        usage()
        print str(e)
        print
        print "Invalid arguments!"
        print
        sys.exit(2)

    # basic arguments checking
    if argv[0] not in actions:
        if argv[0].lower() == "-v" or argv[0].lower() == "--version":

            date = "$Date: 2006/08/30 08:50:07 $"
            tag = "$Name: DQ2_0_2_BRANCH $"
            
            dq2_version = "DQ2 [%s] %s" % (
                tag[7:-2], # 
                date[7:-1] # DQ2 version date
            )
            print dq2_version
            sys.exit(0)
            
        else:
            print "Unknown command: %s" % argv[0]
            sys.exit(2)

    if not chkargs(argv[0], args):
        usage()
        print
        print "Invalid or missing arguments!"
        print
        sys.exit(2)

    version = 0
    complete = None
    poolfile = ''
    conffile = 'client_conf.py'
    page = 1
    rpp = 100
    
    sources_policy = 0
    sources = {}
    callbacks = {}
    destination = ''
    wait_for_sources = 0
    archived = None
    attributes = []

    for o, a in opts:
        if o == "-v":
            version = int(a)
        elif o == "-c":
            complete = LocationState.COMPLETE
        elif o == "-i":
            complete = LocationState.INCOMPLETE
        elif o == "-f":
            poolfile = a
        elif o == "-s":
            conffile = a
        elif o == "-a":
            archived = SubscriptionState.ARCHIVE
        elif o == "-u":
            archived = SubscriptionState.UNARCHIVE
        elif o == "-p":
            page = int(a)
        elif o == "-r":
            rpp = int(a)
        elif o == "--archived":
            archived=SubscriptionState.ARCHIVE
        elif o == "--no-complete-sources":
            print "Warning: --no-complete-sources is a deprecated option!"
        elif o == "--no-incomplete-sources":
            print "Warning: --no-incomplete-sources is a deprecated option!"
        elif o == "--complete-sources":
            sources_policy |= SourcesPolicy.COMPLETE_SOURCES
        elif o == "--incomplete-sources":
            sources_policy |= SourcesPolicy.INCOMPLETE_SOURCES
        elif o == "--close-sources":
            sources_policy |= SourcesPolicy.CLOSE_SOURCES
        elif o == "--all-sources":
            sources_policy |= SourcesPolicy.ALL_SOURCES
        elif o == "--sources":
            #
            # we support only LRC lookups on the cmd line tool for now
            #
            sources_policy |= SourcesPolicy.KNOWN_SOURCES
            srcs = a.split(',')
            for src in srcs:
                # TODO: must validate user entries somehow!
                sources[src] = { 'policy': SourceResolverPolicy.LRC_LOOKUP }
        elif o == "--monitor":
            # TODO: must validate user entries somehow!
            callbacks[CallbackType.MONITOR_SUBSCRIPTION] = a.split(',')
        elif o == "--callbacks-vuid-complete":
            # TODO: must validate user entries somehow!
            callbacks[CallbackType.FETCHER_VUID_COMPLETE] = a.split(',')
        elif o == "--callbacks-file-done":
            # TODO: must validate user entries somehow!
            callbacks[CallbackType.FILE_DONE] = a.split(',')
        elif o == "--callbacks-error":
            # TODO: must validate user entries somehow!
            callbacks[CallbackType.ERROR] = a.split(',')
        elif o == "--destination":
            # TODO: must validate user entries somehow!
            destination = a
        elif o == "--wait-for-sources":
            wait_for_sources = 1
        
        # metadata options
        elif o == "--all":
            
            attributes = Metadata.DATASET
            attributes += Metadata.DATASET_VERSION
            attributes += Metadata.TIER0
        
        elif o == "--dataset":
            
            attributes += Metadata.DATASET
        
        elif o == "--datasetversion":
            
            attributes += Metadata.DATASET_VERSION
        
        elif o == "--tier0":
            
            attributes += Metadata.TIER0
            
    
    try:
        client_conf = __import__(conffile[:-3])
    except ImportError:
        print 'Missing or bad configuration file!'
        sys.exit(1)
    
    # tests
    if argv[0] == 'unittest':
        from common.client.testcase import DQClientTestSuite
        DQClientTestSuite.main()
        sys.exit(0)

    if argv[0] == 'stresstest':
        from common.client import DQStressTest
        DQStressTest.runTest(client_conf, int(args[0]), int(args[1]), int(args[2]))
        sys.exit(0)
    
    try:
        dq = DQ2(con_url=client_conf.content['insecure'],
                 con_urlsec=client_conf.content['secure'],
                 loc_url=client_conf.location['insecure'],
                 loc_urlsec=client_conf.location['secure'],
                 rep_url=client_conf.repository['insecure'],
                 rep_urlsec=client_conf.repository['secure'],
                 sub_url=client_conf.subscription['insecure'],
                 sub_urlsec=client_conf.subscription['secure'],
                 mon_url=client_conf.monitor['insecure'],
                 mon_urlsec=client_conf.monitor['secure']
                 )
        
        out = ''
        
        if argv[0] == 'ping':
            """test client configurations and DDM server status"""
            configurations = dq.test_client_configurations()
            for eachConfiguration in configurations.keys():
                if not eachConfiguration == 'status':
                    print '%s : %s' % (eachConfiguration.ljust(17), configurations[eachConfiguration])

            ddm_server_status = ['Down!', 'Running']
            print '%s : %s' % ('DDM server status'.ljust(17), ddm_server_status[dq.is_ddm_server_alive()])
            import common.DQPing
            print '%s : %s' % ('Host status'.ljust(17), str(configurations['status']))
            sys.exit(0)
        
        
        # queries
        if argv[0] == 'listDatasetReplicas':
            ret = dq.listDatasetReplicas(args[0], version, complete)
            if len(ret) > 0:
                if complete is None or complete == LocationState.INCOMPLETE:
                    out += " INCOMPLETE: " % ()
                    sites = ret[args[0]]
                    for eachSite in sites[LocationState.INCOMPLETE]:
                        out += '%s,' % (eachSite)
                    out = out[0:(len(out)-1)]
                out += '\n'
                if complete is None or complete == LocationState.COMPLETE:
                    out += " COMPLETE: " % ()
                    if len(ret) > 0:
                        sites = ret[args[0]]
                    for eachSite in sites[LocationState.COMPLETE]:
                        out += '%s,' % (eachSite)
                    out = out[0:(len(out)-1)]
            
        elif argv[0] == 'listFileReplicas':
            ret = dq.listFileReplicas(args[0])
            sites = []
            for ds in ret:
                """get the sites where the dataset is complete => which, for sure, have the LFN"""
                for site in ret[ds][LocationState.COMPLETE]:
                    if site not in sites:
                        sites.append(site)
            for site in sites:
                out += site+'\n'
                    
        elif argv[0] == 'listDatasetsInSite':
            ret = dq.listDatasetsInSite(args[0], complete, page, rpp)
            for ds in ret:
                out += ds+'\n'
                    
        elif argv[0] == 'listSubscriptions':
            ret = dq.listSubscriptions(args[0], version=version, archived=archived)
            for site in ret:
                out += site + '\n'

        elif argv[0] == 'listSubscriptionInfo':
            ret = dq.listSubscriptionInfo(args[0], args[1], version=version, archived=archived)
            for attr in ret:
                out += '%s: ' % attr
                if attr == 'sourcesPolicy':
                    txt = ''
                    if int(ret[attr]) & SourcesPolicy.ALL_SOURCES:
                        txt += 'ALL_SOURCES '
                    if int(ret[attr]) & SourcesPolicy.KNOWN_SOURCES:
                        txt += 'KNOWN_SOURCES '
                    if int(ret[attr]) & SourcesPolicy.CLOSE_SOURCES:
                        txt += 'CLOSE_SOURCES '
                    if int(ret[attr]) & SourcesPolicy.COMPLETE_SOURCES:
                        txt += 'COMPLETE_SOURCES '
                    if int(ret[attr]) & SourcesPolicy.INCOMPLETE_SOURCES:
                        txt += 'INCOMPLETE_SOURCES '
                    out += '%s\n' % txt
                elif attr == 'sources':
                    for src in ret[attr]:
                        out += '%s ' % src
                    out += '\n'
                elif attr == 'waitForSources' or attr == 'archival':
                    out += '%s\n' % str(bool(ret[attr]))
                else:
                    out += '%s\n' % ret[attr]

        elif argv[0] == 'listSubscriptionsInSite':
            ret = dq.listSubscriptionsInSite(args[0], archived)
            dsets = []
            for ds in ret:
                if ret[ds]['dsn'] not in dsets:
                    dsets.append(ret[ds]['dsn'] )
            
            for dset in dsets:
                out += dset+'\n'
            
        elif argv[0] == 'listFilesInDataset':
            ret = dq.listFilesInDataset(args[0], version)
            tmp = {}
            for guid in ret:
                """inverting dictionary"""
                tmp[ret[guid]] = guid
            ret = tmp
            lfns = ret.keys()
            lfns.sort()
            for lfn in lfns:
                out += ret[lfn]+' '+ lfn +'\n'
                
        elif argv[0] == 'listDatasets':
            ret = dq.listDatasets(args[0], version)
            for ds in ret:
                out += ds+'\n'
        
        elif argv[0] == 'listDatasets':
            ret = dq.listDatasets(args[0], version)
            for ds in ret:
                out += ds+'\n'
                
        elif argv[0] == 'listDestinations':
            from common import TiersOfATLAS
            destinations = TiersOfATLAS.getAllDestinationSites()
            destinations.sort()
            for id in destinations:
                out += ' %s\n' % id
        
        elif argv[0] == 'listSources':
            from common import TiersOfATLAS
            sources = TiersOfATLAS.getAllSources()
            sources.sort()
            for id in sources:
                out += ' %s\n' % id
        
        # metadata
        elif argv[0] == 'listDatasetsByMetaData':
            atts = []#{}
            for i in range(0, len(args[1:]), 2):
                atts.append( {'n': args[i], 'v': args[1+i]} )
                #atts[args[i]] = args[1+i] use this once DQ2.py changed
            ret = dq.listDatasetsByMetaData(atts)
            for ds in ret:
                out += ds+'\n'
            
        elif argv[0] == 'listDatasetsByCreationDate':
            ret = dq.listDatasetsByCreationDate(float(args[0]))
            for ds in ret:
                out += ds+'\n'

        elif argv[0] == 'listMetaDataAttributes':
            ret = dq.listMetaDataAttributes()
            for at in ret:
                out += at+'\n'

        elif argv[0] == 'setMetaDataAttribute':
            dq.setMetaDataAttribute(args[0], args[1], args[2])
            
        elif argv[0] == 'getMetaDataAttribute' or argv[0] == 'getMetaData':
            
            for eachArg in args[1:]:
                attributes.append(eachArg)
            
            result = dq.getMetaDataAttribute(args[0], attributes, version=version)
            
            out += string.ljust('name', 19) +' : '+ str(args[0]) +'\n'
            
            keys = result.keys()
            keys.sort()
            
            for eachKey in keys:
                if eachKey == 'state':
                    result[eachKey] = DatasetState.DESCRIPTION[result[eachKey]]
                out += string.ljust(eachKey, 19) +' : '+ str(result[eachKey]) +'\n'
            
        elif argv[0] == 'getNumberOfFiles':
            out = dq.getNumberOfFiles(args[0])


        # adding
        elif argv[0] == 'registerNewDataset':
            if poolfile != '':
                lfns, guids = getFilesFromCatalog(poolfile)
                dq.registerNewDataset(args[0], lfns, guids)
            else:
                guids = []
                lfns = []
                for i in range(0, len(args[1:]), 2):
                    lfns.append(args[1+i])
                    guids.append(args[2+i])
                dq.registerNewDataset(args[0], lfns, guids)
                
        elif argv[0] == 'registerDatasetLocation':
            if complete is None:
                print "Missing dataset complete state!"
                usage()
                sys.exit(2)
            dq.registerDatasetLocation(args[0], args[1], version, complete)
            
        elif argv[0] == 'registerDatasetSubscription':
            if sources_policy == 0:
                """user didn't enter any sources policy then check COMPLETE and INCOMPLETE"""
                sources_policy = SourcesPolicy.COMPLETE_SOURCES | SourcesPolicy.INCOMPLETE_SOURCES
            
            if archived is None:
                archived = SubscriptionState.UNARCHIVE
            dq.registerDatasetSubscription(args[0], args[1], version,
                archived=archived, callbacks=callbacks,
                sources=sources, sources_policy=sources_policy,
                wait_for_sources=wait_for_sources,
                destination=destination)
        elif argv[0] == 'deleteFilesFromDataset':
            dq.deleteFilesFromDataset(args[0], args[1:])
        elif argv[0] == 'registerNewVersion':
            if poolfile != '':
                files = getFilesFromCatalog(poolfile)
                ret = dq.registerNewVersion(args[0], files)
            else:
                guids = []
                lfns = []
                for i in range(0, len(args[1:]), 2):
                    lfns.append(args[1+i])
                    guids.append(args[2+i])
                ret = dq.registerNewVersion(args[0], lfns, guids)
            out = 'Version %i open' % ret['version']

        elif argv[0] == 'registerFilesInDataset':
            if poolfile != '':
                files = getFilesFromCatalog(poolfile)
                ret = dq.registerFilesInDataset(args[0], files)
            else:
                guids = []
                lfns = []
                for i in range(0, len(args[1:]), 2):
                    lfns.append(args[1+i])
                    guids.append(args[2+i])
                ret = dq.registerFilesInDataset(args[0], lfns, guids)
            if len(ret) !=0:
                out = 'Warning, some files already in dataset: %s' % str(ret)
                
        # closing/freezing
        elif argv[0] == 'closeDataset':
            dq.closeDataset(args[0])
        elif argv[0] == 'freezeDataset':
            dq.freezeDataset(args[0])

        # deleting
        elif argv[0] == 'deleteDatasetSubscription':
            dq.deleteDatasetSubscription(args[0], args[1])
        elif argv[0] == 'deleteDatasetReplicas':
            dq.deleteDatasetReplicas(args[0], args[1:], version)
        elif argv[0] == 'eraseDataset':
            dq.eraseDataset(args[0])
        else:
            raise DQInvalidRequestException( "Unknown command: %s" % argv[0])

        if out != '':
            print out,
            
    except DQException, e:
        print "Error", e
    

if __name__ == '__main__':
    main(sys.argv[1:])


