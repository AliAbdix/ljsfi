"""
The main interface for users to perform operations involving multiple central catalogs.

$Id: DQ2.py,v 1.52.2.49 2006/09/07 15:49:05 psalgado Exp $


"""


import commands
import common.DQValidator
import common.DQPing

from common.DQException import *
from common.DQConstants import DatasetState, LocationState, Metadata, SourcesPolicy, SubscriptionArchivedState 
from content.client.ContentClient import ContentClient
from location.client.LocationClient import LocationClient
from monitor.catalogs.client.MonitorClient import MonitorClient
from repository.client.RepositoryClient import RepositoryClient
from subscription.client.SubscriptionClient import SubscriptionClient


def get_dict_item (dictionary, key):
    """
    """
    assert dictionary is not None
    assert type(dictionary) is dict
    assert key is not None
    
    for eachKey in dictionary.keys():
        """"""
        if eachKey.lower() == key.lower():
            return dictionary[eachKey]
    
    raise KeyError


class DQ2:
    """
    Class to make requests to central catalogs.
    (since 0.2.0)
    """


    def __init__ (self, con_url=None, con_urlsec=None, loc_url=None, loc_urlsec=None, rep_url=None, rep_urlsec=None, sub_url=None, sub_urlsec=None, mon_url=None, mon_urlsec=None, certificate=None):
        """
        Constructs an instance of DQ2.
        (since 0.2.0)
        
        con_url
        con_urlsec
        loc_url
        loc_urlsec
        rep_url
        rep_urlsec
        sub_url
        sub_urlsec
        mon_url
        mon_urlsec
        certificate is the proxy certificate.
        
        
        DQInvalidRequestException is raised,
        in case any given/configured url is not a string or if it
        doesn't match the regular expression (common.DQValidator.URL_REGEXP).
        """
        self.contentClient = ContentClient(con_url, con_urlsec, certificate=certificate)
        self.locationClient = LocationClient(loc_url, loc_urlsec, certificate=certificate)
        self.repositoryClient = RepositoryClient(rep_url, rep_urlsec, certificate=certificate)
        self.subscriptionClient = SubscriptionClient(sub_url, sub_urlsec, certificate=certificate)
        self.monitorClient = MonitorClient(mon_url, mon_urlsec, certificate=certificate)


    def __str__ (self):
        """
        Returns a string representation of this object.
        (since 0.2.1)
        """
        return """DQ2
        (
        content client      : %s
        location client     : %s
        repository client   : %s
        subscription client : %s
        )""" % (self.contentClient, self.locationClient, self.repositoryClient, self.subscriptionClient)


    def _generateUUID (self):
        """
        Generates a fixed 36 character unique identifier.
        (since 0.2.0)
        
        DQUnknownBackendException is raised,
        in case there is an error running uuidgen.
        """
        s,o = commands.getstatusoutput('uuidgen')
        if s != 0:
            raise DQUnknownBackendException('Failed running uuidgen to generate UUID')
        return string.lower(string.strip(o))


# PUBLIC methods


    def closeDataset (self, dsn):
        """
        Closes the latest dataset version.
        (since 0.2.0)
        
        dsn is the dataset name.
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQUnknownDatasetException is raised,
        in case the dataset name doesn't exist.
        DQClosedDatasetException is raised,
        in case the dataset version is already closed.
        DQFrozenDatasetException is raised,
        in case the dataset is frozen.
        DQSecurityException is raised,
        in case the given user cannot change the dataset version state.
        """
        
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.has_wildcard([dsn])
        self.repositoryClient.setState(dsn, DatasetState.CLOSED)
        
        dataset = self.repositoryClient.queryDatasetByName(dsn, 0)
        dataset = get_dict_item(dataset, dsn)
        
        # notify dataset changes
        self.subscriptionClient.markModified([dataset['duid'], dataset['vuids'][0]])


    def deleteDatasetReplicas (self, dsn, locations, version=0):
        """
        Delete the dataset replica from the given site. If it
        was the last replica, delete entries from the repository
        and content.
        (since 0.2.0)
        
        dsn is the dataset name.
        locations is a list with the dataset replica locations.
        version is the dataset version number.
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQUnknownDatasetException is raised,
        in case the dataset name doesn't exist.
        """
        
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.has_wildcard([dsn])
        common.DQValidator.checkArgsInt([version])
        common.DQValidator.is_list_of_sites(locations)
        
        dataset = self.repositoryClient.queryDatasetByName(dsn, version)
        
        if len(dataset) == 0:
            raise DQUnknownDatasetException([dsn, None, None, None])
        
        vuid = get_dict_item(dataset, dsn)['vuids'][0] # the latest version
        
        self.locationClient.deleteDatasetReplica(vuid, locations)


    def deleteDatasetSubscription (self, dsn, site):
        """
        Removes the dataset subscription of the given dataset name from the given site.
        The site will no longer receive updated versions of the dataset.
        (since 0.2.0)
        
        dsn is the dataset name.
        site is the subscription location.
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQUnknownDatasetException is raised,
        in case there is no dataset with the given name.
        """
        
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.has_wildcard([dsn])
        common.DQValidator.is_site(site)
        
        # may raise DQUnknownDatasetException
        duid = self.repositoryClient.resolveName(dsn)['duid']
        
        self.subscriptionClient.deleteDatasetSubscription(duid, site)


    def deleteDatasetSubscriptions (self, dsn):
        """
        Removes all dataset/dataset version subscriptions of the given dataset.
        (since 0.2.1)
        
        dsn is the dataset name.
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQUnknownDatasetException is raised,
        in case there is no dataset with the given name.
        """
        
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.has_wildcard([dsn])
        
         # may raise DQUnknownDatasetException
        duid = self.repositoryClient.resolveName(dsn)['duid']
        # {'dataset_nameA': ['A_vuid_for_version1+X', ..., 'A_vuid_for_version1']}
        dataset = self.repositoryClient.queryDatasetByName(dsn, -1)
        dataset = get_dict_item(result, dsn)
        
        duid_and_vuids = dataset['vuids']
        duid_and_vuids.append(dataset['duid'])
        self.subscriptionClient.deleteDatasetSubscriptions(duid_and_vuids)


    def deleteDatasetVersionSubscriptions (self, dsn, version):
        """
        Removes all subscriptions of the given dataset version.
        (since 0.2.1)
        
        dsn is the dataset name.
        version is the dataset version number
        (
        0 only of the latest version,
        -1 all dataset versions - NOT of the duid -,
        >0 only of the specific version
        ).
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQUnknownDatasetException is raised,
        in case there is no dataset with the given name.
        """
        
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.has_wildcard([dsn])
        common.DQValidator.checkArgsStr([version])
        
        # {'dataset_nameA': ['A_vuid_for_versionX']}
        dataset = self.repositoryClient.queryDatasetByName(dsn, version)
        
        if not len(dataset) > 0:
            raise DQUnknownDatasetException([dsn, None, None, None])
        
        # vuids will always be a list
        vuid = get_dict_item(dataset, dsn)['vuids'][0]
        self.subscriptionClient.deleteDatasetSubscriptions(vuid)


    def deleteFilesFromDataset (self, dsn, guids=[]):
        """
        Removes files from an existing dataset.
        (since 0.2.1)
        
        dsn is the dataset name.
        guids is a list of file unique identifiers (GUID).
        Note: the GUID is typically assigned by external tools
        (e.g. POOL) and must be passed along as is.
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQClosedDatasetException is raised,
        in case the dataset version is closed.
        DQFrozenDatasetException is raised,
        in case the dataset is frozen.
        
        Returns the list of lfns that failed to be added since they are duplicates?
        """
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.has_wildcard([dsn])
        common.DQValidator.is_list_of_uids(guids)
        
        st = self.repositoryClient.getState(dsn)
        
        # is closed!
        if st == DatasetState.CLOSED:
            raise DQClosedDatasetException(dsn)
        elif st == DatasetState.FROZEN:
            raise DQFrozenDatasetException(dsn)
        
        dataset = self.repositoryClient.queryDatasetByName(dsn, 0)
        
        vuid = get_dict_item(dataset, dsn)['vuids'][0] # latest version in on index 0
        
        newvuid = self._generateUUID()
        # ... content catalog must copy all files into a new version
        # except the given LFNs and GUIDs
        out = self.contentClient.deleteFilesFromDataset(vuid, guids, newvuid)
        #nofiles = int(self.repositoryClient.getMetaDataAttribute(dsn, 'numberfiles'))
        
        # update no of files in repository
        # above call returns non unique files added
        #filesdeleted = nofiles - len(out)
        
        # NO FILES WERE DELETED => BAD LUCK!
        #if filesdeleted == 0:
        #    raise DQInvalidRequestException('Error. No new content was deleted, all files already didn\'t exist in dataset!')
        
        self.repositoryClient.updateVersion(dsn, newvuid)
        
        return newvuid


    def eraseDataset (self, dsn):
        """
        Delete all trace of all dataset versions in all the catalogs.
        DANGEROUS!!!
        (since 0.2.0)
        
        dsn is the dataset name (can be used with wildcard).
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQInvalidRequestException is raised,
        in case the dataset name has wildcards.
        Raises DQSecurityException,
        in case the user has no permissions to delete the dataset.
        DQUnknownDatasetException is raised,
        in case the dataset name doesn't exist.
        
        """
        
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.has_wildcard([dsn])
        
        if dsn.find('*') != -1:
            # too dangerous to allow wildcards.
            # Comment this line out if we really want them
            raise DQInvalidRequestException('Wildcards are not supported in this operation!')
        
        #{'dataset_nameA': ['A_vuid_for_version1+X', ..., 'A_vuid_for_version1'], 'dataset_nameB': ['B_vuid_for_version1']}, where X > 0
        datasets = self.repositoryClient.queryDatasetByName(dsn)
        
        if len(datasets) == 0:
            raise DQUnknownDatasetException([dsn, None, None, None])
        
        # removing dataset one by one
        
        for dsname in datasets.keys():
            
            # get all dataset versions
            duid = get_dict_item(datasets, dsname)['duid']
            vuids = get_dict_item(datasets, dsname)['vuids']
            
            self.repositoryClient.deleteDataset(dsname)
            # delete the contents of each vuid
            for vuid in vuids:
                self.contentClient.deleteDataset(vuid)
            
            # delete all replicas from location catalog
            for vuid in vuids:
                self.locationClient.deleteDataset(vuid)
            
            # delete all subscriptions
            uids = vuids
            uids.append(duid)
            
            self.subscriptionClient.deleteDatasetSubscriptions(uids)
        
        return


    def freezeDataset (self, dsn):
        """
        Freezes a dataset.
        (since 0.2.0)
        
        dsn is the dataset name.
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQFrozenDatasetException is raised,
        in case the user is trying to freeze an already frozen dataset.
        DQInvalidRequestException is raised,
        in case the given lfns and guids are not the same length.
        DQSecurityException is raised,
        in case the given user cannot change the dataset version state.
        DQUnknownDatasetException is raised,
        in case there is no dataset with the given name.
        """
        
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.has_wildcard([dsn])
        
        self.repositoryClient.setState(dsn, DatasetState.FROZEN)
        
        dataset = self.repositoryClient.queryDatasetByName(dsn, 0)
        dataset = get_dict_item(dataset, dsn)
        
        # notify dataset changes
        self.subscriptionClient.markModified([dataset['duid'], dataset['vuids'][0]])


    def getMetaDataAttribute (self, dsn, attributes, version=0):
        """
        Get the metadata information for the given dataset/dataset version.
        (since 0.2.0)
        
        dsn is the dataset name.
        attributes is a list of dataset metadata attributes.
        version is the dataset version (0 is the latest).
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQInvalidRequestException is raised,
        in case of an invalid attribute name.
        DQUnknownDatasetException is raised,
        in case there is no dataset with the given name.
        
        Returns a string representation of the attribute value.
        '<attribute_value>'
        """
        
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.has_wildcard([dsn])
        common.DQValidator.is_list_of_metadata_attributes(attributes)
        common.DQValidator.checkArgsInt([version])
        
        if version < 0:
            version = 0
        
        
        output = {}
        fetchDatasetMetadata = False
        fetchDatasetVersionMetadata = False
        
        
        for eachAttribute in attributes:
            if not fetchDatasetMetadata and eachAttribute in Metadata.DATASET:
                fetchDatasetMetadata = True
            elif not fetchDatasetVersionMetadata and eachAttribute in Metadata.DATASET_VERSION:
                fetchDatasetVersionMetadata = True
            elif eachAttribute in Metadata.TIER0:
                """eachAttribute is a Tier0 metadata attribute"""
                output[eachAttribute] = self.repositoryClient.getMetaDataAttribute(dsn, eachAttribute)
        
        #print fetchDatasetMetadata
        #print fetchDatasetVersionMetadata
        
        if fetchDatasetMetadata:
            """retrieving dataset metadata"""
            
            # {'dataset_nameA': {'duid': duid, 'vuids': []}
            dataset_info = self.repositoryClient.queryDatasetByName(dsn, version=-1)
            if len(dataset_info) <= 0:
                """no dataset found"""
                raise DQUnknownDatasetException((dsn, '', '', ''))
            
            dataset_info = get_dict_item(dataset_info, dsn)
            
            if 'duid' in attributes:
                output['duid'] = dataset_info['duid']
            if 'latestvuid' in attributes:
                output['latestvuid'] = dataset_info['vuids'][0]
            if 'latestversion' in attributes:
                output['latestversion'] = len(dataset_info['vuids'])
            
            if 'creationdate' in attributes or 'state' in attributes or 'owner' in attributes:
                
                vuid_1 = dataset_info['vuids'][-1]
                #{'uid': {'vuid','duid','version','cdate','state','dsn','owner'}}
                dataset_version_1 = self.repositoryClient.resolveUIDs([vuid_1]) # 1st version
                dataset_version_1 = dataset_version_1[vuid_1]
                
                if 'creationdate' in attributes:
                    output['creationdate'] = dataset_version_1['cdate']
                if 'state' in attributes:
                    output['state'] = dataset_version_1['state']
                if 'owner' in attributes:
                    output['owner'] = dataset_version_1['owner']
            
            if 'numberfiles' in attributes:
                output['numberfiles'] = self.getNumberOfFiles(dsn, 0)
        
        if fetchDatasetVersionMetadata:
            """retrieving dataset version metadata"""
            
            if 'vuid' in attributes or 'version' in attributes or 'versioncreationdate' in attributes:
                # {'dataset_nameA': {'duid': duid, 'vuids': []}
                dataset_version = self.repositoryClient.queryDatasetByName(dsn, version) # get all versions
                
                if len(dataset_version) <= 0:
                    """given dataset version not found"""
                    raise DQUnknownDatasetException((dsn, version, '', ''))
                
                dataset = get_dict_item(dataset_version, dsn) 
                vuid_version = dataset['vuids'][0] # only the given version is in vuids
                
                if 'vuid' in attributes:
                    output['vuid'] = vuid_version
                if 'version' or 'versioncreationdate':
                    
                    #{'uid': {'vuid','duid','version','cdate','state','dsn','owner'}}
                    dataset_version = self.repositoryClient.resolveUIDs([vuid_version]) # requested version
                    dataset_version = dataset_version[vuid_version]
                    
                    if 'version' in attributes:
                        output['version'] = dataset_version['version']
                    if 'versioncreationdate' in attributes:
                        output['versioncreationdate'] = dataset_version['cdate']
            
            if 'versionnumberfiles' in attributes:
                output['versionnumberfiles'] = self.getNumberOfFiles(dsn, version)
        
        return output


    def getNumberOfFiles (self, dsn, version=0):
        """
        Returns the number of files in the given dataset (or dataversion)
        (since 0.2.5)
        
        dsn is the dataset name.
        version is the dataset version number (0 => the latest version).
        
        """
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.has_wildcard([dsn])
        common.DQValidator.checkArgsInt([version])
        
        return len(self.listFilesInDataset(dsn, version))


    def is_ddm_server_alive (self):
        """
        Returns the status of the DDM server.
        (True: DDM server is running, False: DDM server is down)
        (since 0.2.1)
        """
        if self.monitorClient.is_ddm_server_alive() == 'isAlive=yes':
            return True
        return False


    def listDatasetReplicas (self, dsn, version=0, complete=None):
        """
        (since 0.2.0)
        
        dsn is the dataset name.
        version is the dataset version number.
        complete is the location state of the dataset at a site and may have
        the following values: None: in which case the
        location state is ignore; LocationState.COMPLETE: lists only datasets
        fully present at the site (no files missing);
        LocationState.INCOMPLETE: lists only datasets partially present at the
        site (some files missing).
        
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs. 
        DQUnknownDatasetException is raised,
        in case there is no dataset with the given name.
        
        Returns a list of locations.
        {'dsn_A': ['site_A', ..., 'site_B'], 'dsn_B': [...]}
        """
        
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.has_wildcard([dsn])
        common.DQValidator.checkArgsInt([version])
        if complete is not None:
            common.DQValidator.is_location_state(complete)
        
        dataset = self.repositoryClient.queryDatasetByName(dsn, version)
        
        if len(dataset) == 0:
            raise DQUnknownDatasetException([dsn, None, None, None])
        
        vuid = get_dict_item(dataset, dsn)['vuids'][0] # the latest version
        
        return self.locationClient.queryDatasetLocations(vuids=[vuid], complete=complete)


    def listDatasets (self, dsn, version=0):
        """
        Used to return a list of datasets matching the given
        pattern and version.
        
        dsn is the dataset name.
        version is the dataset version number.
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        
        usage:
        listDatasets('myname') - returns all versions of the given dataset
        listDatasets('myname*') - returns all versions of the datasets that start by 'myname'.
        listDatasets('*myname') - returns all versions of the datasets that end by 'myname'.
        
        listDatasets('myname', 2) - returns the version 2 of dataset 'myname'.
        listDatasets('myname', 0) - returns the latest version of the dataset 'myname'.
        listDatasets('myname', <0) - returns all the versions of the dataset 'myname'.
        listDatasets('myname', ]-infinite, 0[) - returns all the versions of the dataset 'myname'.
        
        listDatasets('myname*', 2) - returns the version 2 of the datasets that start by 'myname'.
        listDatasets('*myname', None) - returns all the versions of the datasets that end with 'myname'.
        
        Returns a dictionary containing the dataset versions information.
        {
            'dataset_nameA': {'duid': duid, 'vuids': ['A_vuid_for_version1+X', ..., 'A_vuid_for_version1']}
            'dataset_nameB': {'duid': duid, 'vuids': ['B_vuid_for_version1']}
        }, where X > 0
        """
        
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.checkArgsInt([version])
        
        return self.repositoryClient.queryDatasetByName(dsn, version)


    def listDatasetsByCreationDate (self, days):
        """
        Returns a dictionary mapping names to last created vuids between [now-<days>, now+<days>].
        (since 0.2.0)
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        
        Returns a dictionary containing the dataset versions information.
        {
            'dataset_nameA': ['A_vuid_for_version1+X', ..., 'A_vuid_for_version1']
            'dataset_nameB': ['B_vuid_for_version1']
        }, where X > 0
        """
        
        common.DQValidator.is_number([days])
        return self.repositoryClient.queryDatasetByCreationDate(days)


    def listDatasetsByMetaData (self, query):
        """
        query the metadata search criteria ({'n': a, 'v': b}).
        (since 0.2.0)
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        
        Return value is a list of tuples with (dataset name, version).
        [
            ('dataset_name_1', 'vuid_1'),
            (...),
            ('dataset_name_N', 'vuid_N')
        ]
        """
        
        common.DQValidator.is_dictionary([query])
        
        for eachAttribute in query.keys():
            common.DQValidator.is_metadata.attribute(eachAttribute)
        for eachValue in query.values():
            common.DQValidator.is_metadata.value(eachValue)
        
        return self.repositoryClient.queryDatasetByMetaData(query)


    def listDatasetsInSite (self, site, complete=None, page=1, rpp=100):
        """
        List all the datasets and their versions available on
        the given site.
        (since 0.2.0)
        
        site is the location to be searched for.
        complete is the location state of the dataset at a site and may have
        the following values: None: in which case the
        location state is ignore; LocationState.COMPLETE: lists only datasets
        fully present at the site (no files missing);
        LocationState.INCOMPLETE: lists only datasets partially present at the
        site (some files missing).
        
        page is the page to be displayed.
        rpp are the results per page.
        
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        
        Returns a list of dataset versions.
        {'dsn': ['vuid_1', ... 'vuid_N']}
        """
        
        common.DQValidator.is_site(site)
        if complete is not None:
            common.DQValidator.is_location_state(complete)
        common.DQValidator.checkArgsInt([page, rpp])
        
        if page <= 0:
            page = 1
        if rpp <= 0:
            rpp = 1
        
        # get the vuids from the LocationCatalog
        
        return self.locationClient.queryDatasetsInSite(site, complete, page, rpp)


    def listFileReplicas (self, lfn):
        """
        Gives the locations of the given LFN.
        This is an expensive operation, requiring a lookup
        over a metadata attribute in the content catalog.
        (since 0.2.0)
        
        lfn is the logical filename (LFN).
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        
        Returns ... TODO
        """
        
        common.DQValidator.is_lfn(lfn)
        
        # look up content cat to get the dataset(s) containing the lfn => vuids
        datasets = self.contentClient.queryDatasetsWithFileByLFN(lfn)
        
        # now look up location cat to find where they are (complete ds only)
        if len(datasets) != 0:
            return self.locationClient.queryDatasetLocations(datasets, complete=LocationState.COMPLETE)
        else:
            return {}


    def listFilesInDataset (self, dsn, version=0):
        """
        Given a dataset name, and optional version, the guids
        and lfns of the files in the dataset are returned.
        (since 0.2.0)
        
        dsn is the dataset name.
        version is the dataset version number (0 => the latest version).
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQUnknownDatasetException is raised,
        in case there is no dataset with the given name.
        """
        
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.has_wildcard([dsn])
        common.DQValidator.checkArgsInt([version])
        
        # get the vuid
        dataset = self.repositoryClient.queryDatasetByName(dsn, version)
        
        if len(dataset) == 0:
            raise DQUnknownDatasetException([dsn, None, None, None])
        
        vuid = get_dict_item(dataset, dsn)['vuids'][0] # get the latest version
        
        # get the list of files
        return self.contentClient.queryFilesInDataset(vuid)


    def listMetaDataAttributes (self):
        """
        Returns a list containing all metadata attributes.
        (since 0.2.0)
        """
        return Metadata.DATASET + Metadata.DATASET_VERSION + Metadata.TIER0


    def listSubscriptionInfo (self, dsn, site, version=None, archived=None):
        """
        Return a list attributes of the subscription of the dataset to
        the given site.
        
        (since 0.2.11)
        
        dsn is the dataset name.
        site is the location the dataset is subscribed to.
        version is the dataset version number (0 is the latest).
        archived is the dataset subscription state.
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        
        Returns a dictionary containing all information on the subscription.
        """
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.has_wildcard([dsn])
        common.DQValidator.checkArgsInt([version])
        common.DQValidator.is_destination(site)
        if archived is not None:
            common.DQValidator.is_subscription_state(archived)
        
        if version is not None and version > 0:
            """querying by vuid"""
            result = self.repositoryClient.queryDatasetByName(dsn, version)
            uid = get_dict_item(result, dsn)['vuids'][0]
        else:
            """querying by duid"""
            uid = self.repositoryClient.resolveName(dsn)['duid']

        sites = self.subscriptionClient.queryDatasetSubscriptions(uid, archived)

        if site.upper() not in sites:
            raise DQUnknownSubscriptionException([dsn, site])
        return get_dict_item(sites, site)


    def listSubscriptions (self, dsn, version=None, archived=None):
        """
        Return a list of sites that have subscribed the given dataset.
        
        (since 0.2.11)
        
        dsn is the dataset name.
        version is the dataset version number (0 is the latest).
        archived is the dataset subscription state.
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        
        Returns a list containing the sites that subscribed, at least, a version of the dataset.
        """
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.has_wildcard([dsn])
        if version is not None:
            common.DQValidator.checkArgsInt([version])
        if archived is not None:
            common.DQValidator.is_subscription_state(archived)
        
        if version is not None and version > 0:
            """querying by vuid"""
            result = self.repositoryClient.queryDatasetByName(dsn, version)
            uid = get_dict_item(result, dsn)['vuids'][0]
        else:
            """querying by duid"""
            uid = self.repositoryClient.resolveName(dsn)['duid']
        
        return self.subscriptionClient.queryDatasetSubscriptions(uid, archived).keys()


    def listSubscriptionsInSite (self, site, archived=None):
        """
        Return a dict of {subscription: site} of subscriptions
        registered in the given site.
        (since 0.2.0)
        
        site is the dataset subscription location.
        archived is the dataset subscription state.
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        
        Returns a list containing the subscribed datasets or dataset versions.
        {
            'uid': {
                'sources': ...,
                'archival': ...,
                'waitForSources': ...,
                'sourcesPolicy': ...,
                'callbacks': ...
            }
        }
        """
        
        common.DQValidator.is_destination(site)
        if archived is not None:
            common.DQValidator.is_subscription_state(archived)
        
        return self.subscriptionClient.querySubscriptionsInSite(site, archived)


    def registerDatasetLocation (self, dsn, location, version=0, complete=LocationState.INCOMPLETE):
        """
        Register new location of a dataset (which must already
        be defined in the repository).
        (since 0.2.0)
        
        dsn is the dataset name.
        location is the dataset location.
        version is the dataset version number.
        complete is the location state of the dataset at a site and may have
        the following values: None: in which case the
        location state is ignore; LocationState.COMPLETE: lists only datasets
        fully present at the site (no files missing);
        LocationState.INCOMPLETE: lists only datasets partially present at the
        site (some files missing).
        
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQOpenedDatasetException is raised,
        in case of a opened dataset.
        DQLocationExistsException is raised,
        in case a dataset version replica exists at the given location.
        DQUnknownDatasetException is raised,
        in case there is no dataset with the given name.
        
        Nothing is returned.
        """
        
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.has_wildcard([dsn])
        common.DQValidator.is_site(location)
        common.DQValidator.is_location_state(complete)
        common.DQValidator.checkArgsInt([version])
        
        dataset = self.repositoryClient.queryDatasetByName(dsn, version)
        
        if len(dataset) == 0:
            raise DQUnknownDatasetVersionException(dsn, version)
        
        vuid = get_dict_item(dataset, dsn)['vuids'][0] # the latest/given version
        dsn = dataset.keys()[0]
        
        # if asked to mark as complete
        if complete == LocationState.COMPLETE:
            # make sure dataset is closed
            st = self.repositoryClient.getState(dsn)
            
            # is not closed!
            if st == DatasetState.OPEN:
                raise DQOpenedDatasetException(dsn)
        
        self.locationClient.addDatasetReplica(vuid, location, dsn, complete)


    def registerDatasetSubscription (self, dsn, location, version=0,
            archived=SubscriptionArchivedState.UNARCHIVE, callbacks={},
            sources={},
            sources_policy=(SourcesPolicy.KNOWN_SOURCES | SourcesPolicy.COMPLETE_SOURCES | SourcesPolicy.INCOMPLETE_SOURCES),
            wait_for_sources=0, destination=''):
        """
        Register a new subscription in the location catalog. If the
        version is not specified a duid is used.
        (since 0.2.0)
        
        'dsn' is the dataset name.
        'location' is the location where the dataset should be subscribed.
        'version' is the dataset version number.
        'archived' is the dataset archival state for the destination
        'callbacks' is a dictionary which specifies, per subscription callback
        state (see common.DQConstants.CallbackType),
        the list of HTTP URLs that should be triggered when the event occurs.
        e.g.
            from common.DQConstants import CallbackType
            callbacks = {
                CallbackType.FETCHER_VUID_COMPLETE:
                    ['https://some.host/service/to/notify'],
                CallbackType.MONITOR_SUBSCRIPTION:
                    ['mail:miguel.branco@cern.ch'],
                CallbackType.FILE_DONE:
                    ['http://some.host/service/to/notify']
                CallbackType.ERROR:
                    ['http://some.host/service/to/notify']
            }
        
        'archived' is the subscription state
        (see common.DQConstants.SubscriptionArchivedState).
        is a bit indicating the archival bit for the subscription.
        Archival subscriptions are never deleted by the cache turnover
        service, while non-archival data may be deleted if the destination
        storage becomes full at some point. Possible values are:
          SubscriptionArchivedState.ARCHIVE
          SubscriptionArchivedState.UNARCHIVE.
        
        'sources' is a dictionary indicating known sources for the
        subscription and the strategy to look them up: either by doing a LRC
        lookup at the source, or by directly specifying a URL, e.g.:
            sources = {
                'CERN'  : { 'policy': SourceResolverPolicy.LRC_LOOKUP },
                'RAL'   : { 'policy' : SourceResolverPolicy.RELATIVE_SURL,
                'rsurl' : 'srm://ral.uk/some/data/here/' }
            }
        Possible values for 'policy' are:
          SourceResolverPolicy.LRC_LOOKUP
          SourceResolverPolicy.RELATIVE_SURL (requires additionally 'rsurl')
        
        'sources_policy' triggers the subscription services to change the
        strategy used for finding source replicas.
        (see common.DQConstants.SourcesPolicy)
        Possible values are:
          ALL_SOURCES
          KNOWN_SOURCES
          CLOSE_SOURCES
          COMPLETE_SOURCES
          INCOMPLETE_SOURCES
        KNOWN_SOURCES is required if 'sources' is specified as part of the subscription.
        Values ar cumulative: e.g.
        source_policy=SourcesPolicy.KNOWN_SOURCES | SourcesPolicy.COMPLETE_SOURCES
        will look for sources in the sites specified as part of the 'sources' field
        in the subscription, as well as in all sites known to have complete
        copies of the dataset.
        
        'wait_for_sources' is a bit (True/False) indicating whether the subscription services
        should keep retrying to fulfill the subscription even if the sources files are missing.
        If True, subscription will not go to HOLD states even if sources are missing.
        
        'destination' is a relative SURL where the destination files should be
        placed within the destination storage (e.g. '/my/path/').
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQSubscriptionExistsException is raised,
        in case there is a subscription for this uid-location.
        DQUnknownDatasetException is raised,
        in case the given dataset name doesn't exist.
        DQUnknownDatasetVersionException is raised,
        in case the given version number doesn't exist for the given dataset.
        
        Nothing is returned.
        """
        
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.has_wildcard([dsn])
        common.DQValidator.is_destination(location)
        common.DQValidator.checkArgsInt([version])
        common.DQValidator.is_subscription_state(archived)
        for eachSource in sources.keys():
            common.DQValidator.is_source(eachSource)
        
        uid = None
        # get the required vuid or duid => register the duid
        if version == 0:
            """registering version 0 is the same as registering the dataset (uid=duid)."""
            # if dataset doesn't exist it will throw a DQUnknownDatasetException
            duid = self.repositoryClient.resolveName(dsn)['duid']
            uid = duid
            
        else:
            """registering a specific dataset version (uid=vuid)."""
            dataset = self.repositoryClient.queryDatasetByName(dsn, version)
            
            if len(dataset) == 0:
                """
                if dataset doesn't exist resolveName will throw a DQUnknownDatasetException
                if not then the dataset exists but the given version no => DQUnknowDatasetVersionException
                """
                self.repositoryClient.resolveName(dsn)
                raise DQUnknownDatasetVersionException(dsn, version)
            
            uid = get_dict_item(dataset, dsn)['vuids'][0]
        
        
        # register in subscription catalog
        self.subscriptionClient.addDatasetSubscription(
            uid, dsn, location, archived=archived, callbacks=callbacks, sources=sources, sources_policy=sources_policy, wait_for_sources=wait_for_sources, destination=destination
        )


    def registerFilesInDataset (self, dsn, lfns=[], guids=[]):
        """
        Add files to an existing dataset.
        (since 0.2.0)
        
        dsn is the dataset name.
        lfns is a list of logical filenames (LFN).
        guids is a list of file unique identifiers (GUID).
        Note: the GUID is typically assigned by external tools
        (e.g. POOL) and must be passed along as is.
        
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQClosedDatasetException is raised,
        in case the dataset version is closed.
        DQFrozenDatasetException is raised,
        in case the dataset is frozen.
        DQInvalidRequestException is raised,
        in case no files were added.
        
        Returns the list of lfns that failed to be added since they are duplicates.
        """
        
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.has_wildcard([dsn])
        common.DQValidator.is_list_of_uids(guids)
        common.DQValidator.is_list_of_lfns(lfns)
        
        st = self.repositoryClient.getState(dsn)
        
        # is closed!
        if st == DatasetState.CLOSED:
            raise DQClosedDatasetException(dsn)
        elif st == DatasetState.FROZEN:
            raise DQFrozenDatasetException(dsn)
        
        dataset = self.repositoryClient.queryDatasetByName(dsn, 0)
        dataset = get_dict_item(dataset, dsn)
        
        duid = dataset['duid']
        vuid = dataset['vuids'][0] # latest version in on index 0
        
        #nofiles = self.getNumberOfFiles()
        
        # add to content cat
        out = self.contentClient.addFilesToDataset(vuid, lfns, guids)
        
        # update no of files in repository
        # above call returns non unique files added
        filesadded = len(lfns)-len(out)
        
        if filesadded == 0:
            raise DQInvalidRequestException('Error. No new content to be added, all files already exist in dataset!')
        
        #nofiles += filesadded
        #self.repositoryClient.setMetaDataAttribute(vuid, 'numberfiles', str(nofiles))
        
        
        # notify dataset changes
        self.subscriptionClient.markModified([vuid, duid])
        
        return out


    def registerNewDataset (self, dsn, lfns=[], guids=[]):
        """
        Register a brand new dataset and associated files (lists of lfns and guids).
        (since 0.2.0)
        
        dsn is the dataset name.
        lfns is a list of logical filenames (LFN).
        guids is a list of file unique identifiers (GUID).
        Note: the GUID is typically assigned by external tools
        (e.g. POOL) and must be passed along as is.
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQDatasetExistsException is raised,
        in case there is a dataset with the given name.
        
        Returns a dictionary containing the dataset duid, vuid and version information.
        {'duid': '...', 'vuid': '...', 'version': ...}
        """
        
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.has_wildcard([dsn])
        common.DQValidator.is_list_of_uids(guids)
        common.DQValidator.is_list_of_lfns(lfns)
        
        if not len(lfns) == len(guids):
            raise DQInvalidRequestException('lfns and guids lists must be the same length')
        
        # add to repository and obtain vuid ({'vuid', 'version'})
        vuid = self.repositoryClient.addDataset(dsn)
        
        # add to content cat
        if len(lfns) > 0:
            # if repository doesn't send a DQDatasetExistsException then content shouldn't
            self.contentClient.addDataset(vuid['vuid'], lfns, guids)
        return vuid


    def registerNewVersion (self, dsn, lfns=[], guids=[]):
        """
        Register a new version of the dataset with the
        given additional files (lists of lfns and guids).
        Plus, it notifies the subscription catalog for changes
        on the dataset and on dataset previous version.
        (since 0.2.0)
        
        dsn is the dataset name.
        lfns are a list of logical filenames (LFN).
        guids...
        
        DQContentAlreadyExists is raised,
        in case all given files already exist in the dataset.
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQInvalidRequestException is raised,
        in case no files have been added to the content catalog.
        DQSecurityException is raised,
        in case the user has no permissions to update the dataset.
        DQUnknownDatasetException is raised,
        in case there is no dataset with the given name.
        
        Returns a dictionary containing the dataset version information.
        {'vuid': vuid_1, 'version': 1, 'duid': duid}
        """
        
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.has_wildcard([dsn])
        common.DQValidator.is_list_of_uids(guids)
        common.DQValidator.is_list_of_lfns(lfns)
        
        if len(lfns) != len(guids):
            raise DQInvalidRequestException('lfns and guids lists must be the same length')
        
        
        dataset = self.repositoryClient.queryDatasetByName(dsn, 0) # returns the latest version
        
        if len(dataset) == 0:
            raise DQUnknownDatasetException([dsn, None, None, None])
        
        vuid = get_dict_item(dataset, dsn)['vuids'][0] # just the vuid
        
        # get the files in the old version
        oldfiles = self.contentClient.queryFilesInDataset(vuid)
        oldguids = oldfiles.keys()
        oldlfns = oldfiles.values()
        
        nold = 0 # keep number of files already on dataset
        
        for guid in oldguids:
            if guid in guids:
                #print 'Warning: repeated file: '+oldfiles[guid]
                nold += 1
            else:
                lfns.append(oldfiles[guid])
                guids.append(guid)
        
        if len(lfns) > 0 and nold == len(lfns):
            raise DQContentAlreadyExists(dsn)
        
        
        newvuid = self._generateUUID()
        newvuid_dict = self.repositoryClient.updateVersion(dsn, newvuid)
        
        # register the new vuid with the old and new files
        newversion = newvuid_dict['version']
        
        if len(lfns) > 0:
            self.contentClient.addDataset(newvuid, lfns, guids)
        
        # notify dataset changes
        duid = newvuid_dict['duid']
        self.subscriptionClient.markModified([vuid, duid])
        
        return newvuid_dict


    def setMetaDataAttribute (self, dsn, attrname, attrvalue):
        """
        Set the value of the given attribute to the given
        value for the given dataset. Operates on the current version.
        (since 0.2.0)
        
        dsn is the dataset name.
        attrname is the metadata dataset attribute name.
        attrvalue is the metadata dataset attribute value.
        
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQSecurityException is raised,
        in case the user has no permissions to set metadata attributes on the dataset.
        DQInvalidRequestException is raised,
        in case of an invalid attribute name.
        DQUnknownDatasetException is raised,
        in case there is no dataset with the given name.
        """
        
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.has_wildcard([dsn])
        common.DQValidator.is_tier0_metadata_attribute(attrname)
        common.DQValidator.is_metadata_value(attrvalue)
        
        # we have to set this from within DQ2, but shouldn't
        # allow users to do it themselves
        
        return self.repositoryClient.setMetaDataAttribute(dsn, attrname, attrvalue)


    def test_client_configurations (self):
        """
        Checks if the DQ2 clients are well configured.
        (since 0.2.1)
        
        clients are the DQ2 clients to be tested.
        
        DQInvalidConfigurationException is raised,
        in case a configured host is not responding or if it is an unknown host.
        
        Returns a dictionary containing the client's configuration settings.
        {
            'content'      : (url_insecure, url_secure),
            'location'     : (url_insecure, url_secure),
            'monitor'      : (url_insecure, url_secure),
            'repository'   : (url_insecure, url_secure),
            'subscription' : (url_insecure, url_secure)
        }
        """
        clients = [
            self.contentClient,
            self.locationClient,
            self.monitorClient,
            self.repositoryClient,
            self.subscriptionClient
        ]
        
        hosts = []
        for eachClient in clients:
            """for each client check its insecure and secure hosts."""
            
            pinglist = []
            for eachHost in eachClient._get_hosts():
                if not eachHost in hosts:
                    hosts.append(eachHost)
        
        status = common.DQPing.pings(hosts, user_friendly=True)
        
        # NOTE: the auto_configure gives the client_conf's configuration settings
        # not the user given configuration settings.
        result = {
            'content'      : (
                self.contentClient.url,
                self.contentClient.url_secure
            ),
            'location'     : (
                self.locationClient.url,
                self.locationClient.url_secure
            ),
            'monitor'      : (
                self.monitorClient.url,
                self.monitorClient.url_secure
            ),
            'repository'   : (
                self.repositoryClient.url,
                self.repositoryClient.url_secure
            ),
            'subscription' : (
                self.subscriptionClient.url,
                self.subscriptionClient.url_secure
            ),
            'status'       : status
        }
        return result
