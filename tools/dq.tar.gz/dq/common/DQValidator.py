"""
DQ2 common methods.
"""


import re
import string
import common.TiersOfATLAS

from common.DQConstants import DatasetState, LocationState, Metadata, SourcesPolicy, SubscriptionModifiedState, SubscriptionArchivedState
from common.DQException import DQInvalidRequestException

DATASET_LOCATION_MAXLENGTH = 50
DATASET_NAME_MAXLENGTH = 255
LFN_MAXLENGTH = 255
METADATA_VALUE_MAXLENGTH = 10
SITE_MAXLENGTH = 50
UID_MAXLENGTH = 36
UID_REGEXP = '^\w{8}-\w{4}-\w{4}-\w{4}-\w{12}$'
UID_COMPILED_REGEXP = re.compile(UID_REGEXP)
URL_REGEXP = '^http(s)?://[^ ]+(:\d{1,4})?(/)?$'
URL_COMPILED_REGEXP = re.compile(URL_REGEXP)


def has_slashes (args):
    """
    Make sure all arguments don't have any slash or backslash.
    
    (since 0.2.0)
    
    B{Exceptions}
        - DQInvalidRequestException is raised,
            in case, at least, one of the arguments has a blank space.
    """
    
    for arg in args:
        if string.find(arg, '/') >= 0 or string.find(arg, '\\') >= 0:
            err_msg = "Slashes are not allowed in this parameter [%s]!" % (str(arg))
            raise DQInvalidRequestException(err_msg)


def has_wildcard (args):
    """
    Tests if the given arguments have wildcards.
    
    (since 0.2.11)
    
    B{Exceptions}
        - DQInvalidRequestException is raised,
            in case, at least, one of the arguments has a wildcard.
    
    """
    for arg in args:
        if string.find(arg, '*') >= 0:
            err_msg = "Wildcards aren't allowed in this parameter [%s]!" % (str(arg))
            raise DQInvalidRequestException(err_msg)


def is_dataset_location (location):
    """
    Tests if the given location is a valid dataset location.
    (since 0.2.1)
    
    location is the location to be tested.
    
    DQInvalidRequestException is raised,
    in case the location is not a string or
    if it exceeds the maximum length (common.DQValidator.DATASET_LOCATION_MAXLENGTH).
    """
    checkArgsStr([location])
    
    if len(location) > DATASET_LOCATION_MAXLENGTH:
        err_msg = 'Parameter value [%s] exceeds the maximum length (%u).' % (location, DATASET_LOCATION_MAXLENGTH)
        raise DQInvalidRequestException(err_msg)


def is_dataset_location_state (state):
    """
    Tests if the given state is a valid dataset location state (common.DQConstants.LocationState).
    (since 0.2.1)
    
    state is the state to be tested.
    
    DQInvalidRequestException is raised,
    in case the state is not an integer or
    if it is an invalid location state.
    """
    checkArgsInt([state])
    
    if not state in LocationState.STATES:
        err_msg = 'Parameter value [%s] is not a valid dataset location state!' % (state)
        raise DQInvalidRequestException(err_msg)


def is_dataset_name (name):
    """
    Tests if the given name is a valid dataset name.
    (since 0.2.1)
    
    name is the name to be tested.
    
    DQInvalidRequestException is raised,
    in case the name is not a string or
    if it exceeds the maximum length (common.DQContants.DATASET_NAME_MAXLENGTH).
    """
    checkArgsStr([name])
    
    if len(name) == 0:
        err_msg = 'Dataset name [%s] cannot be an empty string!' % (name)
        raise DQInvalidRequestException(err_msg)
    
    if len(name) > DATASET_NAME_MAXLENGTH:
        err_msg = 'Dataset name [%s] exceeds the maximum length (%u)!' % (name, DATASET_NAME_MAXLENGTH)
        raise DQInvalidRequestException(err_msg)
    
    has_slashes([name])
    checkArgsNoBlankSpaces([name])


def is_dataset_state (state):
    """
    Tests if the given state is a valid dataset state (common.DQConstants.DatasetState).
    (since 0.2.1)
    
    state is the state to be tested.
    
    DQInvalidRequestException is raised,
    in case the state is not an integer or
    if it is an invalid state.  
    """
    checkArgsInt([state])
    
    if not state in DatasetState.STATES:
        err_msg = 'Parameter value [%s] is not a valid dataset state!' % (state)
        raise DQInvalidRequestException(err_msg)


def is_destination (site):
    """
    Tests if the given site is a valid destination.
    (since 0.2.9)
    
    site is site name.
    
    DQInvalidRequestException is raised,
    in case site is not a string,
    exceeds the maximum length (common.DQConstants.SITE_MAXLENGTH) or
    ... .
    """
    checkArgsStr([site])
    checkArgsNoBlankSpaces([site])
    
    if len(site) == 0:
        err_msg = 'Parameter value [%s] length is zero.' % (site)
        raise DQInvalidRequestException(err_msg)
    
    if len(site) > SITE_MAXLENGTH:
        err_msg = 'Parameter value [%s] exceeds the maximum length (%u).' % (site, SITE_MAXLENGTH)
        raise DQInvalidRequestException(err_msg)
    
    if not site.upper() in common.TiersOfATLAS.getAllDestinationSites():
        err_msg = 'Parameter value [%s] is not a Tiers of Atlas Destination.' % (site.upper())
        raise DQInvalidRequestException(err_msg)


def is_dictionary (args):
    """
    Make sure all args are dictionaries, if not throw an exception.
    (since 0.2.3)

    DQInvalidRequestException is raised,
    in case, at least, one of the arguments is not a list.
    """

    for arg in args:
        if type(arg) is not dict:
            err_msg = '%s is not a dictionary' % (str(arg))
            raise DQInvalidRequestException(err_msg)


def is_lfn (lfn):
    """
    Tests if the given parameter is a valid logical filename.
    (since 0.2.8)
    
    lfn is the logical filename.

    DQInvalidRequestException is raised,
    in case lfn is not a string,
    exceeds the maximum length (common.DQConstants.LFN_MAXLENGTH).
    
    Regular expressions documentation can be found at:
    http://www.amk.ca/python/howto/regex/
    http://docs.python.org/lib/module-re.html
    """
    checkArgsStr([lfn])
    
    if len(lfn) == 0:
        err_msg = 'Parameter value [%s] length is zero.' % (lfn)
        raise DQInvalidRequestException(err_msg)
    
    if len(lfn) > LFN_MAXLENGTH:
        err_msg = 'Parameter value [%s] exceeds the maximum length (%u).' % (lfn, LFN_MAXLENGTH)
        raise DQInvalidRequestException(err_msg)
    
    has_slashes([lfn])
    checkArgsNoBlankSpaces([lfn])


def is_http_url (url):
    """
    Tests if the given url is a valid URL
    (in the form of http://<host>:<port>/
    NOT in the form of http://<host>:<port>/<path>?<searchpart>
    as described in RFC1738).
    (since 0.2.1)
    
    url is the URL to be tested.

    DQInvalidRequestException is raised,
    in case url is not a string or if it
    doesn't match the regular expression (common.DQValidator.URL_REGEXP).
    
    URL documentation can be found at:
    http://www.cse.ohio-state.edu/cs/Services/rfc/rfc-text/rfc1738.txt
    (section 3.3 HTTP)
    """
    checkArgsStr([url])
    
    if URL_COMPILED_REGEXP.match(url, 0) is None:
        err_msg = 'Parameter value [%s] is not a valid URL (%s).' % (url, URL_REGEXP)
        raise DQInvalidRequestException(err_msg)


def is_list (args):
    """
    Make sure all args are lists, if not throw an exception.
    (since 0.2.3)

    DQInvalidRequestException is raised,
    in case, at least, one of the arguments is not a list.
    """

    for arg in args:
        if type(arg) is not list:
            err_msg = '%s is not a list' % (str(arg))
            raise DQInvalidRequestException(err_msg)


def is_list_of_destinations (sites):
    """
    Tests if the given argument is a list containing valid destinations.
    (since 0.2.9)
    
    sites is a list of sites.
    
    DQInvalidRequestException is raised,
    in case the argument is not a list or
    if one the elements is not a valid site.
    """
    is_list([sites])
    for eachSite in sites:
        is_destination(eachSite)


def is_list_of_lfns (lfns):
    """
    Tests if the given uids is list containing valid generated UUIDs.
    (since 0.2.9)
    
    lfns is the LFN list to be tested.

    DQInvalidRequestException is raised,
    in case lfns is not a list or if
    lfns elements aren't a string,
    exceed the maximum length (common.DQConstants.LFN_MAXLENGTH).
    """
    is_list([lfns])
    for eachLFN in lfns:
        is_lfn(eachLFN)


def is_list_of_metadata_attributes (attributes):
    """
    Tests if the given argument is a list containing valid metadata attributes.
    (since 0.2.11)
    
    attributes is a list of attributes.
    
    DQInvalidRequestException is raised,
    in case the argument is not a list or
    if one the elements is not a valid metadata attribute.
    """
    is_list([attributes])
    for eachAttribute in attributes:
        is_metadata_attribute(eachAttribute)


def is_list_of_sites (sites):
    """
    Tests if the given argument is a list containing valid sites.
    (since 0.2.9)
    
    sites is a list of sites.
    
    DQInvalidRequestException is raised,
    in case the argument is not a list or
    if one the elements is not a valid site.
    """
    is_list([sites])
    for eachSite in sites:
        is_site(eachSite)


def is_list_of_sources (sites):
    """
    Tests if the given argument is a list containing valid sources.
    (since 0.2.9)
    
    sites is a list of sites.
    
    DQInvalidRequestException is raised,
    in case the argument is not a list or
    if one the elements is not a valid site.
    """
    is_list([sites])
    for eachSite in sites:
        is_source(eachSite)


def is_list_of_uids (uids):
    """
    Tests if the given uids is list containing valid generated UUIDs.
    (since 0.2.9)
    
    uids is the UUID list to be tested.

    DQInvalidRequestException is raised,
    in case uids is not a list or if
    uids elements aren't a string,
    exceed the maximum length (common.DQConstants.UID_MAXLENGTH) or
    doesn't match the regular expression (common.DQValidator.UID_REGEXP).
    
    Regular expressions documentation can be found at:
    http://www.amk.ca/python/howto/regex/
    http://docs.python.org/lib/module-re.html
    """
    is_list([uids])
    for eachUID in uids:
        is_uid(eachUID)


def is_location_state (state):
    """
    Tests if the given state is a valid dataset state (common.DQConstants.LocationState).
    (since 0.2.9)
    
    state is the state to be tested.
    
    DQInvalidRequestException is raised,
    in case the state is not an integer or
    if it is an invalid state.  
    """
    checkArgsInt([state])
    
    if not state in LocationState.STATES:
        err_msg = 'Parameter value [%s] is not a valid location state!' % (state)
        raise DQInvalidRequestException(err_msg)


def is_metadata_attribute (attribute):
    """
    Tests if the given attribute is a valid metadata attribute.
    (since 0.2.9)
    
    attribute is the metadata attribute to be tested
    
    DQInvalidRequestException is raised,
    in case the given attribute is not a valid metadata attribute.
    """
    checkArgsStr([attribute])
    
    if not attribute in Metadata.DATASET and not attribute in Metadata.DATASET_VERSION and not attribute in Metadata.TIER0:
        err_msg = 'Parameter [%s] is not a valid metadata attribute!' % (attribute)
        raise DQInvalidRequestException(err_msg)


def is_metadata_value (value):
    """
    Tests if the given value is a valid metadata value.
    (since 0.2.1)
    
    value is the metadata value to be tested.
    
    DQInvalidRequestException is raised,
    in case the state is not a string or
    if it exceeds the maximum length (common.DQContants.METADATA_VALUE_MAXLENGTH).
    """
    checkArgsStr([value])
    
    if len(value) > METADATA_VALUE_MAXLENGTH:
        err_msg = 'Parameter value [%s] exceeds the maximum length (%u)!' % (value, METADATA_VALUE_MAXLENGTH)
        raise DQInvalidRequestException(err_msg)


def is_number (args):
    """
    Make sure all args are numbers, if not throw an exception.
    (since 0.2.11)
    
    DQInvalidRequestException is raised,
    in case, at least, one of the arguments is not an integer.
    """
    
    for arg in args:
        if type(arg) is not int and type(arg) is not float and type(arg) is not long:
            err_msg = '%s is not a number' % (str(arg))
            raise DQInvalidRequestException(err_msg)


def is_site (site):
    """
    Tests if the given site is a valid site.
    (since 0.2.9)
    
    site is site name.
    
    DQInvalidRequestException is raised,
    in case site is not a string,
    exceeds the maximum length (common.DQConstants.SITE_MAXLENGTH) or
    ... .
    """
    checkArgsStr([site])
    checkArgsNoBlankSpaces([site])
    
    if len(site) == 0:
        err_msg = 'Parameter value [%s] length is zero.' % (site)
        raise DQInvalidRequestException(err_msg)
    
    if len(site) > SITE_MAXLENGTH:
        err_msg = 'Parameter value [%s] exceeds the maximum length (%u).' % (site, SITE_MAXLENGTH)
        raise DQInvalidRequestException(err_msg)
    
    sites = common.TiersOfATLAS.getAllSources() + common.TiersOfATLAS.getAllDestinationSites()
    if not site.upper() in sites:
        err_msg = 'Parameter value [%s] is not in Tiers of Atlas.' % (site.upper())
        raise DQInvalidRequestException(err_msg)


def is_source (site):
    """
    Tests if the given site is a valid source.
    (since 0.2.9)
    
    site is site name.
    
    DQInvalidRequestException is raised,
    in case site is not a string,
    exceeds the maximum length (common.DQConstants.SITE_MAXLENGTH) or
    ... .
    """
    checkArgsStr([site])
    checkArgsNoBlankSpaces([site])
    
    if len(site) == 0:
        err_msg = 'Parameter value [%s] length is zero.' % (site)
        raise DQInvalidRequestException(err_msg)
    
    if len(site) > SITE_MAXLENGTH:
        err_msg = 'Parameter value [%s] exceeds the maximum length (%u).' % (site, SITE_MAXLENGTH)
        raise DQInvalidRequestException(err_msg)
    
    if not site.upper() in common.TiersOfATLAS.getAllSources():
        err_msg = 'Parameter value [%s] is not a Tiers of Atlas Source.' % (site.upper())
        raise DQInvalidRequestException(err_msg)


def is_subscription_sources_policy (policy):
    """
    Tests if the given policy is a valid subscription policy (common.DQConstants.SourcesPolicy).
    (since 0.2.1)
    
    policy is the policy to be tested.

    DQInvalidRequestException is raised,
    in case the policy is not a integer or
    if it is invalid policy value.
    """
    checkArgsInt([policy])
    
    if policy < 1:
        err_msg = 'Parameter value [%s] is not a valid subscription source policy!' % (policy)
        raise DQInvalidRequestException(err_msg)


def is_subscription_state (state):
    """
    Tests if the given state is a valid subscription state (common.DQConstants.SubscriptionArchivedState).
    (since 0.2.1)

    state is the state to be tested.

    DQInvalidRequestException is raised,
    in case the state is not a integer or
    if it is invalid state.
    """
    checkArgsInt([state])
    
    if not state in SubscriptionArchivedState.STATES:
        err_msg = 'Parameter value [%s] is not a valid subscription state!' % (state)
        raise DQInvalidRequestException(err_msg)


def is_subscription_modified_state (state):
    """
    Tests if the given state is a valid subscription modified state (common.DQConstants.SubscriptionModifiedState).
    (since 0.3.0)

    state is the state to be tested.

    DQInvalidRequestException is raised,
    in case the state is not a integer or
    if it is invalid state.
    """
    checkArgsInt([state])
    
    if not state in SubscriptionModifiedState.STATES:
        err_msg = 'Parameter value [%s] is not a valid subscription modified state!' % (state)
        raise DQInvalidRequestException(err_msg)


def is_tier0_metadata_attribute (attribute):
    """
    Tests if the given attribute is a valid metadata attribute.
    (since 0.2.11)
    
    attribute is the metadata attribute to be tested
    
    DQInvalidRequestException is raised,
    in case the given attribute is not a valid metadata attribute.
    """
    checkArgsStr([attribute])
    
    if not attribute in Metadata.TIER0:
        err_msg = 'Parameter [%s] is not a valid tier0 metadata attribute!' % (attribute)
        raise DQInvalidRequestException(err_msg)


def is_tuple (args):
    """
    Make sure all args are tuples, if not throw an exception.
    (since 0.2.10)

    DQInvalidRequestException is raised,
    in case, at least, one of the arguments is not a tuple.
    """

    for arg in args:
        if type(arg) is not tuple:
            err_msg = '%s is not a tuple' % (str(arg))
            raise DQInvalidRequestException(err_msg)


def is_uid (uid):
    """
    Tests if the given uid is a valid generated UUID.
    (since 0.2.1)
    
    uid is the UUID to be tested.

    DQInvalidRequestException is raised,
    in case uid is not a string,
    exceeds the maximum length (common.DQConstants.UID_MAXLENGTH) or
    doesn't match the regular expression (common.DQValidator.UID_REGEXP).
    
    Regular expressions documentation can be found at:
    http://www.amk.ca/python/howto/regex/
    http://docs.python.org/lib/module-re.html
    """
    checkArgsStr([uid])
    
    if len(uid) > UID_MAXLENGTH:
        err_msg = 'Parameter value [%s] exceeds the maximum length (%u).' % (uid, UID_MAXLENGTH)
        raise DQInvalidRequestException(err_msg)
    
    if UID_COMPILED_REGEXP.match(uid, 0) is None:
        err_msg = 'Parameter value [%s] is not a valid uid (%s).' % (uid, UID_REGEXP)
        raise DQInvalidRequestException(err_msg)


def checkArgsInt (args):
    """
    Make sure all args are ints, if not throw an exception.
    (since 0.2.0)
    
    DQInvalidRequestException is raised,
    in case, at least, one of the arguments is not an integer.
    """
    
    for arg in args:
        if type(arg) is not int:
            err_msg = '%s is not an int' % (str(arg))
            raise DQInvalidRequestException(err_msg)


def checkArgsList (args):
    """
    Make sure all args are lists, if not throw an exception.
    (since 0.2.0)
    
    DQInvalidRequestException is raised,
    in case, at least, one of the arguments is not a list.
    """
    
    for arg in args:
        if type(arg) is not list:
            err_msg = '%s is not a list' % (str(arg))
            raise DQInvalidRequestException(err_msg)


def checkArgsNoBlankSpaces (args):
    """
    Make sure all arguments don't have any blank spaces.
    (since 0.2.0)
    
    DQInvalidRequestException is raised,
    in case, at least, one of the arguments has a blank space.
    """
    
    for arg in args:
        if string.find(arg, ' ') >= 0:
            err_msg = "Blank spaces are not allowed in this parameter [%s]." % (str(arg))
            raise DQInvalidRequestException(err_msg)


def checkArgsStr (args):
    """
    Make sure all args are strings, if not throw an exception.
    (since 0.2.0)
    
    DQInvalidRequestException is raised,
    in case, at least, one of the arguments is not a string.
    """
    
    for arg in args:
        if type(arg) is not str:
            err_msg = '%s is not a string' % (str(arg))
            raise DQInvalidRequestException(err_msg)
