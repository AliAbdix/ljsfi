"""
Tiers of ATLAS
(since 0.2)

This module contains the set of ATLAS sites and its organizational
structure in Tiers.

$Id: TiersOfATLAS.py,v 1.1.2.19 2006/08/29 15:24:22 mbranco Exp $
"""

import os
import stat
import sys
import time
import re
import random
import urllib

from common.DQException import DQTiersOfATLASException


# ToA default URL
TIERS_OF_ATLAS_URL = 'http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/TiersOfATLASCache.py'

# refresh script every few hours
EXPIRED_SECS = 72000


def _cleanPermissions():
    """
    Clean permissions for ToA cache
    (adding group permissions, for DQ2 installations shared
    among multiple users)
    """
    import common
    dir = os.path.abspath(common.__path__[0])
    script = '%s/TiersOfATLASCache.py' % dir

    try:
        # reset permissions to source .py
        os.chmod(script, stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH | \
                            stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH)
    except:
        pass
        
    try:
        # reset permissions to compiled .pyc
        os.chmod('%sc' % script, stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH | \
                            stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH)
    except:
        pass



# first time try to import
try:
    import common.TiersOfATLASCache
    ToACache = common.TiersOfATLASCache
    _cleanPermissions()
except:
    # if fail, will download again
    ToACache = None


def _refreshToACache():
    """
    Auto-update Tiers of ATLAS cache file
    """
    global ToACache, TIERS_OF_ATLAS_URL, EXPIRED_SECS
    
    import common
    dir = os.path.abspath(common.__path__[0])
    script = '%s/TiersOfATLASCache.py' % dir

    missing_or_failed = False
    elapsed_secs = 0
    try:
        elapsed_secs = time.time() - os.stat(script).st_mtime
    except:
        missing_or_failed = True
    
    # missing, expired or bad file
    if missing_or_failed or ToACache is None or elapsed_secs > EXPIRED_SECS:
        
        # download file
        try:
            urllib.urlretrieve(TIERS_OF_ATLAS_URL, script)
        except:
            # failed to download, but don't die - use old ToA!
            if not missing_or_failed and not ToACache is None:
                return
            
            # otherwise through exception
            raise DQTiersOfATLASException("Failed downloading ToA [%s]" % TIERS_OF_ATLAS_URL)
                
        # load ToA cache
        if ToACache is None:
            try:
                import common.TiersOfATLASCache
            except Exception ,e:
                print str(e)
                raise DQTiersOfATLASException("Failed importing ToA")
        else:
            # just reload
            reloaded = False
            for i in range(0,5):
                try:
                    reload(common.TiersOfATLASCache)
                    reloaded = True
                    break
                except:
                    time.sleep(1)
            if not reloaded:
                raise DQTiersOfATLASException("Failed reloading ToA")

        _cleanPermissions()

        ToACache = common.TiersOfATLASCache
        

def _resolveSites(id, start=None):
    """
    Resolves cloud (or site) to a list of 'sites'.
    
    Returns empty list if nothing found or list of
    'sites' matching id.
    """
    id = id.upper()
    
    # first cycle
    if start is None:
        nid = id
    else:
        nid = start
    # termination condition
    if ToACache.sites.has_key(nid):
        return [ nid ]
    # for all elements, aggregate sites
    if not ToACache.topology.has_key(nid):
        return []
    ids = []
    for el in ToACache.topology[nid]:
        response = _resolveSites(id, start=el)
        if response is not None:
            # remove repeated elements
            for id in response:
                if ids.count(id) == 0:
                    ids.append( id )
    return ids


def getCloseSites(id):
    """
    Returns list of sites which are close to given site id,
    or empty list if no close sites found.
    
    Depends on definitions in 'closeSitesTopology'.
    If id is not explicit on 'closeSitesTopology', will
    use topology to resolve sites.
    """
    _refreshToACache()
    
    id = id.upper()
    
    els = []
    
    if ToACache.closeSitesTopology.has_key(id):
        els = ToACache.closeSitesTopology[id]
    else:
        # find site in keys
        for k, v in ToACache.closeSitesTopology.iteritems():
            if id in _resolveSites(k):
                els = v
                break
    
    # find all sites
    sites = []
    for el in els:
        response = _resolveSites(el)
        for id in response:
            if sites.count(id) == 0:
                sites.append( id )
    return sites


def getAllDestinationSites():
    """
    Returns list with all valid destination sites
    """
    _refreshToACache()
    
    return ToACache.sites.keys()
    
    
def getAllSources():
    """
    Returns list with all valid source sites
    """
    _refreshToACache()
    
    # first get all sites
    s = ToACache.sites.keys()
    
    # then get clouds
    g = ToACache.topology.keys()
    for id in g:
        # only add unique entries
        if s.count(id) == 0:
            s.append(id)

    return s


def getLocalCatalog(id):
    """
    Find local catalog endpoint for site.
    
    Supports overriding endpoints in a local configuration file:
      lrcs_conf.py
    that must contain a variable 'lrcs' with a dictionary mapping
      site name to lrc connection string
    
    Returns endpoint or None.
    """
    
    lrcs_conf = None
    try:
        lrcs_conf = __import__('lrcs_conf')
    except:
        pass
    
    # there is a local configuration file
    if lrcs_conf is not None:

        # check if it has site id
        if lrcs_conf.lrcs.has_key(id):
            return lrcs_conf.lrcs[id]
    
    # otherwise check ToA cache
    _refreshToACache()
    
    id = id.upper()
    
    # 'id' must be a destination site...
    if not id in getAllDestinationSites():
        return None
        
    # scan catalogs topology
    for k, v in ToACache.catalogsTopology.iteritems():
        
        for el in v: 
            
            # is explicit on catalogs topology
            if el == id:
                return k
                
            # otherwise is part of a cloud
            response = _resolveSites(el)
            if id in response:
                return k
                
    return None


def getRemoteCatalogs(id):
    """
    Returns list of catalogs associated with site or cloud.
    """
    _refreshToACache()
    
    id = id.upper()
    
    cats = []
    
    # scan catalogs topology
    for k, v in ToACache.catalogsTopology.iteritems():
        
        for nid in v:
            sites = _resolveSites(nid)
            if id in sites:
                return [k]
    
    # not explicit on catalogs topology
    sites = _resolveSites(id)
    
    # recursion termination condition
    if sites == [id]:
        return []
    else:    
        for nid in sites:
            ncats = getRemoteCatalogs(nid)

            # remove repeated elements
            for cat in ncats:
                if cats.count(cat) == 0:
                    cats.append(cat)
        
    return cats


def getFTS(src_surl, dest_surl):
    """
    Finds FTS server serving src -> dest storage URLs.
    
    Supports wildcard channels only if there is not an
    explicit channel between two sites (specified directly
    by hostnames)

    Returns FTS endpoint or None
    """
    _refreshToACache()
    
    # scan FTS topology for explicit matching pairs
    for server, mappings in ToACache.ftsTopology.iteritems():
        
        for dest, srcs in mappings.iteritems():
            
            # base destination path matches
            if dest_surl.find(dest) != -1:
                
                for src in srcs:
                    
                    # base source patch matches
                    if src_surl.find(src) != -1:
                        return server
    
    # re-scan FTS topology for explicit OR wildcards matching pairs
    for server, mappings in ToACache.ftsTopology.iteritems():
        
        for dest, srcs in mappings.iteritems():
            
            # destination matches (FTS topology has wildcard or base path for surl matches)
            if dest == '*' or dest_surl.find(dest) != -1:
                
                for src in srcs:
                    
                    # source matches (FTS topology has wildcard or base path for surl matches)
                    if src == '*' or src_surl.find(src) != -1:
                        return server

    return None
    
    
def getSiteProperty(id, property):
    """
    Will find property for a site id.
    
    Returns property value or None
    """
    _refreshToACache()
    
    id = id.upper()
    
    # property found        
    if property is not None:
        if ToACache.sites.has_key(id) and \
            ToACache.sites[id].has_key(property):
            return ToACache.sites[id][property]
            
    return None


def listCEsInCloudByCloud(id):
    """
    Given the name of a cloud as defined in the dbcloud dictionary
    in the cache, return all the CEs in the cloud.
    """

    _refreshToACache()

    id = id.upper()

    if not ToACache.dbcloud.has_key(id):
        return None

    els = []
    id = ToACache.dbcloud[id]
    
    if ToACache.topology.has_key(id):
        els = ToACache.topology[id]
    else:
        # find site in keys
        for k, v in ToACache.topology.iteritems():
            if id in _resolveSites(k):
                els = v
                break
    
    # find all sites
    sites = []
    for el in els:
        response = _resolveSites(el)
        for id in response:
            if sites.count(id) == 0:
                sites.append( id )

    ces = []
    for site in sites:
        celist = getSiteProperty(site, 'ce')
        if celist is not None:
            for ce in celist:
                if ce != '' and ce not in ces:
                    ces.append(ce)

    return ces


def listCEsInCloudByDomain(domain):
    """
    Given an expression of a domain (eg *.fr) return all the CE
    hostnames matching the epression
    """

    _refreshToACache()
    
    ces = []

    # make sure domain is correct python re syntax
    # assume nothing too complicated...
    i = domain.find('*')
    if i != -1 and (i == 0 or domain[i-1] != '.'):
        domain = domain.replace('*', '.*', 1)
    if domain[-1] != '$':
        domain = domain+'$'

    # go through all sites and match ce hostname against domain
    for site in getAllDestinationSites():
        celist = getSiteProperty(site, 'ce')
        if celist is not None:
            for ce in celist:
                if re.match(domain, ce):
                    ces.append(ce)

    return ces


def getStorageInfo(ce):
    """
    For the given CE, returns the LFC that output files should
    be registered to and a list of storages to store output files
    in order of preference

    - close SE to the CE
    - the associated T1's SE
    - other SEs in the cloud

    Returns a tuple (LFC endpoint, [list of storage endpoints])
    """

    _refreshToACache()
    storages = []
    
    # first find the site the CE is in
    cesite = None
    for site in getAllDestinationSites():
        celist = getSiteProperty(site, 'ce')
        if celist is not None:
            for c in celist:
                if c == ce:
                    cesite = site

    if cesite is None:
        return None

    # get the associated LFC
    lfc = getLocalCatalog(cesite)

    # get the local storage
    localSE = getSiteProperty(cesite, 'srm')
    if localSE is not None and localSE != '':
        storages.append(localSE)
        
    # go through all close sites, picking out T1
    cloudSEs = []
    for site in getCloseSites(cesite):

        # ignore own site and tape sites
        if site == cesite or site[-4:] == 'TAPE':
            continue

        se = getSiteProperty(site, 'srm')
        if se is not None and se != '':
            # if this is the T1 site add to storages list
            if site[-4:] == 'DISK' and site[:-4] in ToACache.topology['TIER1S']:
                storages.append(se)
            else:
                cloudSEs.append(se)
                
    # randomise and add the cloud SEs to the list
    random.shuffle(cloudSEs)
    storages.extend(cloudSEs)

    return (lfc, storages)


def getTier1s():
    """
    Return a dictionary of the T1 clouds mapped to a list
    of CEs within the cloud
    """
    _refreshToACache()

    ces = {}
    t1s = ToACache.dbcloud.keys()
    for t1 in t1s:
        ces[t1] = listCEsInCloudByCloud(t1)

    return ces


def getSiteByCE(ce):
    """
    Return the site id which hosts the CE.
    Brute force method: loop over all sites
    """
    sites = getAllDestinationSites()

    for site in sites:
        ces = getSiteProperty(site, 'ce')
        if ces and len(ces) > 0 and ce in ces:
            return site

    return None


def isSURLFromSiteOrCloud(surl, id):
    """
    Checks if given SURL matches the domain
    specified for the given site or cloud.
    In case of cloud will need to resolve all
    sites within the cloud first.
    
    Returns boolean.
    """
    _refreshToACache()
    
    id = id.upper()
    
    # check site first
    if ToACache.sites.has_key(id):
        if re.match(ToACache.sites[id]['domain'], surl):
            return True
    else:
        # not site, so check clouds
        ids = _resolveSites(id)
        for nid in ids:
            if ToACache.sites.has_key(nid) and \
                ToACache.sites[nid].has_key('domain') and \
                re.match(ToACache.sites[nid]['domain'], surl):
                return True
    
    return False


