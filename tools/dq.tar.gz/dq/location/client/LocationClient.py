"""Client to the dataset location central catalog."""

import common.DQValidator
import getopt
import os
import string
import sys

from common.client.DQClient import DQClient
from common.DQConstants import HTTP, LocationState
from common.DQException import DQException, DQInvalidRequestException
from common.client.x509 import getX509
from common.client.x509 import getCAPath


# MODULE classes


class LocationClient (DQClient):
    """
    Class to make requests to the dataset location central catalog.
    (since 0.2.0)
    """


    def __init__ (self, url=None, urlsec=None, certificate=None, ca_path=None):
        """
        Constructs a LocationClient instance.
        (since 0.2.0)
        
        url is the non-secure URL of the host to be contacted.
        urlsec is the secure URL of the host to be contacted.
        certificate is the proxy certificate.
        ca_path is the location of the Certification Authority certificates.
        """
        DQClient.__init__(self, url, urlsec, certificate, ca_path)


    def addDatasetReplica (self, vuid, site, dsn, complete=LocationState.INCOMPLETE):
        """
        POST request to insert new dataset replica.
        (since 0.2.0)
        
        vuid is the dataset version unique identifier.
        site is the dataset location.
        dsn is the dataset name.
        complete is the state of the dataset version.
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQLocationExistsException is raised,
        in case a dataset version replica exists at the given location.
        
        Nothing is returned.
        """
        
        common.DQValidator.is_uid(vuid)
        common.DQValidator.is_site(site)
        common.DQValidator.is_location_state(complete)
        common.DQValidator.is_dataset_name(dsn)
        
        self.type = HTTP.POST
        self.request = '/location/dataset'
        self.params = {'vuid': vuid, 'site': site, 'dsn': dsn, 'complete': complete}

        self.send()


    def auto_configure ():
        """
        (since 0.2.0)
        
        Returns this client configuration.
        (url_insecure_host, url_secure_host)
        """
        import client_conf
        
        return (
            client_conf.location['insecure'],
            client_conf.location['secure']
        )

    auto_configure = staticmethod(auto_configure)


    def deleteDataset (self, vuid):
        """
        Delete all replicas of the dataset.
        (since 0.2.0)
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        
        Nothing is returned.
        """
        
        common.DQValidator.is_uid(vuid)
        
        replicas = self.queryDatasetLocations(vuids=[vuid])
        
        # vuid only belong to one dsn => only 1 dsn returned => [0] 
        if not len(replicas) == 0:
            replicas = replicas.values()[0]
            sites = []
            sites = sites + replicas[LocationState.COMPLETE] + replicas[LocationState.INCOMPLETE]
            self.deleteDatasetReplica(vuid, sites)


    def deleteDatasetReplica (self, vuid, sites):
        """
        DEL to delete the dataset from the given sites.
        (since 0.2.0)
        
        vuid is the dataset version unique identifier.
        sites is a list of the dataset replica locations.
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        
        Nothing is returned.
        """
        
        common.DQValidator.is_uid(vuid)
        common.DQValidator.is_list_of_sites(sites)
        
        self.type = HTTP.DELETE
        self.request = '/location/dataset'
        self.params = {'vuid': vuid, 'site': sites}
        
        self.send()


    def queryDatasetLocations (self, vuids=[], dsns=[], complete=None):
        """
        GET request to find the locations of the dataset.
        (since 0.2.0)
        
        vuids is a list of dataset version unique identifiers.
        dsns is a list of dataset names.
        complete is the dataset replication state.
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        
        Returns a list of locations.
        {
            'dsn_A': {
                LocationState.COMPLETE:
                ['site_A', 'site_Y'],
                LocationState.INCOMPLETE:
                ['site_Z', 'site_X']
        }
        """
        
        common.DQValidator.is_list_of_uids(vuids)
        common.DQValidator.checkArgsList([dsns])
        if complete is not None:
            common.DQValidator.is_location_state(complete)
        for eachDSN in dsns:
            common.DQValidator.is_dataset_name(eachDSN)
        
        if len(dsns) == 0 and len(vuids) == 0:
            raise DQInvalidRequestException('The vuids and dsns cannot be empty!')
        
        # check if complete is 0 or 1 or empty
        
        self.type = HTTP.GET
        self.request = '/location/dataset'
        self.params = {'vuids': vuids, 'dsns': dsns, 'complete': complete}

        return self.send()


    def queryDatasetsInSite (self, site, complete=None, page=1, rpp=100):
        """
        GET request to get the vuids of datasets on the given site
        (starting at page <page> and retrieve <rpp> results per page).
        (since 0.2.0)
        
        site is the dataset location.
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        
        Returns a list of dataset versions.
        {'dsn': ['vuid_1', ... 'vuid_N']}
        """
        
        common.DQValidator.is_site(site)
        common.DQValidator.checkArgsInt([page, rpp])
        if complete is not None:
            common.DQValidator.is_location_state(complete)
        
        if (page <= 0):
            page = 1
        if (rpp <= 0):
            rpp = 100
        
        
        self.type = HTTP.GET
        self.request = '/location/dataset'
        self.params = {'site': site, 'complete': complete, 'page': page, 'rpp': rpp}
        
        return self.send()


# MODULE methods


def usage():
    """
    Usage: python LocationClient.py <command> <args>
    
      Commands:
    
      addDatasetReplica <-i|-c> <dataset vuid> <site> <dataset name>
      queryDatasetLocations [-i|-c] <dataset_vuids[]> <dataset_names[]>
      queryDatasetsInSite [-i|-c] <site>
      deleteDatasetReplica <dataset vuid> <site[]>
      deleteDataset <dataset vuid>
    
      -i and -c signify incomplete and complete datasets respectively
      (mandatory for adds, optional for queries (default is return both))
    """
    print usage.__doc__


def main(argv):
    """
    (since 0.2.0)
    """

    if len(argv) < 2:
        usage()
        sys.exit(1)

    try:
        opts, args = getopt.getopt(argv[1:], "ic")
    except getopt.GetoptError:
        print "Invalid arguments!"
        usage()
        sys.exit(2)

    complete = None
    for o, a in opts:
        if o == "-c":
            complete = LocationState.COMPLETE
        elif o == "-i":
            complete = LocationState.INCOMPLETE
    
    # retrieving client configuration
    client = LocationClient()
    
    try:
        if argv[0]=='addDatasetReplica':
            out = client.addDatasetReplica(args[0], args[1], args[2], complete)
        elif argv[0]=='queryDatasetLocations':
            out = client.queryDatasetLocations(eval(args[0]), eval(args[1]), complete=complete)
        elif argv[0]=='queryDatasetsInSite':
            out = client.queryDatasetsInSite(args[0], complete)
        elif argv[0]=='deleteDatasetReplica':
            out = client.deleteDatasetReplica(args[0], eval(args[1]))
        elif argv[0]=='deleteDataset':
            out = client.deleteDataset(args[0])
        else:
            print 'Unknown command:',argv[0]
            sys.exit(1)
            
        print out

    except DQException, err_msg:
        sys.stderr.write('Error: '+str(err_msg)+'\n')


if __name__ == '__main__':
    main(sys.argv[1:])
