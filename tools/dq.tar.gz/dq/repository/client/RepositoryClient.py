"""Client to the dataset repository central catalog."""

import common.DQValidator
import os
import string
import sys
import urllib

from common.client.DQClient import DQClient
from common.client.DQCurl import DQCurl
from common.DQConstants import HTTP
from common.DQException import *
from common.client.x509 import getX509
from common.client.x509 import getCAPath


# MODULE classes


class RepositoryClient (DQClient):
    """
    Class to make requests to the dataset repository central catalog.
    (since 0.2.0)
    """


    def __init__ (self, url=None, urlsec=None, certificate=None, ca_path=None):
        """
        Constructs a RepositoryClient instance.
        (since 0.2.0)
        
        url is the non-secure URL of the host to be contacted.
        urlsec is the secure URL of the host to be contacted.
        certificate is the proxy certificate.
        ca_path is the location of the Certification Authority certificates.
        """
        DQClient.__init__(self, url, urlsec, certificate, ca_path)


    def addDataset (self, dsn):
        """
        POST request to insert new dataset which is assigned version 1.
        (since 0.2.0)
        
        dsn is the dataset name.
        
        DQDatasetExistsException is raised,
        in case there is a dataset with the given name.
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        
        Returns a dictionary containing the dataset duid, vuid and version information.
        {'duid': '...', 'vuid': '...', 'version': ...}
        """
        
        common.DQValidator.is_dataset_name(dsn)
        
        self.type = HTTP.POST
        self.request = '/repository/dataset'
        self.is_secure = True
        self.params = {'dsn': dsn}
        
        return self.send()


    def auto_configure():
        """
        (since 0.2.0)
        
        Returns this client configuration.
        (url_insecure_host, url_secure_host)
        """
        import client_conf
        
        return (
            client_conf.repository['insecure'],
            client_conf.repository['secure']
        )

    auto_configure = staticmethod(auto_configure)


    def deleteDataset (self, dsn):
        """
        DEL to delete a dataset.
        (since 0.2.0)
        
        dsn is the dataset name.
        
        Raises DQSecurityException,
        in case the user has no permissions to delete the dataset.
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        
        Nothing is returned.
        """
        
        common.DQValidator.is_dataset_name(dsn)
        
        self.type = HTTP.DELETE
        self.request = '/repository/dataset'
        self.params = {'dsn': dsn}

        self.send()


    def getMetaDataAttribute (self, dsn, attrname):
        """
        GET request to get the value of a particular attribute.
        (since 0.2.0)
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQInvalidRequestException is raised,
        in case of an invalid attribute name.        
        DQUnknownDatasetException is raised,
        in case there is no dataset with the given name.
        
        Returns a string representation of the attribute value.
        '<attribute_value>'
        """
        
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.is_metadata_attribute(attrname)
        
        self.type = HTTP.GET
        self.request = '/repository/attribute'
        self.params = {'dsn': dsn, 'attrname': attrname}
        
        return self.send()


    def getState (self, dsn):
        """
        Gets dataset state.
        Check common.DQConstants.DatasetState.
        (since 0.2.0)
        
        dsn is the dataset name.
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        
        Returns the dataset state (check common.DQConstants.DatasetState).
        """
        
        common.DQValidator.is_dataset_name(dsn)
        
        self.type = HTTP.GET
        self.request = '/repository/state'
        self.params = {'dsn': dsn}
        
        return self.send()


    def queryDatasetByCreationDate (self, days):
        """
        GET request to get the last created dataset versions between [now-<days>, now+<days>].
        (since 0.2.0)
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        
        Returns a dictionary containing the dataset versions information.
        {
            'dataset_nameA': ['A_vuid_for_version1+X', ..., 'A_vuid_for_version1']
            'dataset_nameB': ['B_vuid_for_version1']
        }, where X > 0
        """
        
        common.DQValidator.is_number([days])
        
        self.type = HTTP.GET
        self.request = '/repository/dataset'
        self.params = {'days': days}
        
        return self.send()


    def queryDatasetByName (self, dsn, version=0):
        """
        GET request to get the vuid of a particular version of
        the dataset given by the name.
        If no version no is given the latest one is returned.
        (since 0.2.0)
        
        dsn is the dataset name.
        version is the dataset version, 0 means return the latest version).
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        
        usage:
        queryDatasetByName('myname') - returns all versions of the given dataset
        queryDatasteByName('myname*') - returns all versions of the datasets that start by 'myname'.
        queryDatasteByName('*myname') - returns all versions of the datasets that end by 'myname'.
        
        queryDatasetByName('myname', 2) - returns the version 2 of dataset 'myname'.
        queryDatasetByName('myname', 0) - returns the latest version of the dataset 'myname'.
        queryDatasetByName('myname', <0) - returns all the versions of the dataset 'myname'.
        queryDatasetByName('myname', ]-infinite, 0[) - returns all the versions of the dataset 'myname'.
        
        queryDatasetByName('myname*', 2) - returns the version 2 of the datasets that start by 'myname'.
        queryDatasetByName('*myname', None) - returns all the versions of the datasets that end with 'myname'.
        
        Returns a dictionary containing the dataset versions information.
        {
            'dataset_nameA': {'duid': duid, 'vuids': ['A_vuid_for_version1+X', ..., 'A_vuid_for_version1']}
            'dataset_nameB': {'duid': duid, 'vuids': ['B_vuid_for_version1']}
        }, where X > 0
        """
        
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.checkArgsInt([version])
        
        self.type = HTTP.GET
        self.request = '/repository/dataset'
        self.params = {'dsn': dsn, 'version': version}
        
        return self.send()


    def queryDatasetByMetaData (self, query):
        """
        GET request to retrieve the dataset versions that match the given criteria.
        (since 0.2.0)
        
        query the metadata search criteria ({'n': a, 'v': b}).
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        
        Return value is a list of tuples with (dataset name, version).
        {
            'dataset_name_1', ['vuid_1', ...],
            ...,
            'dataset_name_N', ['vuid_N', ...]
        }
        """
        
        common.DQValidator.is_dictionary([query])
        
        for eachAttribute in query.keys():
            common.DQValidator.is_metadata.attribute(eachAttribute)
        for eachValue in query.values():
            common.DQValidator.is_metadata.value(eachValue)
        
        self.type = HTTP.GET
        self.request = '/repository/metadata'
        self.params = {'query': query}
        
        return self.send()


    def resolveDUID (self, duid):
        """
        Get the latest version of the duid, or if it is a vuid,
        just return it.
        (since 0.2.0)
        
        duid is the dataset unique identifier.
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQUnknownDatasetException is raised,
        in case there is no dataset or dataset version for this duid.
        
        Returns a vuid (dataset version unique identifier).
        '<vuid>'
        """
        
        common.DQValidator.is_uid(duid)
        
        self.type = HTTP.GET
        self.request = '/repository/dataset'
        self.params = {'duid': duid}
        
        return self.send()


    def resolveName (self, dsn):
        """
        GET request to find the duid and pfn of the
        given name.
        (since 0.2.0)
        
        dsn is the dataset name.
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQUnknownDatasetException is raised,
        in case there is no dataset or dataset version for this duid.
        
        Returns the matching duid.
        {'duid': duid, 's': state}
        """
        
        common.DQValidator.is_dataset_name(dsn)
        
        self.type = HTTP.GET
        self.request = '/repository/dataset'
        self.params = {'dsn': dsn}
        
        return self.send()


    def resolveVUID (self, vuid):
        """
        Get the name and version of the given vuid.
        (since 0.2.0)
        
        vuid is the dataset version unique identifier.
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQUnknownDatasetException is raised,
        in case there is no dataset or dataset version with this vuid.
        
        Returns the dataset version name and number.
        return {'dsn': dsn, 'version': version}
        """
        
        common.DQValidator.is_uid(vuid)
        
        self.type = HTTP.GET
        self.request = '/repository/dataset'
        self.params = {'vuid': vuid}
        
        return self.send()


    def resolveUIDs (self, uids):
        """
        Returns a list of VUIDs containing all attributes.
        (since 0.2.0)
        
        uids is either a list of dataset (duid)/dataset version (vuid) unique identifiers
        or a mixture of both.
        if the uid is a duid only the last version information will be returned.
        
        DQDaoException is raised,
        in case there is a python or database error.
        
        Returns the dataset and/or dataset version information.
        {'uid':
            {'vuid': vuid, 'duid': duid, 'version': version, 'cdate': cdate, 'state': state, 'dsn': dsn, 'owner': owner}
        }
        """
        
        common.DQValidator.is_list_of_uids(uids)
        
        self.type = HTTP.POST
        self.request = '/repository/datasets'
        self.is_secure = False
        self.params = {'uids': uids}
        
        return self.send()


    def setMetaDataAttribute (self, dsn, attrname, attrvalue):
        """
        POST request to set the value of a particular attribute.
        (since 0.2.0)
        
        dsn is the dataset name.
        attrname the metadata attribute to be set ('tier0state', 'tier0nrpartitions', 'tier0type').
        attrvalue the metadata attribute value (maximum 10 characters, the rest will be cut).
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQSecurityException is raised,
        in case the user has no permissions to set metadata attributes on the dataset.
        DQInvalidRequestException is raised,
        in case of an invalid attribute name.        
        DQUnknownDatasetException is raised,
        in case there is no dataset with the given name.
        
        Nothing is returned.
        """
        
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.is_tier0_metadata_attribute(attrname)
        common.DQValidator.is_metadata_value(attrvalue)
        
        self.type = HTTP.POST
        self.request = '/repository/attribute'
        self.params = {'dsn': dsn, 'attrname': attrname, 'attrvalue': attrvalue}
        
        self.send()


    def setState (self, dsn, state):
        """
        Sets dataset state. 
        (since 0.2.0)
        
        dsn is the dataset name.
        state is the dataset version state (check common.DQConstants.DatasetState).
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQDatasetClosedException is raised,
        in case the user is trying to closed an already closed dataset.
        DQDatasetNotClosedException is raised,
        in case the user is trying to open an already opened dataset.
        DQSecurityException is raised,
        in case the given user cannot change the dataset version state.
        
        Nothing is returned.
        """
        
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.is_dataset_state(state)
        
        self.type = HTTP.POST
        self.request = '/repository/state'
        self.params = {'dsn': dsn, 'state': int(state)}
        
        self.send()


    def updateVersion (self, dsn, vuid=None):
        """
        PUT request to register a new version of the dataset
        given by name (version automatically incremented by 1).
        (since 0.2.0)
        
        dsn is the dataset name.
        vuid is the dataset unique identifier for the new version.
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        DQSecurityException is raised,
        in case the user has no permissions to update the dataset.
        
        Returns a dictionary containing the dataset version information.
        {'vuid': vuid_1, 'version': 1}
        """
        
        common.DQValidator.is_dataset_name(dsn)
        if vuid is not None:
            common.DQValidator.is_uid(vuid)
        
        self.type = HTTP.PUT
        self.request = '/repository/dataset'
        self.params = {'dsn': dsn, 'vuid': vuid}

        return self.send()


# MODULE methods


def usage():
    """
    Usage: python RepositoryClient.py <command> <args>

      Commands:

      addDataset <dataset name>
      updateVersion <dataset name>
      queryDatasetByCreationDate <number_of_days>
      queryDatasetByName <dataset name> [version]
      queryDatasetByMetaData <name value list>

      setMetaDataAttribute <dataset name> <attribute name> <attribute value>
      getMetaDataAttribute <dataset name> <attribute name>
      
      resolveDUID <dataset duid>
      resolveVUID <dataset vuid>
      resolveUIDs <dataset vuids - ['vuid0', ..., 'vuidN']>
      
      getState <dataset name>
      setState <dataset name> <state 1/2>
      
      deleteDataset <dataset name>
    """
    print usage.__doc__


def main(argv):
    """
    (since 0.2.0)
    """

    if len(argv) < 2:
        usage()
        sys.exit(1)
    
    # retrieving client configuration
    client = RepositoryClient()
    
    
    try:
        
        if argv[0]=='resolveName':
            out = client.resolveName(argv[1])
        elif argv[0]=='queryDatasetByName':
            if len(argv) > 2:
                out = client.queryDatasetByName(argv[1], int(argv[2]) )
            else:
                out = client.queryDatasetByName(argv[1])
        elif argv[0]=='resolveDUID':
            out = client.resolveDUID(argv[1])
        elif argv[0]=='resolveVUID':
            out = client.resolveVUID(argv[1])
        elif argv[0]=='resolveUIDs':
            out = client.resolveUIDs(eval(argv[1]))
        elif argv[0]=='queryDatasetByCreationDate':
            out = client.queryDatasetByCreationDate(int(argv[1]))
        elif argv[0]=='getState':
            out = client.getState(argv[1])
        elif argv[0]=='setState':
            out = client.setState(argv[1], int(argv[2]))
        elif argv[0]=='queryDatasetByMetaData':
            out = client.queryDatasetByMetaData(eval(argv[1]))
        elif argv[0]=='getMetaDataAttribute':
            out = client.getMetaDataAttribute(argv[1], argv[2])
        elif argv[0]=='setMetaDataAttribute':
            out = client.setMetaDataAttribute(argv[1], argv[2], argv[3])
        elif argv[0]=='addDataset':
            if len(argv) > 2: out = client.addDataset(argv[1], int(argv[2]) )
            else: out = client.addDataset(argv[1])
        elif argv[0]=='updateVersion':
            if len(argv) > 2:
                out = client.updateVersion(argv[1], int(argv[2]) )
            else:
                out = client.updateVersion(argv[1])
        elif argv[0]=='deleteDataset':
            out = client.deleteDataset(argv[1])
        else:
            print 'Unknown command:', argv[0]
            sys.exit(1)

        print out

    except DQException, err_msg:
        sys.stderr.write('Error: '+str(err_msg)+'\n')

        
if __name__ == '__main__':
    main(sys.argv[1:])
