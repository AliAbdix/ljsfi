"""
Client to the dataset subscription central catalog.

$Id: SubscriptionClient.py,v 1.22.2.22 2006/08/16 10:11:54 psalgado Exp $
"""


import common.DQValidator
import getopt
import os
import string
import sys

from common.client.DQClient import DQClient
from common.DQConstants import HTTP, SourcesPolicy, SubscriptionArchivedState
from common.DQException import DQException, DQInvalidRequestException, DQBackendException
from common.client.x509 import getCAPath
from common.client.x509 import getX509


# MODULE classes


class SubscriptionClient (DQClient):
    """
    Class to make requests to the dataset subscription central catalog.
    (since 0.2.0)
    """


    def __init__ (self, url=None, urlsec=None, certificate=None, ca_path=None):
        """
        Constructs a SubscriptionClient instance.
        (since 0.2.0)
        
        url is the non-secure URL of the host to be contacted.
        urlsec is the secure URL of the host to be contacted.
        certificate is the proxy certificate.
        ca_path is the location of the Certification Authority certificates.
        """        
        DQClient.__init__(self, url, urlsec, certificate, ca_path)


    def addDatasetSubscription (self, uid, dsn, location, archived=SubscriptionArchivedState.UNARCHIVE, callbacks={}, sources={}, sources_policy=SourcesPolicy.ALL_SOURCES, wait_for_sources=0, destination=''):
        """
        POST request to insert new dataset subscription.
        (since 0.2.0)
        
        uid is the dataset or dataset version unique identifier.
        dsn is the dataset name.
        location is the dataset subscription location.
        archived is the subscription state.
        callbacks ... TODO
        sources ... TODO
        sources_policy ... TODO
        wait_for_sources ... TODO
        destination ... TODO
        
        DQSubscriptionExistsException is raised,
        in case there is a subscription for this uid-location.
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        
        Nothing is returned.
        """
        
        common.DQValidator.is_uid(uid)
        common.DQValidator.is_dataset_name(dsn)
        common.DQValidator.is_destination(location)
        common.DQValidator.is_subscription_sources_policy(sources_policy)
        common.DQValidator.is_dictionary([sources, callbacks])
        for eachSource in sources.keys():
            common.DQValidator.is_source(eachSource)
        common.DQValidator.is_subscription_state(archived)
        common.DQValidator.checkArgsStr([destination])
        common.DQValidator.checkArgsInt([wait_for_sources])
        
        self.type = HTTP.POST
        self.request = '/subscription/dataset'
        self.params = {
            'uid': uid,
            'dsn': dsn,
            'location': location,
            'archive': archived,
            'callback': callbacks,
            'sources': sources,
            'sources_policy': sources_policy,
            'wait_for_sources': wait_for_sources,
            'destination': destination
        }
        
        self.send()


    def auto_configure ():
        """
        Returns this client configuration.
        (since 0.2.0)
        
        (url_insecure_host, url_secure_host)
        """
        import client_conf
        
        return (
            client_conf.subscription['insecure'],
            client_conf.subscription['secure']
        )

    auto_configure = staticmethod(auto_configure)


    def deleteDatasetSubscription (self, uid, location):
        """
        DEL to delete the dataset/dataset version subscription from the given location.
        (since 0.2.0)
        
        uid is the dataset or dataset version unique identifier.
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        
        Nothing is returned.
        """
        
        common.DQValidator.is_uid(uid)
        common.DQValidator.is_source(location)
        
        self.type = HTTP.DELETE
        self.request = '/subscription/dataset'
        self.params = {'uid': uid, 'location': location}
        self.send()


    def deleteDatasetSubscriptions (self, uids):
        """
        DEL to delete the given dataset/dataset version subscriptions from all locations.
        (since 0.2.1)
        
        uids is list of dataset or dataset version unique identifiers.
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        """
        
        common.DQValidator.is_list_of_uids(uids)
        
        self.type = HTTP.DELETE
        self.request = '/subscription/dataset'
        self.params = {'uids': uids}
        self.send()


    def markModified (self, uids):
        """
        Marks the given subscriptions as modified and update the last modified time.
        
        uids is a list of dataset or dataset version unique identifiers.
        
        DQDaoException is raised,
        in case there is a python or database error.
        
        Nothing is returned.
        """
        
        common.DQValidator.is_list_of_uids(uids)
        
        self.type = HTTP.PUT
        self.request = '/subscription/rpc'
        self.params = {'operation': 'markModified', 'uids': uids}
        self.send()


    def markProcessed (self, location, uids):
        """
        Marks the given subscriptions as modified and update the last modified time.
        (since 0.2.5)
        
        location is the dataset subscription location that were the uids were processed.
        uids is a dictionary containing {'uid', 'timestamp'}.
        
        DQDaoException is raised,
        in case there is a python or database error.
        DQInvalidRequestException is raised,
        in case the given uids are not a list.
        
        Nothing is returned.
        """
        
        common.DQValidator.is_destination(location)
        
        common.DQValidator.is_dictionary([uids])
        common.DQValidator.is_list_of_uids(uids.keys())
        
        self.type = HTTP.PUT
        self.request = '/subscription/rpc'
        self.params = {'operation': 'markProcessed', 'location': location, 'uids': uids}
        
        print self.send()


    def queryDatasetSubscriptions (self, uid, archive=None):
        """
        GET request to find the subscriptions of the dataset given by vuid.
        (since 0.2.0)
        
        uid is the dataset or dataset version unique identifier.
        archive is the dataset subscription state (common.DQConstants.SubscriptionArchivedState).
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        
        Returns a dictionary containing the subscriptions information.
        {
            'location1': {
                'sources': [],
                'archival': 0,
                'waitForSources': True,
                'sourcesPolicy': SourcesPolicy.ALL_SOURCES,
                'callbacks': ['http://callback/1']
                'creationdate': creationdate,
                'owner': owner,
                'destination': destination,
                'dsn' : dsn
            }
            (...)
            'locationN': {
                'sources': [],
                'archival': 1,
                'waitForSources': True,
                'sourcesPolicy': SourcesPolicy.ALL_SOURCES,
                'callbacks': ['http://callback/1']
                'creationdate': creationdate,
                'owner': owner,
                'destination': destination,
                'dsn' : dsn
            }
        }
        """
        
        common.DQValidator.is_uid(uid)
        
        if archive is not None:
            common.DQValidator.is_subscription_state(archive)
        
        self.type = HTTP.GET
        self.request = '/subscription/dataset'
        self.params = {'uid': uid, 'archive': archive}
        
        return self.send()


    def querySubscriptionCallbacks (self, uid, location):
        """
        GET request to get the callbacks of the subscription
        given by vuid to the given location.
        (since 0.2.0)
        
        uid is the dataset or dataset version unique identifier.
        location is the subscription location.
        
        DQDaoException is raised,
        in case there is a python or database error in the central catalogs.
        
        Returns the callback python structure.
        """
        
        common.DQValidator.is_uid(uid)
        common.DQValidator.is_destination(location)
        
        self.type = HTTP.GET
        self.request = '/subscription/callback'
        self.params = {'uid': uid, 'location': location}
        
        return self.send()


    def querySubscriptionsInSite (self, location, archived=None, modified=None):
        """
        GET request to get the subscriptions on the given location.
        (since 0.2.0)
        
        location is the subscription location.
        query is a filter criteria to be appended to the SQL where clause.
        archived the dataset subscription state.
        modified is the dataset subscription modified flag.
        
        DQDaoException is raised,
        in case there is a python or database error.
        
        Returns a list containing the subscribed datasets or dataset versions.
        {
            'uid': {
                'timestamp': ..., <= last modified date
                'sources': ...,
                'archival': ...,
                'waitForSources': ...,
                'sourcesPolicy': ...,
                'callbacks': ...,
                'dsn': ...,
                'destination': ...,
                'creationdate': <= the dataset subscription creation date
            }
        }
        """
        
        common.DQValidator.is_destination(location)
        
        if archived is not None:
            common.DQValidator.is_subscription_state(archived)
        if modified is not None:
            common.DQValidator.is_subscription_modified_state(modified)
        
        self.type = HTTP.GET
        self.request = '/subscription/rpc'
        self.params = {'operation': 'querySubscriptionsInSite', 'location': location, 'archived': archived, 'modified': modified}
        
        return self.send()


# MODULE methods


def usage():
    """
    Usage: python SubscriptionClient.py <command> <args>

    Commands:

    addDatasetSubscription <-a|-u> <dataset vuid> <dataset name> <site> [{callbacks}] [list of sources] [sources policy] [wait for sources]
    queryDatasetSubscriptions [-a|-u] <dataset vuid>
    querySubscriptionsInlocation [-a|-u] <site>
    querySubscriptionCallbacks <vuid> <site>
    deleteDatasetSubscription <dataset vuid> <site>
    deleteDatasetSubscriptions (uid_1, ..., uid_N)

    -a and -u signify archived and unarchived datasets respectively
    (mandatory for adds, optional for queries (default is return both))
    """
    print usage.__doc__


def main (argv):
    """
    (since 0.2.0)
    """

    if len(argv) < 2:
        usage()
        sys.exit(1)
    
    # retrieving client configuration
    client = SubscriptionClient()
    
    try:
        opts, args = getopt.getopt(argv[1:], "au")
    except getopt.GetoptError:
        print "Invalid arguments!"
        usage()
        sys.exit(2)

    archive = SubscriptionArchivedState.UNARCHIVE
    for o, a in opts:
        if o == "-a":
            archive = SubscriptionArchivedState.ARCHIVE
        elif o == "-u":
            archive = SubscriptionArchivedState.UNARCHIVE

    try:
        if argv[0]=='addDatasetSubscription':
            if len(args) > 2:
                out = client.addDatasetSubscription(args[0], args[1], args[2], archive, eval(args[3]), eval(args[4]), int(args[5]), int(args[6]))
            else:
                out = client.addDatasetSubscription(args[0], args[1], archive)
        elif argv[0]=='markProcessed':
            out = client.markProcessed(args[0], eval(args[1]))
        elif argv[0]=='queryDatasetSubscriptions':
            out = client.queryDatasetSubscriptions(args[0], archive)
        elif argv[0]=='querySubscriptionsInlocation':
            out = client.querySubscriptionsInSite(args[0], archive)
        elif argv[0]=='querySubscriptionCallbacks':
            out = client.querySubscriptionCallbacks(args[0], args[1])
        elif argv[0]=='deleteDatasetSubscription':
            out = client.deleteDatasetSubscription(args[0], args[1])
        elif argv[0]=='deleteDatasetSubscriptions':
            out = client.deleteDatasetSubscriptions(args[0:])            
        else:
            print 'Unknown command:',argv[0]
            sys.exit(1)

        print out

    except DQException, err_msg:
        sys.stderr.write('Error: '+str(err_msg)+'\n')


if __name__ == '__main__':
    main(sys.argv[1:])
