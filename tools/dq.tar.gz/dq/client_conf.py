repository = { 'secure': 'https://atlddmpro.cern.ch:8443/',
               'insecure': 'http://atlddmpro.cern.ch:8000/' }
location = { 'secure': 'https://atlddmpro.cern.ch:8443/',
             'insecure': 'http://atlddmpro.cern.ch:8000/' }
content = { 'secure': 'https://atlddmpro.cern.ch:8443/',
            'insecure': 'http://atlddmpro.cern.ch:8000/' }
subscription = { 'secure': 'https://atlddmpro.cern.ch:8443/',
                 'insecure': 'http://atlddmpro.cern.ch:8000/' }
monitor = { 'secure': 'https://atlddmpro.cern.ch:8443/',
                 'insecure': 'http://atlddmpro.cern.ch:8000/' }
