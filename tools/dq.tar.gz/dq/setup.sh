export DQ2_URL_SERVER=http://atlddmpro.cern.ch:8000/dq2/
export DQ2_URL_SERVER_SSL=https://atlddmpro.cern.ch:8443/dq2/
export DQ2_LOCAL_ID=
export PATH=$PATH:$PWD
