#!/bin/sh
#
# Installs DQ2 client and generates client configuration file
#

CENTRAL_CATALOG=atlddmpro.cern.ch

WEB_DIR=http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/

VERSION=0_2_11

MYPWD=$PWD

MYTMP=`mktemp -d`

cd $MYTMP

wget $WEB_DIR/externals/python/pycurl-7.10.6.tar.gz
tar zxf pycurl-7.10.6.tar.gz
cd pycurl-7.10.6
python setup.py build
python setup.py install --install-data=$MYPWD --install-lib=$MYPWD

wget $WEB_DIR/DQ2_$VERSION/dq2-client-$VERSION.tar.gz
tar zxf dq2-client-$VERSION.tar.gz
cd dq2-client-$VERSION
python setup-client.py build
python setup-client.py install --install-data=$MYPWD --install-lib=$MYPWD

# generate client configuration script
cat > $MYPWD/client_conf.py << EOF
repository = { 'secure': 'https://$CENTRAL_CATALOG:8443/',
               'insecure': 'http://$CENTRAL_CATALOG:8000/' }
location = { 'secure': 'https://$CENTRAL_CATALOG:8443/',
             'insecure': 'http://$CENTRAL_CATALOG:8000/' }
content = { 'secure': 'https://$CENTRAL_CATALOG:8443/',
            'insecure': 'http://$CENTRAL_CATALOG:8000/' }
subscription = { 'secure': 'https://$CENTRAL_CATALOG:8443/',
                 'insecure': 'http://$CENTRAL_CATALOG:8000/' }
monitor = { 'secure': 'https://$CENTRAL_CATALOG:8443/',
                 'insecure': 'http://$CENTRAL_CATALOG:8000/' }
EOF

# generate run script with correct server endpoint
cat > $MYPWD/dq2 << EOF
export PYTHONPATH=$MYPWD:\$PYTHONPATH
python $MYPWD/common/client/tool/dq2.py \$@
EOF
chmod +x $MYPWD/dq2

cd $MYPWD

