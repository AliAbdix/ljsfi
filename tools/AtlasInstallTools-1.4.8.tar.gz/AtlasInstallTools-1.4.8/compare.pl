#!/usr/bin/perl

use Getopt::Long;
GetOptions("file=s"=> \$file, "host=s" => \$host);
open srnname, "< $ENV{'PWD'}/$file"

or warn "compare.pl:Can't open file: myguid, probably it does not exist yet\n";

while (<srnname>){
	chomp;
	$array = $_;
#	print "$array\n ";
    }
    close srnname;


$str = $array;
$where = index($str, $host);
if ($where == -1) 
{
    print "0";
#it did'nt found the match between your SE and the SE with your tarball stored
}
else 
{
#it did
    print "1";
}
