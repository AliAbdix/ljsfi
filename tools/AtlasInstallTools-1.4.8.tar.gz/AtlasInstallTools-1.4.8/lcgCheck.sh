#!/bin/bash
###############################################################################
#Script: lcgCheck.sh:
#Notes:
#script running in the WN, allows the SM to copy in the best (the CLOSEST one) 
#SE the software he need to install in the WN.
# it check if the software is already copiedAndRegistered in the Grid:
# if not does it (through the script lcgDownUpload.sh) or stops the process 
# if yes it replicas the file in the closest SE whether it's not yet present 
# there a copy.
##############################################################################
name_tar=$1
se_host=$2
number_oftar=$3
vo_name=$4
VERSION=$5
export MAINPATH
export EXP_PATH

source $EXP_PATH/setup-installation.sh

echo "checking the position of tarballs in the Grid......"
 i=1
 while [ $i -le $number_oftar ]
 do
   if [ $number_oftar -eq "1" ]; then
      nametar=${name_tar}.tar.gz
   else
   nametar=${name_tar}_${i}.tar.gz
   fi
   i=`expr $i + 1`

 lcg-lg --vo=${vo_name} lfn:${CATALOG_PATH}${nametar} >myguid
 result=` perl $STORAGE_DIR/parse.pl -list`
 if [ "${result}" -eq "1" ]; then
  #edg-rm --vo=$vo_name listBestFile lfn:$nametar >bestReplica
  lcg-lr --vo=$vo_name lfn:${CATALOG_PATH}${nametar} | grep $se_host | tail -n 1 >bestReplica
  match=` perl $STORAGE_DIR/compare.pl -file bestReplica -host $se_host`
  if [ "${match}" -eq "1" ]; then
   echo "Already present in the correct location"
   lcg-lr --vo=$vo_name lfn:${CATALOG_PATH}${nametar} | grep $se_host | tail -n 1 >srnlocation
  else [ "${match}" -eq "0" ]
   echo "Need a new Replica to the close SE"
   lcg-rep --vo=$vo_name lfn:${CATALOG_PATH}${nametar} -d $se_host -P install/lcg/${nametar} > srnlocation 
   if [ ! $? -eq "0" ]; then
    echo "lcgCheck:Error in replicating files to the closest SE" >&2
   fi
  #you need this srnlocation later, in  the copyFile statement
  fi
 else [ "${result}" -eq "0" ] 
  echo "The tarball has yet not been uploaded in the Grid" 
  echo "Trying to launch the utility to download from outside the software" 
  if [ -f "$EXP_PATH/lcgDownAndUpload.sh" ]; then
   $EXP_PATH/lcgDownAndUpload.sh $VERSION $nametar $vo_name $se_host
   if [ ! $? -eq "0" ]; then
    echo "lcgCheck:Tarball not uploaded in the grid or not still created " >&2
    exit 1
   fi 
  else
   echo "lcgCheck:Tarball not uploaded in the grid or not still created " >&2
   echo "Utility to download not present"
   exit 1
  fi
 fi
done
 
