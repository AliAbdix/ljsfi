VERSION=$1
internal_tar_name=$2
vo_name=$3
host_SE=$4

cd $STORAGE_DIR
TEMPBUILD="$PWD/`basename $EXP_PATH`_temp"
mkdir $TEMPBUILD
cp -a $EXP_PATH/* $TEMPBUILD
cd $TEMPBUILD

source setup-installation.sh

# prepare the experiment scripts in the temporary directory
# to build the tarball..
chmod +x *
# Prepare the local cache
mkdir -p localcache/temp
cd localcache/temp

# Setup pacman for our architecture
pacman -version
if [ `echo $PACMAN_VER | awk -F. '{printf "%d%02d%02d",$1,$2,$3}'` -lt 31800 ] ; then
  pacman -v down tar up
else
  pacman -v download tar up
fi
pacman -def

# Get the compiler and do the snapshot
echo "Getting the compiler from the cache"
pacman $PACMAN_OPTS \
       -fetch http://classis01.roma1.infn.it/pacman/cache:$VERSION/gcc${arch}
echo "Making a snapshot of the compiler cache"
pacman $PACMAN_OPTS -snap
[ -s gcc${arch}.snap ] && mv gcc${arch}.snap ..
[ -d installation.snapshot ] && mv installation.snapshot ../gcc${arch}.snapshot
rm -fr *

# Get KV and do the snapshot
echo "Getting KV from the cache"
pacman $PACMAN_OPTS \
       -fetch http://classis01.roma1.infn.it/pacman/cache:$VERSION/KitValidation
echo "Making a snapshot of the KV cache"
pacman $PACMAN_OPTS -snap
[ -s KitValidation.snap ] && mv KitValidation.snap ..
[ -d installation.snapshot ] && mv installation.snapshot ../KitValidation.snapshot
rm -fr *

# Get the DB release and do the snapshot
if [ "$DBREL" != "" ] ; then
  echo "Getting DB release $DBREL from the cache"
  pacman $PACMAN_OPTS -fetch $ATLASDBRELCACHE:DBRelease-$DBREL
  echo "Making a snapshot of the DB release cache"
  pacman $PACMAN_OPTS -snap
  [ -s DBRelease-$DBREL.snap ] && mv DBRelease-$DBREL.snap ..
  [ -d installation.snapshot ] && mv installation.snapshot ../DBRelease-$DBREL.snapshot
  rm -fr *
fi

# Get the release and create the snapshot
echo "Getting $sw_name $VERSION from the cache"
pbver="`echo $VERSION | sed 's#\.#_#g'`"
if [ "$sw_name" == "AtlasRelease" ] ; then       # Monolithic builds
  pacman $PACMAN_OPTS -fetch ATLAS:$VERSION/${sw_name}${relarch}-opt
else                                             # Project builds
  pacman $PACMAN_OPTS -fetch $ATLASPROJECTSCACHE:${sw_name}_${pbver}${relarch}_opt
fi
echo "Making a snapshot of the ${sw_name} cache"
pacman $PACMAN_OPTS -snap -o atlas-sw-install
if [ "$sw_name" == "AtlasRelease" ] ; then     # Monolithic release
  [ -s atlas-sw-install.snap ] && \
     mv atlas-sw-install.snap ../${sw_name}${relarch}-opt.snap
  [ -d atlas-sw-install.snapshot ] && \
     mv atlas-sw-install.snapshot ../${sw_name}${relarch}-opt.snapshot
else                                           # Project build
  [ -s atlas-sw-install.snap ] && \
     mv atlas-sw-install.snap ../${sw_name}_${pbver}${relarch}_opt.snap
  [ -d atlas-sw-install.snapshot ] && \
     mv atlas-sw-install.snapshot ../${sw_name}_${pbver}${relarch}_opt.snapshot
fi
cd ..
rm -fr temp
cd ..
rm -fr stderror stdout

# Calculate the checksums
echo "Calculating checksums"
rm -f MD5SUM
find . -type f -exec md5sum {} \; | grep -v MD5SUM >> MD5SUM
 
# Build and register the tar file
echo "Listing the build directory: $PWD"
\ls $PWD

echo "Creating the tarball..."
tar cvfz $internal_tar_name * > /dev/null
  if [ ! $? -eq "0" ]; then
   echo "Tarball SW-EXP creation: FAILED. " >&2
   exit 
  fi 
echo
echo ">>> Registering $internal_tar_name"
echo ">>> as ${CATALOG_PATH}${internal_tar_name}"
echo ">>> in the catalog (TYPE=$LCG_CATALOG_TYPE, HOST=$LFC_HOST)"
echo ">>> SE name: $host_SE"
echo
lcg-cr --vo=$vo_name file:$PWD/$internal_tar_name -d $host_SE -l ${CATALOG_PATH}${internal_tar_name} -P install/lcg/${internal_tar_name} >okkio
  if [ ! $? -eq "0" ]; then
   echo "Tarball not uploaded in the grid:. " >&2
   exit 
  fi  
cd $STORAGE_DIR
rm -fr $TEMPBUILD
cd $EXP_PATH
