#!/usr/bin/perl

use Getopt::Long;
GetOptions("-list"=>\$list);

if ($list){
    #print $ENV{'PWD'};
open myguid, "< $ENV{'PWD'}/myguid"

or warn "parse.pl:Can't open file: myguid, probably it does not exist yet\n";

while (<myguid>){
	chomp;
	$array = $_;
#	print "$array\n ";
    }
    close myguid;
}

$str = $array;

#print "$str\n";

if ($str =~ /^guid/){


    print "1";
}
else {
    print "0";
}

